import sys, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--step',type=int,default=3364)
ap.add_argument('--gap',type=int,default=2)
ap.add_argument('--u',type=int,default=2)
ap.add_argument('--ps',type=int,default=211)
ap.add_argument('--dl',type=int,default=-1)
ap.add_argument('--dw',type=int,default=2)
ap.add_argument('--dt',type=int,default=0)
ap.add_argument('--sstep',type=int,default=3044)
ap.add_argument('--sboot',type=int,default=3000)
ap.add_argument('--pp',default="1830 3740 5420 2341")
a=ap.parse_args()
d1,d2,d3,b=map(int,a.pp.split())
think=f"""res     dat     0,      0
st      dat     0,      0
v0      dat     0,      0
v1      dat     0,      0
v2      dat     0,      0
ch      dat     0,      0
tp      dat     0,      tbl-tp
vp      dat     0,      v0-vp
pc      dat     0,      0
        dat     0,      0
tbl     dat     0,      {a.dl}
        dat     0,      {a.dw}
        dat     0,      {a.dt}
think   ldp.ab  #0,     res
        ldp.ab  #PS,    st
        ldp.ab  #PS+1,  v0
        ldp.ab  #PS+2,  v1
        ldp.ab  #PS+3,  v2
        add.b   res,    tp
        add.b   st,     vp
        add.b   @tp,    @vp
        stp.b   v0,     #PS+1
        stp.b   v1,     #PS+2
        stp.b   v2,     #PS+3
        add.ab  #4000,  v0
        add.ab  #4000,  v1
        add.ab  #4000,  v2
        mov.b   st,     ch
        mov.b   st,     pc
        add.ab  #v0-pc, pc
        slt.b   @pc,    v0
        jmp     n1
        mov.ab  #0,     ch
        mov.ab  #v0-pc, pc
n1      slt.b   @pc,    v1
        jmp     n2
        mov.ab  #1,     ch
        mov.ab  #v1-pc, pc
n2      slt.b   @pc,    v2
        jmp     n3
        mov.ab  #2,     ch
n3      stp.b   ch,     #PS
        jmz.b   loop,   ch
        djn.b   stone,  ch
        jmp     start""".split("\n")
stone=f"""stone   mov.i   }}sbs,   >sbd
        djn     stone,  #5
        jmp     stn+{a.sboot}
sbs     dat     stn-sbs, 0
sbd     dat     0,      stn+{a.sboot}-sbd
stn     spl  #0,     <-100
sloop   mov.i sbmb,  @sptr
sptr    add.ab #{a.sstep}, #{a.sstep}
        djn.f sloop,  <-200
sbmb    dat  >-1,    >1""".split("\n")
paper=f"""start   spl  1,      <-200
        spl  1,      <-300
        spl  1,      <-400
s1      spl  @0,     <{d1}
        mov.i }}-1,   >-1
s2      spl  @0,     <{d2}
        mov.i }}-1,   >-1
s3      spl  @0,     <{d3}
        mov.i }}-1,   >-1
        mov.i pbmb,  >{b}
pbmb    dat  >2667,  >5334""".split("\n")
os=["loop    add.f  inc,   scan",
"scan    sne.i  0,     gap",
"        jmp    loop",
"found   mov.a  scan,  tmp",
"        add.a  #KK,   tmp",
"        slt.a  #RR,   tmp",
"        jmp    loop",
"        mov.ab scan,  scan",
"cl1     mov.i  sb,    >scan"]
os+=["        mov.i  sb,    >scan"]*(a.u-1)
os+=["        djn    cl1,   #LAP","cl2     mov.i  db,    >scan"]
os+=["        mov.i  db,    >scan"]*(a.u-1)
os+=["        jmp    cl2","sb      spl    #0,    SKIP","db      dat    0,     SKIP","inc     dat    step,  step","tmp     dat    0,     0"]
pre = think + paper + stone
M = len(pre)+1
N = len(os)-2
skip = len(os)-1
kk = M + a.gap
rr = kk + N
lap=-(-(8000-(skip-1))//a.u)
code="\n".join(pre+os).replace("SKIP",str(skip)).replace("LAP",str(lap)).replace("KK",str(kk)).replace("RR",str(rr))
print(f""";redcode-94
;name Lamplighter Fold
;author anon
;strategy p-space scored choice between a .66c oneshot scanner and a silk paper
;assert CORESIZE==8000
        org  think
PS      equ  {a.ps}
step    equ  {a.step}
gap     equ  {a.gap}
{code}
        end""")
