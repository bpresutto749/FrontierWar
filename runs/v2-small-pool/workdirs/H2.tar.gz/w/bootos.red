;redcode-94
;name Lamplighter
;author anon
;strategy .66c scan, then unrolled spl/dat self-skipping clear
;assert CORESIZE==8000
        org  go
go      mov.i   }bs,    >bd
        djn     go,     #13
        jmp     loop+4000
bs      dat     loop-bs, 0
bd      dat     0,      loop+4000-bd
step    equ  3364
gap     equ  2
loop    add.f  inc,   scan
scan    sne.i  0,     gap
        jmp    loop
found   mov.ab scan,  scan
cl1     mov.i  sb,    >scan
        mov.i  sb,    >scan
        djn    cl1,   #3995
cl2     mov.i  db,    >scan
        mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    12
db      dat    0,     12
inc     dat    step,  step
        end
