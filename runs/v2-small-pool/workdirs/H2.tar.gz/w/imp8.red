;redcode-94
;name ImpTest
;assert CORESIZE==8000
        org  start
istep   equ  2667
start   spl  1
        spl  1
        spl  1
        jmp  }ptr
ptr     dat  tbl, 0
tbl     jmp  imp
        jmp  imp+istep
        jmp  imp+2*istep
        jmp  imp+3*istep
        jmp  imp+4*istep
        jmp  imp+5*istep
        jmp  imp+6*istep
        jmp  imp+7*istep
imp     mov.i #0, istep
        end
