;redcode-94
;name Origami
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org  start
start   spl  1,      <-200
        spl  1,      <-300
        spl  1,      <-400
s1      spl  @0,     <1830
        mov.i }-1,   >-1
s2      spl  @0,     <3740
        mov.i }-1,   >-1
        mov.i bmb,   >2341
        jmp  s1,     <-1000
bmb     dat  >2667,  >5334
        end
