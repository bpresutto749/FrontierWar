#!/bin/bash
name=$1; R=$2; shift; shift
python3 /tmp/arena_H2/w/gen_sw8.py "$@" > /tmp/arena_H2/w/s8_$name.red
r=$(cd /tmp/arena_H2 && python3 tools/spar.py w/s8_$name.red --rounds $R | tail -1 | awk '{print $2}')
echo "$name $r $*"
