;redcode-94
;name Lamplighter
;author anon
;strategy .66c scan with spl bombing of hits, then spl/dat self-skipping clear
;assert CORESIZE==8000
        org  loop
step    equ  5128
gap     equ  4
loop    add.f  inc,   scan
scan    sne.i  0,     gap
cnt     djn.b  loop,  #921
        jmz.b  clr,   cnt
        mov.i  sbomb, @scan
        mov.i  sbomb, *scan
        djn.b  loop,  cnt
clr     mov.i  sb,    >scan
        djn    clr,   #7987
cl2     mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    14
db      dat    0,     14
inc     dat    step,  step
sbomb   spl    #0,    0
        end
