import sys
d1,d2,d3,b=map(int,sys.argv[1:5])
print(f""";redcode-94
;name Origami
;author anon
;strategy three-stage silk paper with bombing
;assert CORESIZE==8000
        org  start
start   spl  1,      <-200
        spl  1,      <-300
        spl  1,      <-400
s1      spl  @0,     <{d1}
        mov.i }}-1,   >-1
s2      spl  @0,     <{d2}
        mov.i }}-1,   >-1
s3      spl  @0,     <{d3}
        mov.i }}-1,   >-1
        mov.i bmb,   >{b}
bmb     dat  >2667,  >5334
        end""")
