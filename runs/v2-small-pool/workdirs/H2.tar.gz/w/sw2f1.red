;redcode-94
;name Lamplighter Fold
;author anon
;strategy p-space switch on loss between a .66c oneshot scanner and a silk paper
;assert CORESIZE==8000
        org  think
PS      equ  211
step    equ  3364
gap     equ  2
res     dat     0,      0
str     dat     0,      0
think   ldp.ab  #0,     res
        ldp.ab  #PS,    str
        jmn     keep,   res
        add.ab  #1,     str
        mod.ab  #2,     str
keep    stp.b   str,    #PS
        jmp     start
        jmp     start
start   spl  1,      <-200
        spl  1,      <-300
        spl  1,      <-400
s1      spl  @0,     <1830
        mov.i }-1,   >-1
s2      spl  @0,     <3740
        mov.i }-1,   >-1
s3      spl  @0,     <5420
        mov.i }-1,   >-1
        mov.i pbmb,  >2341
pbmb    dat  >2667,  >5334
loop    add.f  inc,   scan
scan    sne.i  0,     gap
        jmp    loop
found   mov.a  scan,  tmp
        add.a  #24,   tmp
        slt.a  #40,   tmp
        jmp    loop
        mov.ab scan,  scan
cl1     mov.i  sb,    >scan
        mov.i  sb,    >scan
        djn    cl1,   #3992
cl2     mov.i  db,    >scan
        mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    17
db      dat    0,     17
inc     dat    step,  step
tmp     dat    0,     0
        end
