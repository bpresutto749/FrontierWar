#!/bin/bash
# usage: sweep.sh name genargs...
name=$1; shift
python3 /tmp/arena_H2/w/gen_sw3.py "$@" > /tmp/arena_H2/w/sw_$name.red
r=$(cd /tmp/arena_H2 && python3 tools/spar.py w/sw_$name.red --rounds 200 | tail -1 | awk '{print $2}')
echo "$name $r $*"
