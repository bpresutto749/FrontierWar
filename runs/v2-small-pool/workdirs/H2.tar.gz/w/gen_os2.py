import sys
step=int(sys.argv[1]); gap=int(sys.argv[2]); back=int(sys.argv[3]); u=int(sys.argv[4])
L=[]
L.append("loop    add.f  inc,   scan")
L.append("scan    sne.i  0,     gap")
L.append("        jmp    loop")
L.append("found   mov.ab scan,  scan")
if back: L.append(f"        sub.ab #{back}, scan")
L.append("cl1     mov.i  sb,    >scan")
for i in range(u-1): L.append("        mov.i  sb,    >scan")
L.append("        djn    cl1,   #LAP")
L.append("cl2     mov.i  db,    >scan")
for i in range(u-1): L.append("        mov.i  db,    >scan")
L.append("        jmp    cl2")
L.append("sb      spl    #0,    SKIP")
L.append("db      dat    0,     SKIP")
L.append("inc     dat    step,  step")
n=len(L); skip=n-1  # offsets relative to scan: scan index 1, last index n-1 -> offset n-2; skip=n-1
lap=-(-(8000-(skip-1))//u)
src="\n".join(L).replace("SKIP",str(skip)).replace("LAP",str(lap))
print(f""";redcode-94
;name Lamplighter
;author anon
;strategy .66c scan, then unrolled spl/dat self-skipping clear
;assert CORESIZE==8000
        org  loop
step    equ  {step}
gap     equ  {gap}
{src}
        end""")
