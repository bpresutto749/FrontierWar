;redcode-94
;name Lamplighter Fold
;author anon
;strategy p-space scored choice between a .66c oneshot scanner and a silk paper
;assert CORESIZE==8000
PS      equ  211
step    equ  3364
gap     equ  2
        org  loop
loop    add.f  inc,   scan
scan    sne.i  0,     gap
        jmp    loop
found   mov.a  scan,  tmp
        add.a  #3,    tmp
        slt.a  #19,   tmp
        jmp    loop
        mov.ab scan,  scan
cl1     mov.i  sb,    >scan
        mov.i  sb,    >scan
        djn    cl1,   #3992
cl2     mov.i  db,    >scan
        mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    17
db      dat    0,     17
inc     dat    step,  step
tmp     dat    0,     0
        end
