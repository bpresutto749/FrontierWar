;redcode-94
;name StIm
;assert CORESIZE==8000
        org  start
step    equ  3044
istep   equ  2667
start   spl  boot
        spl  1
        spl  1
        spl  1
        spl  2
        jmp  @vec, }0
        jmp  *vec, }0
vec     dat  imp, imp+istep
        dat  0,0
imp     mov.i #istep, *0
boot    jmp  stone
        dat 0,0
        dat 0,0
stone   spl  #0,     <-100
loop    mov.i bomb,  @ptr
ptr     add.ab #step, #step
        djn.f loop,  <-200
bomb    dat  >-1,    >1
        end
