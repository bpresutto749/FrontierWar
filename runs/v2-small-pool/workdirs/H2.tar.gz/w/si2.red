;redcode-94
;name StIm2
;assert CORESIZE==8000
        org  start
step    equ  3044
istep   equ  2667
start   spl  stone
        spl  1
        spl  1
        spl  1
        jmp  }ptr
ptr     dat  tbl, 0
tbl     jmp  imp
        jmp  imp+istep
        jmp  imp+2*istep
        jmp  imp+3*istep
        jmp  imp+4*istep
        jmp  imp+5*istep
        jmp  imp+6*istep
        jmp  imp+7*istep
imp     mov.i #0, istep
        dat 0,0
        dat 0,0
stone   spl  #0,     <-100
loop    mov.i bomb,  @ptr2
ptr2    add.ab #step, #step
        djn.f loop,  <-200
bomb    dat  >-1,    >1
        end
