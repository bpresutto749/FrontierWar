import sys, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--step',type=int,default=3364)
ap.add_argument('--gap',type=int,default=2)
ap.add_argument('--u',type=int,default=2)
ap.add_argument('--ps',type=int,default=211)
ap.add_argument('--force',type=int,default=-1)
ap.add_argument('--pp',default="1830 3740 5420 2341")
ap.add_argument('--order',default="ps")
a=ap.parse_args()
d1,d2,d3,b=map(int,a.pp.split())
think=f"""res     dat     0,      0
str     dat     0,      0
think   ldp.ab  #0,     res
        ldp.ab  #PS,    str
        jmn     keep,   res
        add.ab  #1,     str
        mod.ab  #2,     str
keep    stp.b   str,    #PS
        jmz     loop,   str
        jmp     start""".split("\n")
if a.force==0: think[-2]="        jmp     loop"
if a.force==1: think[-2]="        jmp     start"
paper=f"""start   spl  1,      <-200
        spl  1,      <-300
        spl  1,      <-400
s1      spl  @0,     <{d1}
        mov.i }}-1,   >-1
s2      spl  @0,     <{d2}
        mov.i }}-1,   >-1
s3      spl  @0,     <{d3}
        mov.i }}-1,   >-1
        mov.i pbmb,  >{b}
pbmb    dat  >2667,  >5334""".split("\n")
os=["loop    add.f  inc,   scan",
"scan    sne.i  0,     gap",
"        jmp    loop",
"found   mov.a  scan,  tmp",
"        add.a  #KK,   tmp",
"        slt.a  #RR,   tmp",
"        jmp    loop",
"        mov.ab scan,  scan",
"cl1     mov.i  sb,    >scan"]
os+=["        mov.i  sb,    >scan"]*(a.u-1)
os+=["        djn    cl1,   #LAP","cl2     mov.i  db,    >scan"]
os+=["        mov.i  db,    >scan"]*(a.u-1)
os+=["        jmp    cl2","sb      spl    #0,    SKIP","db      dat    0,     SKIP","inc     dat    step,  step","tmp     dat    0,     0"]
pre = think + (paper if a.order=="ps" else [])
post = [] if a.order=="ps" else paper
M = len(pre)+1  # offset of first instruction relative to scan is -M
N = len(os)-2 + len(post)  # last offset
skip = len(os)-1  # skip past os code (tmp at offset len(os)-2)
kk = M + a.gap
rr = kk + N
lap=-(-(8000-(skip-1))//a.u)
code="\n".join(pre+os+post).replace("SKIP",str(skip)).replace("LAP",str(lap)).replace("KK",str(kk)).replace("RR",str(rr))
print(f""";redcode-94
;name Lamplighter Fold
;author anon
;strategy p-space switch on loss between a .66c oneshot scanner and a silk paper
;assert CORESIZE==8000
        org  think
PS      equ  {a.ps}
step    equ  {a.step}
gap     equ  {a.gap}
{code}
        end""")
