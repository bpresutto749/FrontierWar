;redcode-94
;name Lamplighter Switch
;author anon
;strategy p-space switch on loss: oneshot scanner / stone
;assert CORESIZE==8000
        org  think
PS      equ  211
step    equ  3364
gap     equ  2
sstep   equ  3044
res     dat     0,      0
str     dat     0,      0
think   ldp.ab  #0,     res
        ldp.ab  #PS,    str
        jmn     keep,   res
        add.ab  #1,     str
        mod.ab  #2,     str
keep    stp.b   str,    #PS
        jmp loop
stone   spl  #0,     <-100
sloop   mov.i sbmb,  @sptr
sptr    add.ab #sstep, #sstep
        djn.f sloop,  <-200
sbmb    dat  >-1,    >1
loop    add.f  inc,   scan
scan    sne.i  0,     gap
        jmp    loop
found   mov.a  scan,  tmp
        add.a  #18,   tmp
        slt.a  #32,   tmp
        jmp    loop
        mov.ab scan,  scan
cl1     mov.i  sb,    >scan
        djn    cl1,   #7990
cl2     mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    14
db      dat    0,     14
inc     dat    step,  step
tmp     dat    0,     0
        end
