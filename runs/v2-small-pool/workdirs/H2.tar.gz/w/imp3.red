;redcode-94
;name ImpTest
;assert CORESIZE==8000
        org  start
istep   equ  2667
start   spl  1
        spl  1
        spl  1
        spl  1
        spl  1
        spl  1
        spl  1
        spl  2
        jmp  @vec, }0
        jmp  *vec, }0
vec     dat  imp, imp+istep
        dat  0,0
imp     mov.i #istep, *0
        end
