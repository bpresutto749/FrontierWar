import sys
step=int(sys.argv[1]) if len(sys.argv)>1 else 1032
gap=int(sys.argv[2]) if len(sys.argv)>2 else 4
cnt=int(sys.argv[3]) if len(sys.argv)>3 else 968
print(f""";redcode-94
;name Lamplighter
;author anon
;strategy .66c scan with spl bombing of hits, then spl/dat self-skipping clear
;assert CORESIZE==8000
        org  loop
step    equ  {step}
gap     equ  {gap}
loop    add.f  inc,   scan
scan    sne.i  0,     gap
cnt     djn.b  loop,  #{cnt}
        jmz.b  clr,   cnt
        mov.i  sbomb, @scan
        mov.i  sbomb, *scan
        djn.b  loop,  cnt
clr     mov.i  sb,    >scan
        djn    clr,   #7987
cl2     mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    14
db      dat    0,     14
inc     dat    step,  step
sbomb   spl    #0,    0
        end""")
