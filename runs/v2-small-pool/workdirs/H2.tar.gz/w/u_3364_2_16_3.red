;redcode-94
;name Lamplighter
;author anon
;strategy .66c scan, then unrolled spl/dat self-skipping clear
;assert CORESIZE==8000
        org  loop
step    equ  3364
gap     equ  2
loop    add.f  inc,   scan
scan    sne.i  0,     gap
        jmp    loop
found   mov.ab scan,  scan
        sub.ab #16, scan
cl1     mov.i  sb,    >scan
        mov.i  sb,    >scan
        mov.i  sb,    >scan
        djn    cl1,   #2662
cl2     mov.i  db,    >scan
        mov.i  db,    >scan
        mov.i  db,    >scan
        jmp    cl2
sb      spl    #0,    15
db      dat    0,     15
inc     dat    step,  step
        end
