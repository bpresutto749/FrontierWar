import sys
def si(step=3364, D=4000, imp=2667, bmb="dat     >-1, >1"):
    return f""";redcode-94
;name Pebble Imp
;author Barthelemy Presutto
;strategy stone with 3-point imp ring
;assert CORESIZE==8000
        org     go
go      mov.i   loop, loop+{D}
        mov.i   loop+1, loop+{D}+1
        mov.i   loop+2, loop+{D}+2
        mov.i   loop+3, loop+{D}+3
        spl     loop+{D}
c0      spl     i2
        nop     0, 0
        jmp     imp
i2      spl     i3
        jmp     imp+{imp}
i3      jmp     imp+{2*imp}
imp     mov.i   #0, {imp}
loop    add.ab  #{step}, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     {bmb}
        end
"""
if __name__=="__main__":
    kw={}
    for x in sys.argv[1:]:
        k,v=x.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    print(si(**kw))
