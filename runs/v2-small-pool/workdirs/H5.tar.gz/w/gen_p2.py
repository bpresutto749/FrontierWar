import sys
def paper(cs=(3620,2368,5512), bomb="mov.i   #1, <1", last="djn.f   p1, <2667", nspl=3):
    pairs="".join(f"p{i}      spl     @0, }}{c}\n        mov.i   }}p{i}, >p{i}\n" for i,c in enumerate(cs))
    return f""";redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        org     start
start   {"spl     1\n        "*nspl}
{pairs}        {bomb}
        {last}
        end
""".replace("start   spl     1\n        \n","start   spl     1\n").replace("\n        \np0","\np0")
