;redcode-94
;name sit
;author x
loop jmp 0
