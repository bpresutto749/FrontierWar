;redcode-94
;name Pebble
;author Barthelemy Presutto
;strategy stone
;assert CORESIZE==8000
STEP    equ     3364
        org     loop
loop    add.ab  #STEP, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
        end
