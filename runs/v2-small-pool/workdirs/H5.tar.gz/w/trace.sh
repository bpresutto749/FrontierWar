#!/bin/bash
W=$1; O=$2; N=$3
s=""; pa=0; pb=0; for r in $(seq 1 $N); do read x a b c < <(../bin/pmars -b -r $r -f $W $O 2>/dev/null| tail -1); if [ $a -gt $pa ]; then s="${s}W"; elif [ $b -gt $pb ]; then s="${s}L"; else s="${s}T"; fi; pa=$a; pb=$b; done; echo $s
