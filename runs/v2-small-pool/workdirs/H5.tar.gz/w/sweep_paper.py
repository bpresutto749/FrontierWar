import random, subprocess, re, sys
sys.path.insert(0,'.')
from gen_paper import paper
random.seed(int(sys.argv[1]))
res=[]
for i in range(int(sys.argv[2])):
    a,b,c=[random.randint(100,7900) for _ in range(3)]
    open(f'tmp_{sys.argv[1]}.red','w').write(paper(a,b,c))
    out=subprocess.run(['python3','../tools/spar.py',f'tmp_{sys.argv[1]}.red','--rounds','100'],capture_output=True,text=True).stdout
    m=re.search(r'MEAN\s+([\d.]+)',out)
    s=float(m.group(1)) if m else -1
    res.append((s,a,b,c)); print(s,a,b,c,flush=True)
res.sort(reverse=True); print("BEST",res[:5])
