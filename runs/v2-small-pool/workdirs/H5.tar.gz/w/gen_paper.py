import sys
def paper(a,b,c,bomb="mov.i   #1, <1", last="djn.f   p1, <2667"):
    return f""";redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
p1      spl     @0, }}{a}
        mov.i   }}p1, >p1
p2      spl     @0, }}{b}
        mov.i   }}p2, >p2
p3      spl     @0, }}{c}
        mov.i   }}p3, >p3
        {bomb}
        {last}
        end
"""
if __name__=="__main__":
    a,b,c=map(int,sys.argv[1:4])
    print(paper(a,b,c))
