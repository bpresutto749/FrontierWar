;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
p0      spl     @0, }3620
        mov.i   }p0, >p0
p1      spl     @0, }2368
        mov.i   }p1, >p1
p2      spl     @0, }5512
        mov.i   }p2, >p2
p3      spl     @0, }1440
        mov.i   }p3, >p3
        mov.i   #1, <1
        djn.f   p0, <2667
        end
