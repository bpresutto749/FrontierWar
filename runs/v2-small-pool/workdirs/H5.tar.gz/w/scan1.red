;redcode-94
;name Lens
;author Barthelemy Presutto
;strategy oneshot scanner into d-clear
;assert CORESIZE==8000
STEP    equ     3364
START   equ     200
        org     scan
scan    add.ab  #STEP, ptr
ptr     jmz.f   scan, START
        mov.ab  ptr, gate
        add.ab  #ptr-gate-8, gate
clr     spl     #0, 0
cl      mov.i   bmb, >gate
        djn.f   cl, >gate
bmb     dat     <2667, <5334
gate    dat     0, 0
        end
