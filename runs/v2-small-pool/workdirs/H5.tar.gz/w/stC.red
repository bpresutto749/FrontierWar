;redcode-94
;name Pebble
;author Barthelemy Presutto
;assert CORESIZE==8000
        org     loop
loop    mov.i   bmb, @ptr
        add.ab  #3364, ptr
ptr     djn.f   loop, <100
bmb     dat     >-1, >1
        end
