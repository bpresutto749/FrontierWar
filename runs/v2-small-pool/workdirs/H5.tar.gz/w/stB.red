;redcode-94
;name Pebble
;author Barthelemy Presutto
;assert CORESIZE==8000
        org     loop
loop    add.f   inc, ptr
        mov.i   bmb, *ptr
        mov.i   bmb, @ptr
        jmp     loop
ptr     dat     100, 100+1682
inc     dat     3364, 3364
bmb     dat     >-1, >1
        end
