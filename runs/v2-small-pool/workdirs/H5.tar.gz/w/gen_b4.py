import sys
def b3(a=3620,b=2368,c=5512, step=3364, D=4000, pc=41, W=3, T=-1, L=-3,
       sstep=2379, soff=2375, K=6, n=3, E=9):
    return f""";redcode-94
;name Origami Triad
;author Barthelemy Presutto
;strategy p-space bandit choosing among silk paper, stone and spl-scanner
;assert CORESIZE==8000
        org     think
res     dat     0, 0
st      dat     0, 0
dl      dat     0, 0
v0      dat     0, 0
v1      dat     0, 0
v2      dat     0, 0
vptr    dat     0, v0-vptr
rc      dat     0, 0
think   ldp.ab  #0, res
        ldp.ab  #{pc}, st
        ldp.ab  #{pc+1}, v0
        ldp.ab  #{pc+2}, v1
        ldp.ab  #{pc+3}, v2
        jmz.b   lose, res
        sne.ab  #1, res
        jmp     wn
        sne.ab  #2, res
        jmp     te
        mov.ab  #4000, v0
        mov.ab  #4000, v1
        mov.ab  #4000, v2
        jmp     pick
lose    mov.ab  #{L}, dl
        jmp     upd
wn      mov.ab  #{W}, dl
        jmp     upd
te      mov.ab  #{T}, dl
upd     add.b   st, vptr
        add.b   dl, @vptr
pick    ldp.ab  #{pc+4}, rc
        add.ab  #1, rc
        stp.b   rc, #{pc+4}
        slt.ab  #{E}, rc
        jmp     expl
        mov.ab  #0, st
        mov.b   v0, dl
        slt.b   dl, v1
        jmp     c2
        mov.ab  #1, st
        mov.b   v1, dl
c2      slt.b   dl, v2
        jmp     store
        mov.ab  #2, st
        jmp     store
expl    mov.b   rc, st
        mod.ab  #3, st
store   stp.b   st, #{pc}
        stp.b   v0, #{pc+1}
        stp.b   v1, #{pc+2}
        stp.b   v2, #{pc+3}
        mov.i   res, store
        mov.i   res, pick+2
        mov.i   res, store+1
        mov.i   res, store+2
        mov.i   res, store+3
        mov.i   res, upd
        mov.i   res, upd+1
        jmz.b   start, st
        sne.ab  #1, st
        jmp     stone
        jmp     scan
stone   mov.i   loop, loop+{D}
        mov.i   loop+1, loop+{D}+1
        mov.i   loop+2, loop+{D}+2
        mov.i   loop+3, loop+{D}+3
        jmp     loop+{D}
start   spl     1
        spl     1
        spl     1
p1      spl     @0, }}{a}
        mov.i   }}p1, >p1
p2      spl     @0, }}{b}
        mov.i   }}p2, >p2
p3      spl     @0, }}{c}
        mov.i   }}p3, >p3
        mov.i   #1, <1
        djn.f   p1, <2667
loop    add.ab  #{step}, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
inc     dat     #{sstep}, #{sstep}
scan    add.f   inc, sp
sp      sne.i   {soff}, {soff+4}
        jmp     scan
        slt.ab  #20, sp
        jmp     self
        slt.ab  #{8000-70}, sp
        jmp     hit
self    djn.b   scan, #{K}
        jmp     clr
hit     mov.i   sb, *sp
        mov.i   sb, @sp
        jmp     scan
sb      spl     #0, 0
gate    dat     0, 8
clr     spl     #0, 0
cl      mov.i   cb, >gate
        djn.f   cl, >gate
cb      dat     <2667, 5
        end
"""
if __name__=="__main__":
    kw={}
    for x in sys.argv[1:]:
        k,v=x.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    print(b3(**kw))
