;redcode-94
;name Pebble2
;author Barthelemy Presutto
;strategy spl stone with clear
;assert CORESIZE==8000
STEP    equ     3044
        org     start
start   spl     #0, <-20
loop    mov.i   bmb, @ptr
        add.ab  #STEP, ptr
ptr     djn.f   loop, <-2000
bmb     dat     >-1, >1
        end
