import sys
def ps(a=3620,b=2368,c=5512, step=3364, pc=37, D=4000, L=1, W=1, TH=2, first="paper", tiep=0):
    order = ("start","stone") if first=="paper" else ("stone","start")
    return f""";redcode-94
;name Origami Switch
;author Barthelemy Presutto
;strategy p-space switch (with hysteresis) between silk paper and stone
;assert CORESIZE==8000
        org     think
res     dat     0, 0
st      dat     0, 0
cnt     dat     0, 0
think   ldp.ab  #0, res
        ldp.ab  #{pc}, st
        ldp.ab  #{pc+1}, cnt
        jmz.b   lost, res
        sne.ab  #1, res
        jmp     win
        sne.ab  #2, res
        add.ab  #{tiep}, cnt
        jmp     chk
win     slt.ab  #{W-1}, cnt
        mov.ab  #{W}, cnt
        sub.ab  #{W}, cnt
        jmp     save
lost    add.ab  #{L}, cnt
chk     slt.ab  #{TH-1}, cnt
        jmp     save
        add.ab  #1, st
        mov.ab  #0, cnt
save    stp.b   st, #{pc}
        stp.b   cnt, #{pc+1}
        mod.ab  #2, st
        jmz.b   {order[0]}, st
        jmp     {order[1]}
stone   mov.i   loop, loop+{D}
        mov.i   loop+1, loop+{D}+1
        mov.i   loop+2, loop+{D}+2
        mov.i   loop+3, loop+{D}+3
        jmp     loop+{D}
start   spl     1
        spl     1
        spl     1
p1      spl     @0, }}{a}
        mov.i   }}p1, >p1
p2      spl     @0, }}{b}
        mov.i   }}p2, >p2
p3      spl     @0, }}{c}
        mov.i   }}p3, >p3
        mov.i   #1, <1
        djn.f   p1, <2667
loop    add.ab  #{step}, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
        end
"""
if __name__=="__main__":
    kw={}
    for x in sys.argv[1:]:
        k,v=x.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    print(ps(**kw))
