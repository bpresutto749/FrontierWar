;redcode-94
;name Lens
;author Barthelemy Presutto
;strategy scanner into d-clear
;assert CORESIZE==8000
        org     scan
inc     dat     #2379, #2379
scan    add.f   inc, sp
sp      sne.i   2375, 2379
        jmp     scan
        slt.ab  #17, sp
        jmp     scan
        slt.ab  #7993, sp
        jmp     attack
        jmp     scan
gate    dat     0, 0
attack  mov.ab  sp, gate
        add.ab  #sp-gate-6, gate
clr     spl     #0, 0
cl      mov.i   bmb, >gate
        djn.f   cl, >gate
bmb     dat     <2667, 7
        end

