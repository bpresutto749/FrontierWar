import sys
def sc(step=2379, off=2375, d=4, K=6, sb="spl     #0, 0", bomb="dat     <2667, 5"):
    return f""";redcode-94
;name Lens
;author Barthelemy Presutto
;strategy scanner: spl-bombs what it finds, then d-clear
;assert CORESIZE==8000
        org     scan
inc     dat     #{step}, #{step}
scan    add.f   inc, sp
sp      sne.i   {off}, {off+d}
        jmp     scan
        slt.ab  #20, sp
        jmp     self
        slt.ab  #7993, sp
        jmp     hit
self    djn.b   scan, #{K}
        jmp     clr
hit     mov.i   sb, *sp
        mov.i   sb, @sp
        jmp     scan
sb      {sb}
gate    dat     0, 8
clr     spl     #0, 0
cl      mov.i   bmb, >gate
        djn.f   cl, >gate
bmb     {bomb}
        end
"""
if __name__=="__main__":
    kw={}
    for x in sys.argv[1:]:
        k,v=x.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    print(sc(**kw))
