;redcode-94
;name Pebble
;author Barthelemy Presutto
;assert CORESIZE==8000
        org     loop
loop    add.ab  #3364, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     spl     #0, >1
        end
