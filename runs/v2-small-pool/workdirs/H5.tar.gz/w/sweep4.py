import random, subprocess, re, sys
sys.path.insert(0,'.')
from gen_p2 import paper
seed=int(sys.argv[1]); random.seed(seed)
for i in range(int(sys.argv[2])):
    cs=tuple(random.randint(200,7800) for _ in range(4))
    f=f'tmp4_{seed}.red'
    open(f,'w').write(paper(cs=cs,last="djn.f   p0, <2667"))
    out=subprocess.run(['python3','../tools/spar.py',f,'--rounds','200'],capture_output=True,text=True).stdout
    m=re.search(r'MEAN\s+([\d.]+)',out)
    print(float(m.group(1)) if m else -1, cs, flush=True)
