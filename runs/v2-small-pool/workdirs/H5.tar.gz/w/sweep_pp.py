import random, subprocess, re, sys, math
sys.path.insert(0,'.')
from gen_ps4 import ps
seed=int(sys.argv[1]); random.seed(seed)
for i in range(int(sys.argv[2])):
    a,b,c,e=[random.randint(200,7800) for _ in range(4)]
    f=f'tpp_{seed}.red'
    open(f,'w').write(ps(a=a,b=b,c=c,e=e))
    out=subprocess.run(['python3','../tools/spar.py',f,'--rounds','200'],capture_output=True,text=True).stdout
    m=re.search(r'MEAN\s+([\d.]+)',out)
    print(float(m.group(1)) if m else -1, a,b,c,e, flush=True)
