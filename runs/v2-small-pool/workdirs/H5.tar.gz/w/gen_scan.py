import sys
def scan(step, off, d=4, back=6, bomb="dat     <2667, 7", clr="spl     #0, 0"):
    return f""";redcode-94
;name Lens
;author Barthelemy Presutto
;strategy scanner into d-clear
;assert CORESIZE==8000
        org     scan
inc     dat     #{step}, #{step}
scan    add.f   inc, sp
sp      sne.i   {off}, {off+d}
        jmp     scan
        slt.ab  #17, sp
        jmp     scan
        slt.ab  #7993, sp
        jmp     attack
        jmp     scan
gate    dat     0, 0
attack  mov.ab  sp, gate
        add.ab  #sp-gate-{back}, gate
clr     {clr}
cl      mov.i   bmb, >gate
        djn.f   cl, >gate
bmb     {bomb}
        end
"""
if __name__=="__main__":
    print(scan(*map(int,sys.argv[1:])))
