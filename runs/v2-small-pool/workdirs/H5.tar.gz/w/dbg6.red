;redcode-94
;name Origami Triad
;author Barthelemy Presutto
;strategy p-space bandit choosing among silk paper, stone and spl-scanner
;assert CORESIZE==8000
        org     think
res     dat     0, 0
st      dat     0, 0
dl      dat     0, 0
v0      dat     0, 0
v1      dat     0, 0
v2      dat     0, 0
vptr    dat     0, v0-vptr
rc      dat     0, 0
think   ldp.ab  #0, res
        ldp.ab  #41, st
        ldp.ab  #42, v0
        ldp.ab  #43, v1
        ldp.ab  #44, v2
        jmz.b   lose, res
        sne.ab  #1, res
        jmp     wn
        sne.ab  #2, res
        jmp     te
        mov.ab  #4000, v0
        mov.ab  #4000, v1
        mov.ab  #4000, v2
        jmp     pick
lose    mov.ab  #-3, dl
        jmp     upd
wn      mov.ab  #3, dl
        jmp     upd
te      mov.ab  #-1, dl
upd     add.b   st, vptr
        add.b   dl, @vptr
pick    ldp.ab  #45, rc
        add.ab  #1, rc
        stp.b   rc, #45
        slt.ab  #9, rc
        jmp     expl
        mov.ab  #0, st
        mov.b   v0, dl
        slt.b   dl, v1
        jmp     c2
        mov.ab  #1, st
        mov.b   v1, dl
c2      slt.b   dl, v2
        jmp     store
        mov.ab  #2, st
        jmp     store
expl    mov.b   rc, st
        mod.ab  #3, st
store   stp.b   st, #41
        stp.b   v0, #42
        stp.b   v1, #43
        stp.b   v2, #44
        mov.i   res, store
        mov.i   res, pick+2
        mov.i   res, store+1
        mov.i   res, store+2
        mov.i   res, store+3
        mov.i   res, upd
        mov.i   res, upd+1
        jmz.b   start, st
        sne.ab  #1, st
        jmp     stone
        jmp     scan
stone   dat 0, 0
        mov.i   loop+1, loop+4000+1
        mov.i   loop+2, loop+4000+2
        mov.i   loop+3, loop+4000+3
        jmp     loop+4000
start   spl     1
        spl     1
        spl     1
p1      spl     @0, }3620
        mov.i   }p1, >p1
p2      spl     @0, }2368
        mov.i   }p2, >p2
p3      spl     @0, }5512
        mov.i   }p3, >p3
        mov.i   #1, <1
        djn.f   p1, <2667
loop    add.ab  #3364, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
inc     dat     #2379, #2379
scan    dat 0, 0
sp      sne.i   2375, 2379
        jmp     scan
        slt.ab  #20, sp
        jmp     self
        slt.ab  #7930, sp
        jmp     hit
self    djn.b   scan, #6
        jmp     clr
hit     mov.i   sb, *sp
        mov.i   sb, @sp
        jmp     scan
sb      spl     #0, 0
gate    dat     0, 8
clr     spl     #0, 0
cl      mov.i   cb, >gate
        djn.f   cl, >gate
cb      dat     <2667, 5
        end

