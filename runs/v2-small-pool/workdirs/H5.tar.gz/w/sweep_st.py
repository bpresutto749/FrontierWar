import random, subprocess, re, sys, math
sys.path.insert(0,'.')
from gen_ps4 import ps
seed=int(sys.argv[1]); random.seed(seed)
for i in range(int(sys.argv[2])):
    while True:
        st=random.randint(100,3999)*2 if random.random()<0.5 else random.randint(200,7800)
        if math.gcd(st,8000) in (1,2,4,5,8,10,16): break
    f=f'tst_{seed}.red'
    open(f,'w').write(ps(step=st))
    out=subprocess.run(['python3','../tools/spar.py',f,'--rounds','200'],capture_output=True,text=True).stdout
    m=re.search(r'MEAN\s+([\d.]+)',out)
    print(float(m.group(1)) if m else -1, st, flush=True)
