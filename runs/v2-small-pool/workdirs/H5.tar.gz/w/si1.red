;redcode-94
;name Pebble Imp
;author Barthelemy Presutto
;strategy stone with 3-point imp ring
;assert CORESIZE==8000
        org     go
go      mov.i   loop, loop+4000
        mov.i   loop+1, loop+4000+1
        mov.i   loop+2, loop+4000+2
        mov.i   loop+3, loop+4000+3
        spl     loop+4000
c0      spl     i2
        nop     0, 0
        jmp     imp
i2      spl     i3
        jmp     imp+2667
i3      jmp     imp+5334
imp     mov.i   #0, 2667
loop    add.ab  #3364, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
        end

