;redcode-94
;name Lens
;author Barthelemy Presutto
;strategy scanner: spl-bombs what it finds, then d-clear
;assert CORESIZE==8000
        org     scan
inc     dat     #2379, #2379
scan    add.f   inc, sp
sp      sne.i   2375, 2379
        jmp     scan
        slt.ab  #20, sp
        jmp     self
        slt.ab  #7993, sp
        jmp     hit
self    djn.b   scan, #6
        jmp     clr
hit     mov.i   sb, *sp
        mov.i   sb, @sp
        jmp     scan
sb      spl     #0, 0
gate    dat     0, 8
clr     spl     #0, 0
cl      mov.i   bmb, >gate
        djn.f   cl, >gate
bmb     dat     <2667, 5
        end

