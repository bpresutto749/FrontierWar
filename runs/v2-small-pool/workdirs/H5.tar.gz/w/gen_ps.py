import sys
def ps(a=3620,b=2368,c=5512, step=3364, pc=37, mode="loss", D=4000, force=None):
    sw = "jmn.b   nosw, res" if mode=="loss" else "sne.ab  #1, res"
    sel = "jmz.b   start, st" if force is None else ("jmp start" if force=="paper" else "nop 0,0")
    return f""";redcode-94
;name Origami Switch
;author Barthelemy Presutto
;strategy p-space switch between silk paper and stone
;assert CORESIZE==8000
        org     think
res     dat     0, 0
st      dat     0, 0
think   ldp.ab  #0, res
        ldp.ab  #{pc}, st
        {sw}
        add.ab  #1, st
nosw    stp.b   st, #{pc}
        mod.ab  #2, st
        {sel}
        mov.i   loop, loop+{D}
        mov.i   loop+1, loop+{D}+1
        mov.i   loop+2, loop+{D}+2
        mov.i   loop+3, loop+{D}+3
        jmp     loop+{D}
start   spl     1
        spl     1
        spl     1
p1      spl     @0, }}{a}
        mov.i   }}p1, >p1
p2      spl     @0, }}{b}
        mov.i   }}p2, >p2
p3      spl     @0, }}{c}
        mov.i   }}p3, >p3
        mov.i   #1, <1
        djn.f   p1, <2667
loop    add.ab  #{step}, ptr
        mov.i   bmb, @ptr
ptr     jmp     loop, #0
bmb     dat     >-1, >1
        end
"""
if __name__=="__main__":
    kw={}
    for x in sys.argv[1:]:
        k,v=x.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    print(ps(**kw))
