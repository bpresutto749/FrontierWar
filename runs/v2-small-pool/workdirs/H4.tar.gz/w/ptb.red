;redcode-94
;name pta
;assert CORESIZE==8000
        org    p
p       ldp.ab #1,    v
        jmn.b  die,   v
        stp.b  v,     #1
        jmp    paper
die     dat    #0, #0
v       dat    #0, #0
paper   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }284
        mov.i }silk1, >silk1
silk2   spl @0, }7805
        mov.i }silk2, >silk2
        mov.i {silk1, <silkj
silkj   jmp @0, >5104
