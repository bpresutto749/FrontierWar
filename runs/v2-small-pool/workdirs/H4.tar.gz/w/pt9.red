;redcode-94
;name pt8
;assert CORESIZE==8000
        org    p
p       ldp.ab #3,    s0
        add.ab #3,    s0
        stp.b  s0,    #3
        ldp.ab #3,    s0
        ldp.ab #4,    s1
        slt.ab #2, s0
        jmp    paper
        dat    #0, #0
s0      dat    #0, #0
s1      dat    #0, #0
paper   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }284
        mov.i }silk1, >silk1
silk2   spl @0, }7805
        mov.i }silk2, >silk2
        mov.i {silk1, <silkj
silkj   jmp @0, >5104
