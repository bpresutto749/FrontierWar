;redcode-94
;name pt
;assert CORESIZE==8000
        org    p
p       ldp.ab #2,    cnt
        add.ab #1,    cnt
        stp.b  cnt,   #2
        slt.ab #10,   cnt
        dat    #0, #0
        jmp    imp
cnt     dat    #0, #0
imp     mov.i  #0, 1
