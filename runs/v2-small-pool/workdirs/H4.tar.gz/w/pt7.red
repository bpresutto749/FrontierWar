;redcode-94
;name pt7
;assert CORESIZE==8000
        org    p
p       ldp.ab #0,    res
        ldp.ab #2,    cnt
        jmz.b  first, cnt
        mov.b  res,   tp
        add.ab #tbl-tp, tp
        mov.b  @tp,   pts
        ldp.ab #3,    s0
        add.b  pts,   s0
        stp.b  s0,    #3
first   add.ab #1,    cnt
        stp.b  cnt,   #2
        ldp.ab #3,    s0
        slt.ab #200,  s0
        jmp    paper
        dat    #0, #0
res     dat    #0, #0
cnt     dat    #0, #0
s0      dat    #0, #0
tp      dat    #0, #0
pts     dat    #0, #0
tbl     dat    #0, #0
        dat    #0, #3
        dat    #0, #1
paper   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }284
        mov.i }silk1, >silk1
silk2   spl @0, }7805
        mov.i }silk2, >silk2
        mov.i {silk1, <silkj
silkj   jmp @0, >5104
