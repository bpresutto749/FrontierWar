;redcode-94
;name pt3
;assert CORESIZE==8000
        org    p
p       mov.ab #2,    res
        mov.b  res,   tp
        add.ab #tbl-tp, tp
        mov.b  @tp,   pts
        jmn.b  live,  pts
        dat    #0, #0
live    jmp    imp
res     dat    #0, #0
tp      dat    #0, #0
pts     dat    #0, #0
tbl     dat    #0, #0
        dat    #0, #3
        dat    #0, #1
imp     mov.i  #0, 1
