;redcode-94
;name Ply
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }2091
        mov.i }silk1, >silk1
silk2   spl @0, }5744
        mov.i }silk2, >silk2
        mov.i bmb, }6333
        mov.i bmb, }3865
        mov.i {silk1, <silk3
silk3   jmp @0, >1992
bmb     spl #0, #0
