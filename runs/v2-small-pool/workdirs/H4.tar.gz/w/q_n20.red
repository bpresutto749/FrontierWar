;redcode-94
;name Ply Q
;author anon
;strategy loop quickscan then silk paper
;assert CORESIZE==8000
        org qs
qs      add.f  qinc,  qp
qp      seq.i  40, 4040
        jmp    found
        djn.b  qs,    #20
        jmp    start
found   jmz.f  useb,  *qp
        mov.ab qp,    tp
        jmp    att
useb    mov.b  qp,    tp
att     add.ab #qp-tp-6, tp
atl     mov.i  qbomb, >tp
        djn.b  atl,   #20
        jmp    start
tp      dat    #0, #0
qinc    dat    #190, #190
qbomb   dat #0, #0
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }284
        mov.i }silk1, >silk1
silk2   spl @0, }7805
        mov.i }silk2, >silk2
silk3   spl @0, }3882
        mov.i }silk3, >silk3
silk4   spl @0, }3011
        mov.i }silk4, >silk4
silk5   spl @0, }1476
        mov.i }silk5, >silk5
        mov.i {silk1, <silkj
silkj   jmp @0, >5104
bmb     dat <2667, <5334
