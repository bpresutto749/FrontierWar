;redcode-94
;name Eye II
;author anon
;strategy oneshot sne scanner into spl then dat clear, self-safe
;assert CORESIZE==8000
step    equ    10
n       equ    (last+1-scan)
        org    scan
scan    add.f  inc,   ptr
ptr     sne.i  n+4,   n+4004
        djn.b  scan,  #(4000-n-16)/step
found   mov.ab ptr,   cp
        add.ab #(ptr-cp)-4, cp
        mov.ab #(scan-cp), cnt
        sub.b  cp,    cnt
sp      mov.i  sbmb,  >cp
        djn.b  sp,    cnt
        mov.ab #(last+2-cp), cp
dp      mov.i  dbmb,  >cp
        djn.b  dp,    #8000-n-3
        jmp    found
cp      dat    #0,    #0
cnt     dat    #0,    #0
inc     dat    #step, #step
sbmb    spl    #0,    #0
last
dbmb    dat    #0,    #0
