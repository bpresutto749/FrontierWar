;redcode-94
;name Ply
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }4359
        mov.i }silk1, >silk1
silk2   spl @0, }6999
        mov.i }silk2, >silk2
        mov.i bmb, }5591
        mov.i bmb, }1655
        mov.i {silk1, <silk3
silk3   jmp @0, >7656
bmb     spl #0, #0
