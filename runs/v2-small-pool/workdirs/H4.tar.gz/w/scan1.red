;redcode-94
;name Eye
;author anon
;strategy oneshot sne scanner into spl/dat clear
;assert CORESIZE==8000
step    equ    14
        org    scan
scan    add.f  inc,   ptr
ptr     sne.i  20,    4020
        djn.b  scan,  #280
found   mov.ab ptr,   cp
        add.ab #-12,  cp
clr     mov.i  sbmb,  >cp
        djn.b  clr,   #8000-40
clr2    mov.i  dbmb,  >cp
        jmp    clr2
cp      dat    #0,    #0
inc     dat    #step, #step
sbmb    spl    #0,    #0
dbmb    dat    #0,    #0
