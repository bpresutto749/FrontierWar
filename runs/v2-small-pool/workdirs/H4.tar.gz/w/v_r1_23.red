;redcode-94
;name Ply
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }3961
        mov.i }silk1, >silk1
silk2   spl @0, }7652
        mov.i }silk2, >silk2
        mov.i bmb, }5500
        mov.i bmb, }4589
        mov.i {silk1, <silk3
silk3   jmp @0, >2405
bmb     dat <2667, <5334
