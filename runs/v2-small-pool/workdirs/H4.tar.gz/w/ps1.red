;redcode-94
;name Ply Eye
;author anon
;strategy p-space switch between silk paper and oneshot scanner on loss
;assert CORESIZE==8000
        org    pstart
pstart  ldp.ab #0,    res
        ldp.ab #1,    strat
        jmn.b  keep,  res
        add.ab #1,    strat
        mod.ab #2,    strat
        stp.b  strat, #1
keep    jmz.b  start, strat
        jmp    scan
res     dat    #0,    #0
strat   dat    #0,    #0
start   spl    1,     <300
        spl    1,     <150
        spl    1,     <450
silk1   spl    @0,    }3620
        mov.i  }silk1, >silk1
silk2   spl    @0,    }1876
        mov.i  }silk2, >silk2
        mov.i  bmb,   }2367
        mov.i  bmb,   }-1033
        mov.i  {silk1, <silk3
silk3   jmp    @0,    >5143
bmb     dat    <2667, <5334
step    equ    10
n       equ    (last+1-scan)
scan    add.f  inc,   ptr
ptr     sne.i  n+4,   n+4004
        djn.b  scan,  #(4000-n-16)/step
found   mov.ab ptr,   cp
        add.ab #(ptr-cp)-4, cp
        mov.ab #(scan-cp), cnt
        sub.b  cp,    cnt
sp      mov.i  sbmb,  >cp
        djn.b  sp,    cnt
        mov.ab #(last+2-cp), cp
dp      mov.i  dbmb,  >cp
        djn.b  dp,    #8000-n-3
        jmp    found
cp      dat    #0,    #0
cnt     dat    #0,    #0
inc     dat    #step, #step
sbmb    spl    #0,    #0
last
dbmb    dat    #0,    #0
