import random, json, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
random.seed(int(sys.argv[1])); N=int(sys.argv[2])
bombs=["dat <2667, <5334","dat >2667, >5334","spl #0, #0","dat #0, #0"]
def rnd():
    return dict(d1=random.randint(200,7800),d2=random.randint(200,7800),d3=random.randint(200,7800),
                b1=random.randint(100,7900),b2=random.randint(100,7900),bomb=random.choice(bombs))
cands=[rnd() for _ in range(N)]
def run(i):
    out=subprocess.run(["./sweep.sh","r%s_%d"%(sys.argv[1],i),json.dumps(cands[i]),"100"],capture_output=True,text=True).stdout
    return out.strip()
with ThreadPoolExecutor(6) as ex:
    for r in ex.map(run,range(N)): print(r,flush=True)
