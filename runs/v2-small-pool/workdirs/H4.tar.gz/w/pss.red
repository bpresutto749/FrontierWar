;redcode-94
;name ps
dat #PSPACESIZE, #MAXPROCESSES
