#!/bin/bash
# usage: sweep.sh name json rounds
cd /tmp/arena_H4
python3 w/gen_paper.py "$2" > w/v_$1.red
r=$(python3 tools/spar.py w/v_$1.red --rounds ${3:-100} | grep MEAN | awk '{print $2}')
echo "$r $1 $2"
