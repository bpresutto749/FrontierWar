;redcode-94
;name Granite Imp
;author anon
;strategy mod-4 stone plus 3-point imp ring
;assert CORESIZE==8000
step    equ    3044
istep   equ    2667
        org    boot
boot    mov.i  imp,   imp+istep
        mov.i  imp,   imp+2*istep
        spl    loop
l0      spl    l2
l1      jmp    pad
l2      spl    l4
l3      jmp    imp+istep
l4      jmp    imp+2*istep
pad     jmp    imp
imp     mov.i  0,     istep
loop    add.f  incr,  ptr
        mov.i  sbomb, *ptr
        mov.i  dbomb, @ptr
        djn.b  loop,  #1000
clr     mov.i  dbomb, >ptr
        djn.f  clr,   >ptr
ptr     dat    #step-2, #2*step-2
incr    dat    #2*step, #2*step
sbomb   spl    #0,    #0
dbomb   dat    #0,    #0
