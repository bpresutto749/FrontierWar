;redcode-94
;name pt4
;assert CORESIZE==8000
        org    p
p       ldp.ab #2,    cnt
        ldp.ab #3,    v
        add.ab #1,    cnt
        stp.b  cnt,   #2
        stp.ab #5,    #3
        seq.ab #3,    cnt
        jmp    chk
        dat    #0, #0
chk     seq.ab #1,    cnt
        jmn.b  ok,    v
        jmp    imp
ok      sne.ab #5,    v
        jmp    imp
        dat    #0, #0
cnt     dat    #0, #0
v       dat    #0, #0
imp     jmp    0
