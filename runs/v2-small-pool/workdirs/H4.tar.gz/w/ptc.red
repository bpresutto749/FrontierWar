;redcode-94
;name ptc
;assert CORESIZE==8000
        org    p
p       ldp.ab #0,    res
        seq.ab #7999, res
        jmp    chk
        dat    #0, #0
chk     seq.ab #0,    res
        dat    #0, #0
        jmp    0
res     dat    #0, #0
