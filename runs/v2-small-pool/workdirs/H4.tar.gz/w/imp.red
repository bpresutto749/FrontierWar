;redcode-94
;name imp
mov.i #0,1
