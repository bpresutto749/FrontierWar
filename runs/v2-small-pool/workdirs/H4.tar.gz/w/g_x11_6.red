;redcode-94
;name Ply
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }3708
        mov.i }silk1, >silk1
silk2   spl @0, }4941
        mov.i }silk2, >silk2
silk3   spl @0, }7001
        mov.i }silk3, >silk3
silk4   spl @0, }1700
        mov.i }silk4, >silk4
silk5   spl @0, }4352
        mov.i }silk5, >silk5
        mov.i {silk1, <silkj
silkj   jmp @0, >2014
bmb     dat #0, #0
