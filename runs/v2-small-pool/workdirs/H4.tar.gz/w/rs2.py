import random, json, subprocess, sys
random.seed(int(sys.argv[1])); N=int(sys.argv[2])
for i in range(N):
    k=random.choice([4,5,6])
    ds=[random.randint(100,7900) for _ in range(k)]
    kw=dict(ds=ds,dj=random.randint(100,7900),bomb=random.choice(["dat <2667, <5334","dat >2667, >5334","dat #0, #0"]))
    subprocess.run(["./sw2.sh","x%s_%d"%(sys.argv[1],i),json.dumps(kw),"200"],capture_output=True)
