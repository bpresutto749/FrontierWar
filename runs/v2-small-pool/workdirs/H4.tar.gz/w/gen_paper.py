import sys
def paper(d1=3620,d2=1876,d3=5143,b1=2367,b2=-1033,nspl=3,bomb="dat <2667, <5334",extra=""):
    s=[";redcode-94",";name Ply",";author anon",";strategy silk paper",";assert CORESIZE==8000","        org start"]
    s.append("start   spl 1, <300")
    for i in range(nspl-1): s.append("        spl 1, <%d"%(150+i*300))
    s+=["silk1   spl @0, }%d"%d1,"        mov.i }silk1, >silk1",
        "silk2   spl @0, }%d"%d2,"        mov.i }silk2, >silk2",
        "        mov.i bmb, }%d"%b1,"        mov.i bmb, }%d"%b2]
    if extra: s.append(extra)
    s+=["        mov.i {silk1, <silk3","silk3   jmp @0, >%d"%d3,"bmb     "+bomb]
    return "\n".join(s)+"\n"
if __name__=="__main__":
    import json
    kw=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
    print(paper(**kw),end="")
