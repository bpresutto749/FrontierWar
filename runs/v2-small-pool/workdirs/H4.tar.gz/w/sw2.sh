#!/bin/bash
cd /tmp/arena_H4
python3 w/gen2.py "$2" > w/g_$1.red
r=$(python3 tools/spar.py w/g_$1.red --rounds ${3:-200} | grep MEAN | awk '{print $2}')
echo "$r $1 $2" | tee -a w/sw2.log
