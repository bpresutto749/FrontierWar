import sys, json
def paper(ds=(3620,1876,5432,980), dj=5143, nspl=3, bomb="dat <2667, <5334", bombs=(), back=True):
    s=[";redcode-94",";name Ply",";author anon",";strategy silk paper",";assert CORESIZE==8000","        org start"]
    s.append("start   spl 1, <300")
    for i in range(nspl-1): s.append("        spl 1, <%d"%(150+i*300))
    for i,d in enumerate(ds):
        s+=["silk%d   spl @0, }%d"%(i+1,d),"        mov.i }silk%d, >silk%d"%(i+1,i+1)]
    for b in bombs: s.append("        mov.i bmb, }%d"%b)
    if back: s.append("        mov.i {silk1, <silkj")
    s+=["silkj   jmp @0, >%d"%dj,"bmb     "+bomb]
    return "\n".join(s)+"\n"
if __name__=="__main__":
    kw=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
    print(paper(**kw),end="")
