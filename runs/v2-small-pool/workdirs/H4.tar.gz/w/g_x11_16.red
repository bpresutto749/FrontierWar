;redcode-94
;name Ply
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }6403
        mov.i }silk1, >silk1
silk2   spl @0, }1172
        mov.i }silk2, >silk2
silk3   spl @0, }3534
        mov.i }silk3, >silk3
silk4   spl @0, }5373
        mov.i }silk4, >silk4
silk5   spl @0, }3243
        mov.i }silk5, >silk5
silk6   spl @0, }1054
        mov.i }silk6, >silk6
        mov.i {silk1, <silkj
silkj   jmp @0, >3334
bmb     dat >2667, >5334
