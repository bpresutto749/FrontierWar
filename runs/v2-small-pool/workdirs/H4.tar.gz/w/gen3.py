import sys, json
sys.path.insert(0,'/tmp/arena_H4/w')
def build(F=40,S=97,N=40,W=20,back=6,qb="dat #0, #0",ds=(284,7805,3882,3011,1476),dj=5104,inc_b=None):
    s=[";redcode-94",";name Ply Q",";author anon",";strategy loop quickscan then silk paper",";assert CORESIZE==8000","        org qs"]
    s+=["qs      add.f  qinc,  qp",
        "qp      seq.i  %d, %d"%(F,F+4000),
        "        jmp    found",
        "        djn.b  qs,    #%d"%N,
        "        jmp    start",
        "found   jmz.f  useb,  *qp",
        "        mov.ab qp,    tp",
        "        jmp    att",
        "useb    mov.b  qp,    tp",
        "att     add.ab #qp-tp-%d, tp"%back,
        "atl     mov.i  qbomb, >tp",
        "        djn.b  atl,   #%d"%W,
        "        jmp    start",
        "tp      dat    #0, #0",
        "qinc    dat    #%d, #%d"%(S,S),
        "qbomb   "+qb]
    s.append("start   spl 1, <300")
    s+=["        spl 1, <150","        spl 1, <450"]
    for i,d in enumerate(ds):
        s+=["silk%d   spl @0, }%d"%(i+1,d),"        mov.i }silk%d, >silk%d"%(i+1,i+1)]
    s.append("        mov.i {silk1, <silkj")
    s+=["silkj   jmp @0, >%d"%dj,"bmb     dat <2667, <5334"]
    return "\n".join(s)+"\n"
if __name__=="__main__":
    kw=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
    print(build(**kw),end="")
