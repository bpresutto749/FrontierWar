;redcode-94
;name pt5
;assert CORESIZE==8000
        org    p
p       ldp.ab #0,    res
        ldp.ab #2,    cnt
        add.ab #1,    cnt
        stp.b  cnt,   #2
        seq.ab #1,    cnt
        jmp    chk
        jmp    paper
chk     slt.ab #3,    res
        jmp    paper
        dat    #0, #0
cnt     dat    #0, #0
res     dat    #0, #0
paper   spl 1, <300
        spl 1, <150
        spl 1, <450
silk1   spl @0, }284
        mov.i }silk1, >silk1
silk2   spl @0, }7805
        mov.i }silk2, >silk2
        mov.i {silk1, <silkj
silkj   jmp @0, >5104
