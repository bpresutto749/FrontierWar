;redcode-94
;name Gravel
;author Barthelemy Presutto
;strategy mod-5 dat stone then self-gated core clear
;assert CORESIZE==8000
step    equ     3315
gate    dat     0,      8
ptr     dat     #0,     #step
loop    mov.i   bomb,   @ptr
        add.ab  #step,  ptr
        djn.b   loop,   #1599
clr     mov.i   bomb,   >gate
bomb    dat     >2667,  #8
        jmp     clr,    0
        end     loop
