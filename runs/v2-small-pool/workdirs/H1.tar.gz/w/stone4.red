;redcode-94
;name Gravel
;author Barthelemy Presutto
;strategy mod-5 dat stone then self-gated core clear
;assert CORESIZE==8000
step    equ     3315
gate    dat     0,      9
clr     mov.i   bomb,   >gate
        jmp     clr,    0
ptr     dat     #0,     #step
loop    mov.i   bomb,   @ptr
        add.ab  #step,  ptr
        djn.b   loop,   #1599
        jmp     clr,    0
bomb    dat     >2667,  #9
        end     loop
