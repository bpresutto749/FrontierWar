;redcode-94
;name Origami Gravel
;author Barthelemy Presutto
;strategy p-space switch on loss between silk paper and mod-5 stone
;assert CORESIZE==8000
res     dat     0,      0
strat   dat     0,      0
start   ldp.ab  #0,     res
        ldp.ab  #77,    strat
        jmn.b   keep,   res
        add.ab  #1,     strat
        mod.ab  #2,     strat
        stp.b   strat,  #77
keep    jmz.b   q0x,    strat
        jmp     sloop,  0
q0x    spl 1, <2034
        spl 1, <1989
        spl 1, <295
q0      spl 1647, 0
        mov.i >q0, }q0
q1      spl 2863, 0
        mov.i >q1, }q1
q2      spl 1622, 0
        mov.i >q2, }q2
        mov.i qbomb, @1319
        mov.i qbomb, <4379
        jmp q2, <q2
qbomb    dat >2667, >5334
step    equ     3315
gate    dat     0,      9
clr     mov.i   sbomb,  >gate
        jmp     clr,    0
ptr     dat     #0,     #step
sloop   mov.i   sbomb,  @ptr
        add.ab  #step,  ptr
        djn.b   sloop,  #1599
        jmp     clr,    0
sbomb   dat     >2667,  #9
        end     start
