;redcode-94
;name Sieve
;author Barthelemy Presutto
;strategy jmz scanner stunning finds with spl, then gated dat clear
;assert CORESIZE==8000
step    equ     3359
gate    dat     0,      0
ptr     dat     0,      step
scan    add.ab  #step,  ptr
        jmz.f   scan,   @ptr
        slt.ab  #last-ptr, ptr
        jmp     clear,  0
        mov.i   sb,     @ptr
        mov.i   sb,     <ptr
        jmp     scan,   0
clear   mov.ab  #last-gate+1, gate
cl      mov.i   db,     >gate
        jmp     cl,     0
sb      spl     #0,     0
db      dat     0,      last-gate+1
last    dat     0,      0
        end     scan
