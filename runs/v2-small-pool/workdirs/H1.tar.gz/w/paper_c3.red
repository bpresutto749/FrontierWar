;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        spl 1, <3318
        spl 1, <4279
        spl 1, <538
p0      spl 4152, 0
        mov.i >p0, }p0
p1      spl 2444, 0
        mov.i >p1, }p1
p2      spl 3517, 0
        mov.i >p2, }p2
        mov.i bomb, *2278
        mov.i bomb, {6190
        jmp p2, <p2
bomb    dat >2667, >5334
        end
