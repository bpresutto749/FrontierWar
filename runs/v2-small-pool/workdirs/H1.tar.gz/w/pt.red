;redcode-94
;name pt
;assert 1
res     dat     0,      0
start   ldp.ab  #5,     res
        jmn.b   die,    res
        stp.b   #3,     #5
loop    jmp     loop
die     dat     0,      0
        end     start
