;redcode-94
;name idle
;assert 1
loop    jmp     loop
