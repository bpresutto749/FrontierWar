;redcode-94
;name Sieve
;author Barthelemy Presutto
;strategy jmz scanner into gated dat clear
;assert CORESIZE==8000
step    equ     3044
gate    dat     0,      100
scan    add.ab  #step,  gate
        jmz.f   scan,   @gate
        slt.ab  #9,     gate
        jmp     scan,   0
clr     spl     #0,     0
        mov.i   dbomb,  >gate
        jmp     -1,     0
dbomb   dat     0,      9
        end     scan
