;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk-style replicator with bombing
;assert CORESIZE==8000
d1      equ     2317
d2      equ     5623
d3      equ     1499
        spl     1,      <-411
        spl     1,      <-823
        spl     1,      <-1231
p1      spl     d1,     0
        mov.i   >p1,    }p1
p2      spl     d2,     0
        mov.i   >p2,    }p2
        mov.i   bomb,   >d3
        mov.i   bomb,   }d3+7
        jmp     p1,     <p1
bomb    dat     >2667,  >5334
        end
