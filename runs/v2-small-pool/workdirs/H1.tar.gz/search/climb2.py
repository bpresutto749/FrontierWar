import random, sys, json, copy, re
from concurrent.futures import ThreadPoolExecutor
sys.argv_saved = list(sys.argv)
seed = int(sys.argv[1]); rounds = int(sys.argv[2]); BESTF = sys.argv[3]; STARTF = sys.argv[4]
sys.argv = ['x', '0', '0', '/dev/null']
exec(open('/tmp/arena_H1/search/gen_paper2.py').read().split('if __name__')[0])
R2 = random.Random(seed)
best = json.loads(open(STARTF).read())
def mutate(p):
    q = copy.deepcopy(p)
    for _ in range(R2.choice([1, 1, 2])):
        k = R2.choice(['d', 'd', 'b', 'b', 'bm', 'bt', 'jt', 'addb', 'delb', 'nspl', 'dsmall', 'bsmall'])
        if k == 'd':
            q['d'][R2.randrange(len(q['d']))] = R2.randint(200, 7800)
        elif k == 'dsmall':
            i = R2.randrange(len(q['d'])); q['d'][i] = (q['d'][i] + R2.randint(-60, 60)) % 8000
        elif k == 'b':
            q['b'][R2.randrange(len(q['b']))][0] = R2.randint(200, 7800)
        elif k == 'bsmall':
            i = R2.randrange(len(q['b'])); q['b'][i][0] = (q['b'][i][0] + R2.randint(-60, 60)) % 8000
        elif k == 'bm':
            q['b'][R2.randrange(len(q['b']))][1] = R2.choice(['>', '}', '<', '{', '@', '*'])
        elif k == 'bt':
            q['bt'][1] = R2.randint(0, len(BOMBS) - 1)
            if R2.random() < 0.5: q['b'][R2.randrange(len(q['b']))][2] = R2.randint(0, 1)
        elif k == 'jt':
            q['jt'] = R2.randint(0, len(q['d']) - 1)
        elif k == 'addb' and len(q['b']) < 4:
            q['b'].append([R2.randint(200, 7800), R2.choice(['>', '}', '<', '{', '@', '*']), R2.randint(0, 1)])
        elif k == 'delb' and len(q['b']) > 1:
            q['b'].pop(R2.randrange(len(q['b'])))
        elif k == 'nspl':
            q['nspl'] = R2.choice([2, 3, 4])
    return q
bs, _, _ = ev(best, rounds)
print("start", bs, flush=True)
while True:
    cands = [mutate(best) for _ in range(3)]
    with ThreadPoolExecutor(3) as ex:
        res = list(ex.map(lambda c: ev(c, rounds), cands))
    for s, p, so in res:
        with open(BESTF + ".all", "a") as f:
            f.write(json.dumps({'s': s, 'p': p}) + "\n")
    s, p, so = max(res, key=lambda t: t[0])
    if s >= bs:
        bs, best = s, p
        open(BESTF, 'w').write(json.dumps({'s': bs, 'p': best}))
        print("improve", bs, json.dumps(best), flush=True)
