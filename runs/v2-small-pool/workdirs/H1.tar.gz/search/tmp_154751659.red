;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        spl 1, <6219
        spl 1, <1083
        spl 1, <2719
p0      spl 589, 0
        mov.i >p0, }p0
p1      spl 2711, 0
        mov.i >p1, }p1
        mov.i bomb, >6595
        mov.i bomb, @1888
        mov.i bomb, }7742
        jmp p1, <p1
bomb    dat >2667, >5334
        end
