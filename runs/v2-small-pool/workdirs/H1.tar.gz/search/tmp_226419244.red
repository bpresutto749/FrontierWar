;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        spl 1, <1367
        spl 1, <309
        spl 1, <4022
p0      spl 3793, 0
        mov.i >p0, }p0
p1      spl 6629, 0
        mov.i >p1, }p1
        mov.i bomb, @2787
        mov.i bomb, {3784
        jmp p1, <p1
bomb    dat >2667, >5334
        end
