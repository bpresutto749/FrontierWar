import random, sys, subprocess, re, json, os
from concurrent.futures import ThreadPoolExecutor
R = random.Random(int(sys.argv[1]))
N = int(sys.argv[2])
out = sys.argv[3]
BOMBS = ["dat >2667, >5334", "dat <2667, <5334", "spl #0, 0", "dat #0, #0", "dat }1, >1", "mov.i #1, -1"]
def paper(p):
    L = [";redcode-94", ";name Origami", ";author Barthelemy Presutto", ";strategy silk paper", ";assert CORESIZE==8000"]
    for k in range(p['nspl']):
        L += ["        spl 1, <%d" % p['s'][k]]
    for i, d in enumerate(p['d']):
        L += ["p%d      spl %d, 0" % (i, d), "        mov.i >p%d, }p%d" % (i, i)]
    for b, m, w in p['b']:
        L += ["        mov.i bomb%d, %s%d" % (w, m, b)]
    L += ["        jmp p%d, <p%d" % (p['jt'], p['jt'])]
    for w in range(2):
        L += ["bomb%d   %s" % (w, BOMBS[p['bt'][w]])]
    L += ["        end"]
    return "\n".join(L) + "\n"
def rnd():
    ns = R.choice([2, 3, 3, 4])
    nb = R.choice([1, 2, 2, 3])
    return {'nspl': R.choice([3, 3, 4]), 's': [R.randint(100, 7900) for _ in range(4)],
            'd': [R.randint(200, 7800) for _ in range(ns)],
            'b': [(R.randint(200, 7800), R.choice(['>', '}', '<', '{', '@', '*']), R.randint(0, 1)) for _ in range(nb)],
            'jt': R.choice([ns - 1, ns - 1, R.randint(0, ns - 1)]), 'bt': [0, R.randint(0, len(BOMBS) - 1)]}
def ev(p, rounds=100):
    src = paper(p)
    import uuid; fn = "/tmp/arena_H1/search/tmp2_%s.red" % uuid.uuid4().hex
    open(fn, "w").write(src)
    r = subprocess.run(["python3", "/tmp/arena_H1/tools/spar.py", fn, "--rounds", str(rounds)], capture_output=True, text=True)
    m = re.search(r"MEAN\s+([0-9.]+)", r.stdout)
    os.remove(fn)
    return (float(m.group(1)) if m else -1, p, r.stdout)
if __name__ == "__main__":
    ps = [rnd() for _ in range(N)]
    with ThreadPoolExecutor(3) as ex:
        for s, p, so in ex.map(ev, ps):
            with open(out, "a") as f:
                f.write(json.dumps({'s': s, 'p': p}) + "\n")
