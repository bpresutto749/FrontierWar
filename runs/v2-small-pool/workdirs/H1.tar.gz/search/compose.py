import json, sys
def paper_lines(p, pre="q"):
    L = ["%s0x    spl 1, <%d" % (pre, p['s1']), "        spl 1, <%d" % p['s2'], "        spl 1, <%d" % p['s3']]
    for i, d in enumerate(p['d']):
        L += ["%s%d      spl %d, 0" % (pre, i, d), "        mov.i >%s%d, }%s%d" % (pre, i, pre, i)]
    for b, m in p['b']:
        L += ["        mov.i %sbomb, %s%d" % (pre, m, b)]
    L += ["        jmp %s%d, <%s%d" % (pre, p['jt'], pre, p['jt'])]
    L += ["%sbomb    dat >2667, >5334" % pre]
    return L
STONE = """step    equ     3315
gate    dat     0,      9
clr     mov.i   sbomb,  >gate
        jmp     clr,    0
ptr     dat     #0,     #step
sloop   mov.i   sbomb,  @ptr
        add.ab  #step,  ptr
        djn.b   sloop,  #1599
        jmp     clr,    0
sbomb   dat     >2667,  #9""".split("\n")
def switcher(p, pc=77):
    L = [";redcode-94", ";name Origami Gravel", ";author Barthelemy Presutto", ";strategy p-space switch on loss between silk paper and mod-5 stone", ";assert CORESIZE==8000"]
    L += ["res     dat     0,      0",
          "strat   dat     0,      0",
          "start   ldp.ab  #0,     res",
          "        ldp.ab  #%d,    strat" % pc,
          "        jmn.b   keep,   res",
          "        add.ab  #1,     strat",
          "        mod.ab  #2,     strat",
          "        stp.b   strat,  #%d" % pc,
          "keep    jmz.b   q0x,    strat",
          "        jmp     sloop,  0"]
    L += paper_lines(p)
    L += STONE
    L += ["        end     start"]
    return "\n".join(L) + "\n"
if __name__ == "__main__":
    p = json.loads(sys.argv[1])
    sys.stdout.write(switcher(p))
