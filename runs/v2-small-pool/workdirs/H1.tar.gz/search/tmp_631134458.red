;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        spl 1, <1957
        spl 1, <3237
        spl 1, <2824
p0      spl 5287, 0
        mov.i >p0, }p0
p1      spl 5902, 0
        mov.i >p1, }p1
p2      spl 4055, 0
        mov.i >p2, }p2
        mov.i bomb, }1046
        jmp p1, <p1
bomb    dat >2667, >5334
        end
