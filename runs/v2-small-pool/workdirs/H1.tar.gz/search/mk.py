import sys, json
sys_argv = list(sys.argv)
sys.argv = ['x', '0', '0', '/dev/null']
exec(open('/tmp/arena_H1/search/gen_paper2.py').read().split('if __name__')[0])
d = json.loads(open(sys_argv[1]).read())
p = d.get('p', d)
open(sys_argv[2], 'w').write(paper(p))
