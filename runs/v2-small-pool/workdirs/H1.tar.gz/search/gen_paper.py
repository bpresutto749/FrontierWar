import random, sys, subprocess, re, json, os
from concurrent.futures import ThreadPoolExecutor
R = random.Random(int(sys.argv[1]))
N = int(sys.argv[2])
out = sys.argv[3]
def paper(p):
    L = [";redcode-94", ";name Origami", ";author Barthelemy Presutto", ";strategy silk paper", ";assert CORESIZE==8000"]
    L += ["        spl 1, <%d" % p['s1'], "        spl 1, <%d" % p['s2'], "        spl 1, <%d" % p['s3']]
    for i, d in enumerate(p['d']):
        L += ["p%d      spl %d, 0" % (i, d), "        mov.i >p%d, }p%d" % (i, i)]
    for b, m in p['b']:
        L += ["        mov.i bomb, %s%d" % (m, b)]
    L += ["        jmp p%d, <p%d" % (p['jt'], p['jt'])]
    L += ["bomb    dat >2667, >5334", "        end"]
    return "\n".join(L) + "\n"
def rnd():
    ns = R.choice([2, 3, 3])
    nb = R.choice([1, 2, 2, 3])
    return {'s1': R.randint(100, 7900), 's2': R.randint(100, 7900), 's3': R.randint(100, 7900),
            'd': [R.randint(200, 7800) for _ in range(ns)],
            'b': [(R.randint(200, 7800), R.choice(['>', '}', '<', '{', '@', '*'])) for _ in range(nb)],
            'jt': R.randint(0, ns - 1)}
def ev(p):
    src = paper(p)
    fn = "/tmp/arena_H1/search/tmp_%d.red" % (abs(hash(json.dumps(p))) % 10**9)
    open(fn, "w").write(src)
    r = subprocess.run(["python3", "/tmp/arena_H1/tools/spar.py", fn, "--rounds", "100"], capture_output=True, text=True)
    m = re.search(r"MEAN\s+([0-9.]+)", r.stdout)
    os.remove(fn)
    return (float(m.group(1)) if m else -1, p, r.stdout)
ps = [rnd() for _ in range(N)]
with ThreadPoolExecutor(4) as ex:
    for s, p, so in ex.map(ev, ps):
        with open(out, "a") as f:
            f.write(json.dumps({'s': s, 'p': p}) + "\n")
