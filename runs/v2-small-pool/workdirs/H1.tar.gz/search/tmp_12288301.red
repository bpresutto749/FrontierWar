;redcode-94
;name Origami
;author Barthelemy Presutto
;strategy silk paper
;assert CORESIZE==8000
        spl 1, <5148
        spl 1, <5098
        spl 1, <2527
p0      spl 4968, 0
        mov.i >p0, }p0
p1      spl 7750, 0
        mov.i >p1, }p1
p2      spl 7068, 0
        mov.i >p2, }p2
        mov.i bomb, <4223
        mov.i bomb, >7421
        jmp p0, <p0
bomb    dat >2667, >5334
        end
