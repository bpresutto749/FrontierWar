import sys
E=int(sys.argv[1]) if len(sys.argv)>1 else 24
LP=int(sys.argv[3]) if len(sys.argv)>3 else 1
out=sys.argv[2] if len(sys.argv)>2 else "sw3.red"
SA=2664
sel=f"""sel     ldp.ab  #0,   res
        ldp.ab  #1,   cnt
        ldp.ab  #2,   cur
        mov.b   cur,  idx
        add.ab  #3,   idx
        ldp.b   idx,  sc
        sne.ab  #1,   res
        add.ab  #3,   sc
        sne.ab  #2,   res
        add.ab  #1,   sc
        sne.ab  #0,   res
        sub.ab  #{LP},  sc
        slt.ab  #4000, sc
        jmp     okk,  0
        mov.ab  #0,   sc
okk     stp.b   sc,   idx
        add.ab  #1,   cnt
        stp.b   cnt,  #1
        slt.ab  #{E},  cnt
        jmp     explr, 0
        ldp.ab  #3,   s0
        ldp.ab  #4,   s1
        ldp.ab  #5,   s2
        mov.ab  #0,   cur
        mov.b   s0,   bv
        slt.b   bv,   s1
        jmp     c2,   0
        mov.ab  #1,   cur
        mov.b   s1,   bv
c2      slt.b   bv,   s2
        jmp     go,   0
        mov.ab  #2,   cur
        jmp     go,   0
explr   mov.b   cnt,  cur
        sub.ab  #1,   cur
        mod.ab  #3,   cur
go      stp.b   cur,  #2
        jmz.b   boota, cur
        sne.ab  #1,   cur
        jmp     bootb, 0
        jmp     pgo,  0
res     dat     0,    0
cnt     dat     0,    0
cur     dat     0,    0
idx     dat     0,    0
sc      dat     0,    0
s0      dat     0,    0
s1      dat     0,    0
s2      dat     0,    0
bv      dat     0,    0
"""
paper="""pgo     spl  1,     0
        spl  1,     0
        spl  1,     0
p1      spl  @0,    3620
        mov.i }p1,  >p1
p2      spl  @0,    -1850
        mov.i }p2,  >p2
        mov.i pbmb, >2667
        mov.i {p2,  <p2
        jmp   p1,   0
pbmb    dat   >2667, >5334
"""
osa=f"""gatea   dat   0,     0
scana   add.ab #{-SA},  gatea
        jmz.f  scana, @gatea
        sub.ab #12,  gatea
        spl    #0,   0
mva     mov.i  bomba, >gatea
        djn.f  mva,  >gatea
bomba   dat    0,    bomba-gatea
"""
osb=f"""scanb   add.ab #{SA},  gateb
        jmz.f  scanb, @gateb
        add.ab #13,  gateb
        spl    #0,   0
mvb     mov.i  bombb, <gateb
        djn.f  mvb,  <gateb
bombb   dat    0,    -8
gateb   dat    0,    0
"""
def lines(s): return [l for l in s.split("\n") if l.strip()]
L_sel=len(lines(sel)); L_p=len(lines(paper))
# layout: sel, paper, boota(9), osa(8), bootb(9), osb(8)
start_boota=L_sel+L_p
pos_osa=start_boota+9
start_bootb=pos_osa+8
pos_osb=start_bootb+9
total=pos_osb+8
def pick(S,gate_off):
    cells=range(0,total)
    best=None
    for BD in range(300,7700):
        # new region must not overlap original
        rel=set(((c-gate_off-BD)%8000) for c in cells)
        first=1001
        for k in range(1,1001):
            if (k*S)%8000 in rel: first=k;break
        if best is None or first>best[0]: best=(first,BD)
    return best
fa,BDa=pick(-SA,pos_osa)
fb,BDb=pick(SA,pos_osb+7)
sys.stderr.write(f"BDa={BDa} first={fa}  BDb={BDb} first={fb} total={total}\n")
boota="\n".join(("boota" if i==0 else "     ")+f"   mov.i  gatea+{i}, gatea+{BDa+i}" for i in range(8))+f"\n        jmp    scana+{BDa}, 0\n"
bootb="\n".join(("bootb" if i==0 else "     ")+f"   mov.i  scanb+{i}, scanb+{BDb+i}" for i in range(8))+f"\n        jmp    scanb+{BDb}, 0\n"
src=""";redcode-94
;name Tri-Switch
;author anon
;strategy p-space: explore three strategies round-robin, then commit to the best scorer
;strategy strategies: booted forward-clear oneshot, booted backward-clear oneshot, silk paper
        org   sel
"""+sel+paper+boota+osa+bootb+osb
open(out,"w").write(src)
