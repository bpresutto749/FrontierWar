;redcode-94
;name Oneshot E
;author anon
;strategy 0.5c jmz scan, then backward djn d-clear
S       equ   3048
        org   scan
scan    add.ab #S,   gate
        jmz.f  scan, @gate
        add.ab #13,  gate
clr     spl    #0,   0
mv      mov.i  bomb, <gate
        djn.f  mv,   <gate
bomb    dat    0,    -8
gate    dat    0,    0
