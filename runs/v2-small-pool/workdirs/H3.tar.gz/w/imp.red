;redcode-94
;name imp
;author x
imp mov.i #0, 1
