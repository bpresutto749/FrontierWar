;redcode-94
;name Oneshot D
;author anon
;strategy 0.5c jmz scan, then two-pass spl/dat djn clear
S       equ   3048
        org   scan
gate    dat   sb-gate, 0
scan    add.ab #S,   gate
        jmz.f  scan, @gate
        sub.ab #12,  gate
clr     spl    #0,   0
mv      mov.i  *gate, >gate
        djn.f  mv,   >gate
db      dat    db-gate, sb-gate
sb      spl    #db-gate, sb-gate
