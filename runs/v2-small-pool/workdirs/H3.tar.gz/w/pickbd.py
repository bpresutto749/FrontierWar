import sys
S=int(sys.argv[1]); lo=int(sys.argv[2]); hi=int(sys.argv[3])  # idle cells rel. to orig gate: lo..hi
best=[]
for BD in range(300,7700):
    cells=set(((c-BD)%8000) for c in range(lo,hi+1))
    first=None
    for k in range(1,1001):
        p=(k*S)%8000
        if p in cells: first=k;break
    best.append((first or 1001,BD))
best.sort(reverse=True)
print(best[:15])
