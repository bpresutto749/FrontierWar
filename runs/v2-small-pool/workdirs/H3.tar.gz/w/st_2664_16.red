;redcode-94
;name Stunner
;author anon
;strategy 0.5c scan, spl-stun each find, then forward d-clear
        org   scan
gate    dat    0,     0
scan    add.ab #2664,  gate
        jmz.f  scan,  @gate
        mov.i  sbomb, >gate
        mov.i  sbomb, >gate
        mov.i  sbomb, @gate
        sub.ab #2,    gate
        djn.b  scan,  #16
        sub.ab #12,   gate
        spl    #0,    0
mv      mov.i  dbomb, >gate
        djn.f  mv,    >gate
dbomb   dat    0,     dbomb-gate+1
sbomb   spl    #0,    0
