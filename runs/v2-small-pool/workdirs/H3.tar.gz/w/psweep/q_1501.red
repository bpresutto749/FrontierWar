;redcode-94
;name Silkworm
;author anon
;strategy silk paper with imp-ish bombing
        org  go
go      spl  1,     0
        spl  1,     0
        spl  1,     0
p1      spl  @0,    3620
        mov.i }p1,  >p1
p2      spl  @0,    -1850
        mov.i }p2,  >p2
        mov.i bmb,  >1501
        mov.i {p2,  <p2
        jmp   p1, 0
bmb     dat   >2667, >5334
