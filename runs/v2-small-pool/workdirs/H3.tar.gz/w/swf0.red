;redcode-94
;name Switchblade
;author anon
;strategy p-space switch on loss: forward-clear oneshot, backward-clear oneshot, silk paper
SA      equ   2664
        org   sel
; --- W1: backward clear oneshot (bottom) ---
scan5   add.ab #SA,  gate5
        jmz.f  scan5, @gate5
        add.ab #13,  gate5
        spl    #0,   0
mv5     mov.i  bomb5, <gate5
        djn.f  mv5,  <gate5
bomb5   dat    0,    -8
gate5   dat    0,    0
; --- selector ---
sel     ldp.ab  #0,   res
        ldp.ab  #1,   st
        sne.ab  #0,   res
        add.ab  #1,   st
        mod.ab  #3,   st
        stp.b   st,   #1
        jmp     scan2, 0
        sne.ab  #1,   st
        jmp     scan5
        jmp     pgo
res     dat     0,    0
st      dat     0,    0
; --- W2: paper ---
pgo     spl  1,     0
        spl  1,     0
        spl  1,     0
p1      spl  @0,    3620
        mov.i }p1,  >p1
p2      spl  @0,    -1850
        mov.i }p2,  >p2
        mov.i pbmb, >2667
        mov.i {p2,  <p2
        jmp   p1,   0
pbmb    dat   >2667, >5334
; --- W0: forward clear oneshot (top) ---
gate2   dat   0,     0
scan2   add.ab #-SA, gate2
        jmz.f  scan2, @gate2
        sub.ab #12,  gate2
        spl    #0,   0
mv2     mov.i  bomb2, >gate2
        djn.f  mv2,  >gate2
bomb2   dat    0,    bomb2-gate2
