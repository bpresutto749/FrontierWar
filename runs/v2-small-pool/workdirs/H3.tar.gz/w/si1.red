;redcode-94
;name Stone Ring A
;author anon
;strategy mod-4 stone plus 3-point imp ring
STEP    equ   3364
IS      equ   2667
        org   start
start   spl   s1,     0
        spl   a2,     0
        spl   a3,     0
        jmp   imp+IS, 0
a2      jmp   imp,    0
a3      jmp   imp+2*IS, 0
s1      add.ab #STEP, sp
        mov.i  sbomb, @sp
        jmp    s1,    0
sp      dat    0,     0
sbomb   dat    0,     0
        for 10
        dat 0,0
        rof
imp     mov.i  #0,    IS
