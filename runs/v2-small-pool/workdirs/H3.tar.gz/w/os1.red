;redcode-94
;name Oneshot A
;author anon
;strategy 0.5c jmz scan, then forward d-clear
S       equ   3048
        org   scan
gate    dat   0,     0
scan    add.ab #S,   gate
        jmz.f  scan, @gate
        sub.ab #12,  gate
clr     spl    #0,   0
mv      mov.i  bomb, >gate
        jmp    mv,   0
bomb    dat    0,    bomb-gate
