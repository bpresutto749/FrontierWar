;redcode-94
;name Switchblade II
;author anon
;strategy p-space switch on loss: booted oneshot scanner / silk paper
SA      equ   -2664
        org   sel
sel     ldp.ab  #0,   res
        ldp.ab  #1,   st
        sne.ab  #0,   res
        add.ab  #1,   st
        mod.ab  #2,   st
        stp.b   st,   #1
        jmz.b   boot, st
        jmp     pgo,  0
res     dat     0,    0
st      dat     0,    0
pgo     spl  1,     0
        spl  1,     0
        spl  1,     0
p1      spl  @0,    3620
        mov.i }p1,  >p1
p2      spl  @0,    -1850
        mov.i }p2,  >p2
        mov.i pbmb, >2667
        mov.i {p2,  <p2
        jmp   p1,   0
pbmb    dat   >2667, >5334
boot    mov.i  gate2+0, gate2+5336
        mov.i  gate2+1, gate2+5337
        mov.i  gate2+2, gate2+5338
        mov.i  gate2+3, gate2+5339
        mov.i  gate2+4, gate2+5340
        mov.i  gate2+5, gate2+5341
        mov.i  gate2+6, gate2+5342
        mov.i  gate2+7, gate2+5343
        jmp    scan2+5336, 0
gate2   dat   0,     0
scan2   add.ab #SA,  gate2
        jmz.f  scan2, @gate2
        sub.ab #12,  gate2
        spl    #0,   0
mv2     mov.i  bomb2, >gate2
        djn.f  mv2,  >gate2
bomb2   dat    0,    bomb2-gate2
