#!/bin/bash
# usage: sweep.sh file...  -> prints mean score per file
for f in "$@"; do
  ( r=$(python3 /tmp/arena_H3/tools/spar.py $f --rounds 500 | awk '{printf "%s ", $NF}'); echo "$(basename $f) $r" ) &
done
wait
