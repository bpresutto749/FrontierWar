import sys, json
E=int(sys.argv[1]); out=sys.argv[2]; LP=int(sys.argv[3]); P=json.loads(sys.argv[4]) if len(sys.argv)>4 else {}
Sa=P.get("Sa",-2664); OFFa=P.get("offa",24); Sb=P.get("Sb",2664); CNT=P.get("cnt",16)
PA=P.get("pa",3620); PB=P.get("pb",-1850); PC=P.get("pc",2667)
sel=f"""sel     ldp.ab  #0,   res
        ldp.ab  #1,   cnt
        ldp.ab  #2,   cur
        mov.b   cur,  idx
        add.ab  #3,   idx
        ldp.b   idx,  sc
        sne.ab  #1,   res
        add.ab  #3,   sc
        sne.ab  #2,   res
        add.ab  #1,   sc
        sne.ab  #0,   res
        sub.ab  #{LP},  sc
        slt.ab  #4000, sc
        jmp     okk,  0
        mov.ab  #0,   sc
okk     stp.b   sc,   idx
        add.ab  #1,   cnt
        stp.b   cnt,  #1
        slt.ab  #{E},  cnt
        jmp     explr, 0
        ldp.ab  #3,   s0
        ldp.ab  #4,   s1
        ldp.ab  #5,   s2
        mov.ab  #0,   cur
        slt.b   s0,   s1
        jmp     c2,   0
        mov.ab  #1,   cur
        mov.b   s1,   s0
c2      slt.b   s0,   s2
        jmp     go,   0
        mov.ab  #2,   cur
        jmp     go,   0
explr   mov.b   cnt,  cur
        sub.ab  #1,   cur
        mod.ab  #3,   cur
go      stp.b   cur,  #2
        jmz.b   boota, cur
        sne.ab  #1,   cur
        jmp     bootb, 0
        jmp     pgo,  0
res     dat     0,    0
cnt     dat     0,    0
cur     dat     0,    0
idx     dat     0,    0
sc      dat     0,    0
s0      dat     0,    0
s1      dat     0,    0
s2      dat     0,    0
"""
paper=f"""pgo     spl  1,     0
        spl  1,     0
        spl  1,     0
p1      spl  @0,    {PA}
        mov.i }}p1,  >p1
p2      spl  @0,    {PB}
        mov.i }}p2,  >p2
        mov.i pbmb, >{PC}
        mov.i {{p2,  <p2
        jmp   p1,   0
pbmb    dat   >2667, >5334
"""
osa=f"""gatea   dat   0,     0
scana   add.ab #{Sa},  gatea
        jmz.f  scana, @gatea
        sub.ab #{OFFa},  gatea
        spl    #0,   0
mva     mov.i  bomba, >gatea
        djn.f  mva,  >gatea
bomba   dat    0,    bomba-gatea
"""
osb=f"""gateb   dat    0,     0
scanb   add.ab #{Sb},  gateb
        jmz.f  scanb,  @gateb
        mov.i  sbombb, >gateb
        mov.i  sbombb, >gateb
        mov.i  sbombb, @gateb
        sub.ab #2,    gateb
        djn.b  scanb,  #{CNT}
        sub.ab #12,   gateb
        spl    #0,    0
mvb     mov.i  dbombb, >gateb
        djn.f  mvb,    >gateb
dbombb  dat    0,     dbombb-gateb+1
sbombb  spl    #0,    0
"""
def n(s): return len([l for l in s.split("\n") if l.strip()])
La, Lb = n(osa), n(osb)
# layout: sel, paper, boota(4), osa, bootb(4), osb
pos_boota=n(sel)+n(paper); pos_osa=pos_boota+4; pos_bootb=pos_osa+La; pos_osb=pos_bootb+4; total=pos_osb+Lb
def pick(S,gate_off,L):
    best=None
    for BD in range(400,7600):
        rel=set(((c-gate_off-BD)%8000) for c in range(total))
        if any(((gate_off+BD+j)%8000) in set(range(total)) for j in range(L)): continue
        first=1001
        for k in range(1,1001):
            if (k*S)%8000 in rel: first=k;break
        if best is None or first>best[0]: best=(first,BD)
    return best
fa,BDa=pick(Sa,pos_osa,La); fb,BDb=pick(Sb,pos_osb,Lb)
sys.stderr.write(f"BDa={BDa} first={fa} BDb={BDb} first={fb} total={total}\n")
boota=f"""boota   mov.i  }}bpa, >bpa
        djn.b  boota, #{La}
        jmp    scana+{BDa}, 0
bpa     dat    gatea-bpa, gatea+{BDa}-bpa
"""
bootb=f"""bootb   mov.i  }}bpb, >bpb
        djn.b  bootb, #{Lb}
        jmp    scanb+{BDb}, 0
bpb     dat    gateb-bpb, gateb+{BDb}-bpb
"""
src=""";redcode-94
;name Tri-Switch II
;author anon
;strategy p-space: explore three strategies round-robin, then commit to the best scorer
;strategy strategies: booted forward-clear oneshot, booted spl-stun scanner, silk paper
        org   sel
"""+sel+paper+boota+osa+bootb+osb
open(out,"w").write(src)
