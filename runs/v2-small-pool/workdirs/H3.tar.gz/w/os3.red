;redcode-94
;name Oneshot C
;author anon
;strategy 0.5c jmz scan, then two-pass spl/dat clear
S       equ   3048
        org   scan
gate    dat   sb-gate, 0
scan    add.ab #S,   gate
        jmz.f  scan, @gate
        sub.ab #12,  gate
clr     spl    #0,   0
mv      mov.i  *gate, >gate
        jmp    mv,   0
db      dat    db-gate, sb-gate
sb      spl    #db-gate, sb-gate
