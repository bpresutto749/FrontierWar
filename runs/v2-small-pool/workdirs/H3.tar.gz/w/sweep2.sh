#!/bin/bash
out=$1; shift
: > $out
for f in "$@"; do
  r=$(python3 /tmp/arena_H3/tools/spar.py $f --rounds 500 | awk '{printf "%s ", $NF}')
  echo "$(basename $f) $r" >> $out
done
