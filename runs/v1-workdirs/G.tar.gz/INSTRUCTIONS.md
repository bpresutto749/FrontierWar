# Write a Core War warrior

Write a Redcode warrior and save it as `submission.red` in this directory.

## How it is scored

Your warrior plays a hidden hill of 30 human-written competitive warriors
(taken from the public history of the ICWS '94 King-of-the-Hill, ranging from
mid-strength to among the strongest ever submitted). Against each hill warrior
it plays 100 rounds with pMARS 0.9.4 in standard '94 settings: coresize 8000,
80000 cycles, 8000 processes, max warrior length 100, min distance 100,
ICWS '94 instruction set with the pMARS extensions (p-space is allowed).

Per round: win = 3 points, tie = 1, loss = 0. The reward is your mean points
per round over the whole hill divided by 3, so 1.0 means you won every round.
A file that does not assemble scores 0. pMARS hangs on very long source lines, so
comment lines are cut to 200 characters and a code line longer than 200
characters makes the file invalid.

## What you have

- `bin/pmars` — the exact simulator used for scoring (`bin/pmars -h`).
- `doc/` — the Redcode language reference (opcodes, modifiers, addressing modes,
  p-space), the ICWS '94 draft standard and the pMARS manual. It contains no
  strategy guides.
- `sparring/` — 10 public warriors of the same kind as the hidden hill. None of
  them is on the hidden hill.
- `tools/battle.py` — `python3 tools/battle.py submission.red` battles your
  warrior against the sparring pool with the scoring rules above.

Original work only: a near-copy of a published warrior (the sparring pool or
any of about 580 public warriors in our corpus) scores 0. Using published ideas
and techniques is fine; submitting someone else's warrior is not.

You have a wall-clock budget of 45 minutes. No internet access. Your score is
whatever `submission.red` contains at the end, so keep a valid one saved.

## Lessons from earlier attempts at this task

These come from the failure analysis of earlier agent runs on this exact task.

1. The sparring pool is 10 warriors: treat it as a small validation set, not as
   the test. In earlier runs, the agent that pushed its sparring score highest
   (above a strong human warrior's score on the same pool) did worst on the
   hidden hill. Do not keep tuning constants once differences are within noise.
2. Build your own wider test set. Write simple warriors of each major archetype
   (stones that bomb with DAT and SPL, imp spirals and imp rings, silk-style
   papers, scanners, core clears, quick-scans) and check every candidate against
   them as well as the sparring pool, with random start positions (pMARS `-F`
   seeds or no `-f`) as well as the fixed series.
3. Competitive '94 hills have long been dominated by composites: a quick-scan
   opening followed by a stone/imp or paper body. Three of the four earlier
   agents submitted a lone scanner. On the sparring pool it lost most against the imp-based
   warriors (many ties and losses), and the agents named this weakness without
   fixing it.
4. Use the whole time budget. Earlier agents stopped after 8 to 28 of 45 minutes.
