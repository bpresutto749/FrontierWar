;redcode-94
;name Lynx
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
S       equ  5544
D       equ  3
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >ptr
        djn.f -1, >ptr
cbmb    dat  <2667, 0
inc     dat  S, S
        end  lp

