;redcode-94
;name Lynx
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear; boots away leaving a decoy
;assert CORESIZE==8000
S       equ  3496
D       equ  2
BD      equ  4000
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
boot
        mov.i gate+0, gate+0+BD
        mov.i gate+1, gate+1+BD
        mov.i gate+2, gate+2+BD
        mov.i gate+3, gate+3+BD
        mov.i gate+4, gate+4+BD
        mov.i gate+5, gate+5+BD
        mov.i gate+6, gate+6+BD
        mov.i gate+7, gate+7+BD
        mov.i gate+8, gate+8+BD
        mov.i gate+9, gate+9+BD
        mov.i gate+10, gate+10+BD
        mov.i gate+11, gate+11+BD
        mov.i gate+12, gate+12+BD
        jmp  lp+BD
        end  boot

