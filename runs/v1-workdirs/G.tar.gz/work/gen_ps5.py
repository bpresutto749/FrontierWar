import sys
sys.path.insert(0,'.')
from gen_ps3 import PB, PA, hdr
from gen_ps4 import SCAN
T3="""think   ldp.ab #0, res
        ldp.ab #PC, st
        jmz.b  tog, res
        seq.ab #2, res
        jmp    ok
        jmz.b  ok, st
tog     add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #PC
        jmz.b  lp, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
"""
T2="""think   ldp.ab #0, res
        ldp.ab #PC, st
        seq.ab #1, res
        slt.ab #3, res
        jmp    ok
tog     add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #PC
        jmz.b  lp, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
"""
def comp(S=3016, P0=4000, sb='spl  #0, 0', cb='<2667', paper='b', name='Lynx Folding', think=T3, pc=37):
    t=think.replace('#PC','#%d'%pc)
    return hdr(S,name,'p-space switch between a pair scanner and a silk paper')+SCAN.format(cb=cb,sb=sb,P0=P0)+(PB if paper=='b' else PA)+t+"        end  think\n"
if __name__=='__main__':
    open('v3b.red','w').write(comp(paper='b',think=T3))
    open('v3a.red','w').write(comp(paper='a',think=T3))
    open('v2b.red','w').write(comp(paper='b',think=T2))
    open('v2a.red','w').write(comp(paper='a',think=T2))
