;redcode-94
;name Lynx Folding
;author anon
;strategy p-space switch between a pair scanner (booted away) and a silk paper
;assert CORESIZE==8000
S       equ  3016
D       equ  2
PC      equ  37
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
        dat  0, 0
pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >3620
        mov.i }s1, >s1
s2      spl  1764, #0
        mov.i >s2, }s2
s3      spl  @0, >2391
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
think   ldp.ab #0, res
        ldp.ab #37, st
        jmz.b  tog, res
        seq.ab #2, res
        jmp    ok
        jmz.b  ok, st
tog     add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #37
        jmz.b  boot, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
boot
        mov.i gate+0, gate+0+5800
        mov.i gate+1, gate+1+5800
        mov.i gate+2, gate+2+5800
        mov.i gate+3, gate+3+5800
        mov.i gate+4, gate+4+5800
        mov.i gate+5, gate+5+5800
        mov.i gate+6, gate+6+5800
        mov.i gate+7, gate+7+5800
        mov.i gate+8, gate+8+5800
        mov.i gate+9, gate+9+5800
        mov.i gate+10, gate+10+5800
        mov.i gate+11, gate+11+5800
        mov.i gate+12, gate+12+5800
        jmp  lp+5800
        end  think
