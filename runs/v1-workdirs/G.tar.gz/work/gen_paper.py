import sys
def paper(name, D1, D2, D3, D4, D5, variant):
    hdr=f";redcode-94\n;name {name}\n;author anon\n;strategy paper\n;assert CORESIZE==8000\n"
    if variant=='a':
        body=f"""start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >{D1}
        mov.i }}s1, >s1
s2      spl  {D2}, #0
        mov.i >s2, }}s2
lp      mov.i bmb, >{D3}
        mov.i <{D4}, <{D5}
        djn.f lp, <{-D4}
bmb     dat  >5334, >2667
        end start
"""
    elif variant=='b':
        body=f"""start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >{D1}
        mov.i }}s1, >s1
s2      spl  {D2}, #0
        mov.i >s2, }}s2
s3      spl  @0, >{D3}
        mov.i }}s3, >s3
        mov.i <{D4}, <{D5}
        jmp  -1, <{-D4}
        end start
"""
    elif variant=='c':
        body=f"""start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >{D1}
        mov.i }}s1, >s1
s2      spl  {D2}, #0
        mov.i >s2, }}s2
lp      mov.i bmb, >{D3}
        mov.i bmb, }}{D4}
        jmp  lp, <{D5}
bmb     dat  >5334, >2667
        end start
"""
    return hdr+body
if __name__=='__main__':
    a=sys.argv[1:]
    print(paper(a[0],*map(int,a[1:6]),a[6]))
