#!/bin/bash
# usage: ev.sh warrior.red  -> sparring (fixed) + sparring random + own opps random
W=$1
cd /tmp/arena_G
python3 tools/battle.py $W | tail -1 | sed 's/MEAN/SPAR_FIXED/'
python3 tools/battle.py $W --vs work/opp/*.red | sed 's/^/  /'
