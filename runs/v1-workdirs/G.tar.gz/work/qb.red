;redcode-94
;name Lynx Folding
;author anon
;strategy p-space switch between a pair scanner and a silk paper
;assert CORESIZE==8000
S       equ  3288
D       equ  2
PC      equ  37
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.ab sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
        dat  0, 0
pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >2758
        mov.i }s1, >s1
s2      spl  1307, #0
        mov.i >s2, }s2
s3      spl  @0, >1704
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
think   ldp.ab #0, res
        ldp.ab #37, st
        jmz.b  tog, res
        seq.ab #2, res
        jmp    ok
        jmz.b  ok, st
tog     add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #37
        jmz.b  q0, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
q0      jmz.f  q1, gate+300
        mov.ab #gate+300-ptr-2, ptr
        jmp    top
q1      jmz.f  q2, gate+940
        mov.ab #gate+940-ptr-2, ptr
        jmp    top
q2      jmz.f  q3, gate+1580
        mov.ab #gate+1580-ptr-2, ptr
        jmp    top
q3      jmz.f  q4, gate+2220
        mov.ab #gate+2220-ptr-2, ptr
        jmp    top
q4      jmz.f  q5, gate+2860
        mov.ab #gate+2860-ptr-2, ptr
        jmp    top
q5      jmz.f  q6, gate+3500
        mov.ab #gate+3500-ptr-2, ptr
        jmp    top
q6      jmz.f  q7, gate+4140
        mov.ab #gate+4140-ptr-2, ptr
        jmp    top
q7      jmz.f  q8, gate+4780
        mov.ab #gate+4780-ptr-2, ptr
        jmp    top
q8      jmz.f  q9, gate+5420
        mov.ab #gate+5420-ptr-2, ptr
        jmp    top
q9      jmz.f  q10, gate+6060
        mov.ab #gate+6060-ptr-2, ptr
        jmp    top
q10      jmz.f  q11, gate+6700
        mov.ab #gate+6700-ptr-2, ptr
        jmp    top
q11      jmz.f  qend, gate+7340
        mov.ab #gate+7340-ptr-2, ptr
        jmp    top
qend    jmp    lp
        end  think
