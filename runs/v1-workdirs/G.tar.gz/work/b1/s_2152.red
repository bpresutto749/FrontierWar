;redcode-94
;name Lynx
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
S       equ  2152
D       equ  2
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
        end  lp

