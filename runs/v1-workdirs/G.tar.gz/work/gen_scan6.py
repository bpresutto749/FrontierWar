import sys
def scan(S=3016, D=2, P0=4000, sb='spl  #0, 0', cb='<2667', clr='spl  #0, 0', name='Lynx'):
    return f""";redcode-94
;name {name}
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
S       equ  {S}
D       equ  {D}
gate    dat  0, inc+1-gate
ptr     dat  0, {P0}
sbmb    {sb}
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     {clr}
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  {cb}, inc+1-gate
inc     dat  S, S
        end  lp
"""
V={
 'base':{},
 'd1':{'D':1},
 'p100':{'P0':100},
 'pm50':{'P0':-50},
 'sbdec':{'sb':'spl  #0, <-20'},
 'sbinc':{'sb':'spl  #0, >-20'},
 'cb5334':{'cb':'<5334'},
 'cbgt':{'cb':'>2667'},
 'clrdec':{'clr':'spl  #0, <-30'},
}
if __name__=='__main__':
    import os
    os.makedirs('b4',exist_ok=True)
    for k,v in V.items():
        open(f'b4/{k}.red','w').write(scan(**v))
