import sys
def scan(S, D, P0=4000, name='Lynx'):
    return f""";redcode-94
;name {name}
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
S       equ  {S}
D       equ  {D}
ptr     dat  0, {P0}
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >ptr
        djn.f -1, >ptr
cbmb    dat  <2667, 0
inc     dat  S, S
        end  lp
"""
if __name__=='__main__':
    print(scan(int(sys.argv[1]),int(sys.argv[2])))
