import sys
sys.path.insert(0,'.')
from gen_ps3 import PB, PA, hdr
from gen_ps4 import SCAN
from gen_ps5 import T3
def comp(S=3016, P0=4000, sb='spl  #0, 0', cb='<2667', paper='b', name='Lynx Folding', think=T3, pc=37, BD=4000):
    t=think.replace('#PC','#%d'%pc).replace('jmz.b  lp, st','jmz.b  boot, st')
    boot="boot\n"+"".join(f"        mov.i gate+{i}, gate+{i}+{BD}\n" for i in range(13))+f"        jmp  lp+{BD}\n"
    return hdr(S,name,'p-space switch between a pair scanner (booted away) and a silk paper')+SCAN.format(cb=cb,sb=sb,P0=P0)+(PB if paper=='b' else PA)+t+boot+"        end  think\n"
if __name__=='__main__':
    for bd in (2000,4000,5800):
        open(f'w_{bd}.red','w').write(comp(BD=bd))
