;redcode-94
;name Lynx
;author anon
;strategy fast pair scanner, spl burst on hit, then spl/dat clear
;assert CORESIZE==8000
S       equ  3504
D       equ  8
gate    dat  0, last+1-gate
ptr     dat  0, 0
sbmb    spl  #0, 0
lp      add.f inc, sc
sc      seq.i S, S+D
        jmp  fnd
        jmn.a lp, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, last+1-gate
inc     dat  S, S
fnd     jmz.a clr, sc
        mov.b sc, ptr
        mov.i sbmb, >ptr
        mov.i sbmb, >ptr
        mov.i sbmb, >ptr
        mov.i sbmb, >ptr
        mov.i sbmb, >ptr
last    jmp  lp
        end  lp

