;redcode-94
;name sit
;assert 1
l jmp 0
 dat 1,1
 dat 2,2
 dat 3,3
 dat 4,4
 dat 5,5
