;redcode-94
;name t_splstone
;assert 1
step equ 3044
st   spl  #0, <-10
lp   mov.i sb, @ptr
     mov.i db, *ptr
     add.f inc, ptr
     djn.f lp, <-400
sb   spl  #0, 0
db   dat  <2667, <5334
inc  dat  step, step
ptr  dat  step+100, step+102
     end st
