;redcode-94
;name P
;author anon
;strategy paper
;assert CORESIZE==8000
start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >2758
        mov.i }s1, >s1
s2      spl  1307, #0
        mov.i >s2, }s2
s3      spl  @0, >1704
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
        end start

