;redcode-94
;name t_imp
;assert 1
k equ 2667
L0   spl  L4
L1   spl  L3
     spl  L2b
     jmp  imp
L2b  jmp  imp+k
L3   spl  L3b
     jmp  imp+2*k
L3b  jmp  imp+3*k
L4   spl  L6
L5   spl  L5b
     jmp  imp+4*k
L5b  jmp  imp+5*k
L6   spl  L6b
     jmp  imp+6*k
L6b  jmp  imp+7*k
imp  mov.i #0, k
