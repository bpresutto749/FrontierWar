;redcode-94
;name Paper Lantern
;author anon
;strategy silk-style paper
;assert CORESIZE==8000
D1 equ 3620
D2 equ 1764
D3 equ 2391
start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  D1, #0
        mov.i >s1, }s1
s2      spl  D2, #0
        mov.i >s2, }s2
lp      mov.i bmb, >D3
        mov.i bmb, }-D3
        jmp  lp, <-777
bmb     dat  <2667, <5334
        end start
