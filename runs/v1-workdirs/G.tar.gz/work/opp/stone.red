;redcode-94
;name t_stone
;assert 1
step equ 3044
ptr  dat  #0, #0
st   spl  #0, 0
lp   mov.i bmb, @ptr
     add.ab #step, ptr
     djn.f lp, <-300
bmb  dat  >1, >1
     end st
