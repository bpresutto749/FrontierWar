;redcode-94
;name t_clear
;assert 1
gate dat 0, 0
     dat 0, 0
cl   spl #0, 0
     mov.i bomb, >gate
     djn.f -1, >gate
bomb dat >2667, 2-gate
     end cl
