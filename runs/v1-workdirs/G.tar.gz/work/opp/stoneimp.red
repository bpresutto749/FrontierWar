;redcode-94
;name t_stoneimp
;assert 1
k equ 2667
step equ 3364
     spl  stn
L0   spl  L4
L1   spl  L3
     jmp  imp
L3   jmp  imp+k
L4   spl  L6
     jmp  imp+2*k
L6   jmp  imp+3*k
imp  mov.i #0, k
     dat 0,0
     dat 0,0
ptr  dat  #0, #0
stn  spl  #0, 0
lp   mov.i bmb, @ptr
     add.ab #step, ptr
     djn.f lp, <-300
bmb  dat  >1, >1
