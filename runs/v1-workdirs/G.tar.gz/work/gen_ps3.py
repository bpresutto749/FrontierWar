import sys
SCAN="""        dat  0, 0
        dat  0, 0
        dat  0, 0
cbmb    dat  {cb}, inc+1-gate
gate    dat  0, inc+1-gate
sbmb    {sb}
ptr     dat  0, {P0}
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        mov.i sbmb, >ptr
        jmn.a lp, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
"""
PB="""pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >3620
        mov.i }s1, >s1
s2      spl  1764, #0
        mov.i >s2, }s2
s3      spl  @0, >2391
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
"""
PA="""pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  3620, #0
        mov.i >s1, }s1
s2      spl  1764, #0
        mov.i >s2, }s2
plp     mov.i pbmb, >2391
        mov.i pbmb, }-2391
        jmp  plp, <-777
pbmb    dat  <2667, <5334
"""
THINK="""think   ldp.ab #0, res
        ldp.ab #PC, st
        jmn.b  ok, res
        add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #PC
        jmz.b  lp, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
"""
def hdr(S,name,strat): return f";redcode-94\n;name {name}\n;author anon\n;strategy {strat}\n;assert CORESIZE==8000\nS       equ  {S}\nD       equ  2\nPC      equ  37\n"
def solo(S=3016, P0=4000, sb='spl  #0, 0', cb='<2667', name='Lynx'):
    return hdr(S,name,'pair scanner, spl carpet, spl/dat clear')+SCAN.format(cb=cb,sb=sb,P0=P0)+"        end  lp\n"
def comp(S=3016, P0=4000, sb='spl  #0, 0', cb='<2667', paper='b', name='Lynx Folding', force=None):
    t=THINK
    if force=='scan': t=t.replace('jmz.b  lp, st','jmp    lp')
    if force=='pap': t=t.replace('jmz.b  lp, st','jmp    pap')
    return hdr(S,name,'p-space switch on loss between a pair scanner and a silk paper')+SCAN.format(cb=cb,sb=sb,P0=P0)+(PB if paper=='b' else PA)+t+"        end  think\n"
if __name__=='__main__':
    open('t_solo.red','w').write(solo())
    open('t_cb.red','w').write(comp(paper='b'))
    open('t_ca.red','w').write(comp(paper='a'))
    open('t_cscan.red','w').write(comp(force='scan'))
