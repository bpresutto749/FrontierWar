;redcode-94
;name Lynx Folding
;author anon
;strategy p-space switch between a pair scanner and a silk paper
;assert CORESIZE==8000
S       equ  3288
D       equ  2
PC      equ  37
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.ab sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
        dat  0, 0
pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >2758
        mov.i }s1, >s1
s2      spl  1307, #0
        mov.i >s2, }s2
s3      spl  @0, >1704
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
think   ldp.ab #0, res
        ldp.ab #37, st
        jmz.b  tog, res
        seq.ab #2, res
        jmp    ok
        jmz.b  ok, st
tog     add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #37
        jmz.b  q0, st
        jmp    pap
res     dat  0, 0
st      dat  0, 0
q0      jmz.f  q1, gate+200
        mov.ab #gate+200-ptr-2, ptr
        jmp    top
q1      jmz.f  q2, gate+700
        mov.ab #gate+700-ptr-2, ptr
        jmp    top
q2      jmz.f  q3, gate+1200
        mov.ab #gate+1200-ptr-2, ptr
        jmp    top
q3      jmz.f  q4, gate+1700
        mov.ab #gate+1700-ptr-2, ptr
        jmp    top
q4      jmz.f  q5, gate+2200
        mov.ab #gate+2200-ptr-2, ptr
        jmp    top
q5      jmz.f  q6, gate+2700
        mov.ab #gate+2700-ptr-2, ptr
        jmp    top
q6      jmz.f  q7, gate+3200
        mov.ab #gate+3200-ptr-2, ptr
        jmp    top
q7      jmz.f  q8, gate+3700
        mov.ab #gate+3700-ptr-2, ptr
        jmp    top
q8      jmz.f  q9, gate+4200
        mov.ab #gate+4200-ptr-2, ptr
        jmp    top
q9      jmz.f  q10, gate+4700
        mov.ab #gate+4700-ptr-2, ptr
        jmp    top
q10      jmz.f  q11, gate+5200
        mov.ab #gate+5200-ptr-2, ptr
        jmp    top
q11      jmz.f  q12, gate+5700
        mov.ab #gate+5700-ptr-2, ptr
        jmp    top
q12      jmz.f  q13, gate+6200
        mov.ab #gate+6200-ptr-2, ptr
        jmp    top
q13      jmz.f  q14, gate+6700
        mov.ab #gate+6700-ptr-2, ptr
        jmp    top
q14      jmz.f  q15, gate+7200
        mov.ab #gate+7200-ptr-2, ptr
        jmp    top
q15      jmz.f  qend, gate+7700
        mov.ab #gate+7700-ptr-2, ptr
        jmp    top
qend    jmp    lp
        end  think
