;redcode-94
;name Lynx
;author anon
;strategy pair scanner, spl carpet, spl/dat clear
;assert CORESIZE==8000
S       equ  3016
D       equ  2
PC      equ  37
        dat  0, 0
        dat  0, 0
        dat  0, 0
cbmb    dat  <2667, inc+1-gate
gate    dat  0, inc+1-gate
sbmb    spl  #0, 0
ptr     dat  0, 4000
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        mov.i sbmb, >ptr
        jmn.a lp, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
        end  lp
