import sys
def scan(S, D, name='Lynx'):
    return f""";redcode-94
;name {name}
;author anon
;strategy 0.5c pair scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
S       equ  {S}
D       equ  {D}
ptr     dat  0, 0
        dat  0, 0
gate    dat  0, 0
cbmb    dat  <2667, cbmb-gate+3
        dat  0, 0
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.ab sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
inc     dat  S, S
        end  lp
"""
if __name__=='__main__':
    print(scan(int(sys.argv[1]),int(sys.argv[2])))
