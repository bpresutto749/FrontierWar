import sys
def scan(S, D=2, P0=4000, BD=4000, name='Lynx', cb='<2667', sb='spl  #0, 0', ndec=0):
    code=f"""gate    dat  0, inc+1-gate
ptr     dat  0, {P0}
sbmb    {sb}
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  {cb}, inc+1-gate
inc     dat  S, S
"""
    n=13
    boot="boot\n"+"".join(f"        mov.i gate+{i}, gate+{i}+BD\n" for i in range(n))+"        jmp  lp+BD\n"
    dec="".join("        spl  #1, 1\n" for _ in range(ndec))
    return f""";redcode-94
;name {name}
;author anon
;strategy pair scanner with spl carpet, then spl/dat clear; boots away leaving a decoy
;assert CORESIZE==8000
S       equ  {S}
D       equ  {D}
BD      equ  {BD}
{code}{dec}{boot}        end  boot
"""
if __name__=='__main__':
    print(scan(int(sys.argv[1]),int(sys.argv[2]),BD=int(sys.argv[3])))
