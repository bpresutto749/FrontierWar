import sys
def scan(S, D=8, K=5, mode='b', name='Lynx', P0=0):
    bombs="".join("        mov.i sbmb, >ptr\n" for _ in range(K))
    return f""";redcode-94
;name {name}
;author anon
;strategy fast pair scanner, spl burst on hit, then spl/dat clear
;assert CORESIZE==8000
S       equ  {S}
D       equ  {D}
gate    dat  0, last+1-gate
ptr     dat  0, {P0}
sbmb    spl  #0, 0
lp      add.f inc, sc
sc      seq.i S, S+D
        jmp  fnd
        jmn.a lp, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, last+1-gate
inc     dat  S, S
fnd     jmz.a clr, sc
        mov.{mode} sc, ptr
{bombs}last    jmp  lp
        end  lp
"""
if __name__=='__main__':
    a=sys.argv
    print(scan(int(a[1]),int(a[2]),int(a[3]),a[4]))
