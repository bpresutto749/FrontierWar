import sys
sys.path.insert(0,'.')
from gen_ps3 import PB, PA, THINK, hdr
SCAN="""gate    dat  0, inc+1-gate
ptr     dat  0, {P0}
sbmb    {sb}
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  {cb}, inc+1-gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
        dat  0, 0
"""
def comp(S=3016, P0=4000, sb='spl  #0, 0', cb='<2667', paper='b', name='Lynx Folding', force=None, pc=37):
    t=THINK.replace('#PC','#%d'%pc)
    if force=='scan': t=t.replace('jmz.b  lp, st','jmp    lp')
    if force=='pap': t=t.replace('jmz.b  lp, st','jmp    pap')
    return hdr(S,name,'p-space switch on loss between a pair scanner and a silk paper')+SCAN.format(cb=cb,sb=sb,P0=P0)+(PB if paper=='b' else PA)+t+"        end  think\n"
if __name__=='__main__':
    open('u_cscan.red','w').write(comp(force='scan'))
    open('u_cpap.red','w').write(comp(force='pap'))
    open('u_cb.red','w').write(comp(paper='b'))
    open('u_ca.red','w').write(comp(paper='a'))
