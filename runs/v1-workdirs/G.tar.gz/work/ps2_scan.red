;redcode-94
;name Lynx Folding
;author anon
;strategy p-space switch between a pair scanner (spl carpet + spl/dat clear) and a silk paper; switch on loss
;assert CORESIZE==8000
S       equ  3016
D       equ  2
PC      equ  37
        dat  0, 0
        dat  0, 0
        dat  0, 0
gate    dat  0, inc+1-gate
ptr     dat  0, 4000
sbmb    spl  #0, 0
top     mov.i sbmb, >ptr
lp      add.f inc, sc
sc      seq.i S, S+D
        mov.b sc, ptr
        jmn.a top, sc
clr     spl  #0, 0
        mov.i cbmb, >gate
        djn.f -1, >gate
cbmb    dat  <2667, inc+1-gate
inc     dat  S, S
        dat  0, 0
        dat  0, 0
pap     spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >3620
        mov.i }s1, >s1
s2      spl  1764, #0
        mov.i >s2, }s2
s3      spl  @0, >2391
        mov.i }s3, >s3
        mov.i <2667, <5334
        jmp  -1, <-2667
think   ldp.ab #0, res
        ldp.ab #PC, st
        jmn.b  ok, res
        add.ab #1, st
ok      mod.ab #2, st
        stp.b  st, #PC
        jmp lp
        jmp    pap
res     dat  0, 0
st      dat  0, 0
        dat  0, 0
        dat  0, 0
        end  think
