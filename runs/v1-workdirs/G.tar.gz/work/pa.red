;redcode-94
;name P
;author anon
;strategy paper
;assert CORESIZE==8000
start   spl  1, 0
        spl  1, 0
        spl  1, 0
s1      spl  @0, >3620
        mov.i }s1, >s1
s2      spl  1764, #0
        mov.i >s2, }s2
lp      mov.i bmb, >2391
        mov.i <2667, <5334
        djn.f lp, <-2667
bmb     dat  >5334, >2667
        end start

