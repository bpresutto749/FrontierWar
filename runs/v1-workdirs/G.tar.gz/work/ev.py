import subprocess, sys, glob, os
from concurrent.futures import ThreadPoolExecutor
P='/tmp/arena_G/bin/pmars'
def bat(a,b,r=100,fixed=True):
    args=[P,'-b','-k','-r',str(r)]+(['-f'] if fixed else [])+[a,b]
    o=subprocess.run(args,capture_output=True,text=True).stdout.strip().splitlines()
    o=[l for l in o if l.split() and l.split()[0].lstrip('-').isdigit()]
    w1,t1=map(int,o[-2].split()[:2]); w2,_=map(int,o[-1].split()[:2])
    return (3*w1+t1)/(3*r), w1, w2, t1
def ev(w, verbose=False):
    sp=sorted(glob.glob('/tmp/arena_G/sparring/*.red')); op=sorted(glob.glob('/tmp/arena_G/work/opp/*.red'))
    jobs=[(o,True) for o in sp]+[(o,False) for o in sp]+[(o,False) for o in op]
    with ThreadPoolExecutor(4) as ex: res=list(ex.map(lambda j: bat(w,j[0],100,j[1]), jobs))
    n=len(sp); a=sum(r[0] for r in res[:n])/n; b=sum(r[0] for r in res[n:2*n])/n; c=sum(r[0] for r in res[2*n:])/len(op)
    if verbose:
        for j,r in zip(jobs,res): print(f"  {os.path.basename(j[0])[:-4]:20s} {'F' if j[1] else 'R'} {r[1]:3d} {r[2]:3d} {r[3]:3d} {r[0]:.3f}")
    return a,b,c
if __name__=='__main__':
    v='-v' in sys.argv
    for w in [x for x in sys.argv[1:] if x!='-v']:
        a,b,c=ev(w,v); print(f"{os.path.basename(w):24s} sparF {a:.3f} sparR {b:.3f} own {c:.3f}")
