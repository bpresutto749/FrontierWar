;redcode-94
;name Sickle Moon
;author anon
;strategy fast mod scanner with spl carpet and d-clear, booted away from a decoy field
;assert CORESIZE==8000
step    equ 1650
away    equ 1139
        org boot
ptr     dat.f  0, 1650
top     mov.i  sb, >ptr
scan    seq.i  2*step, 2*step+24
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.b  top, ptr
clr     spl.i  #0, 0
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
sb      spl.i  #0, 0
inc     dat.f  step, step
boot    mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        jmp    @bjmp, 0
bsrc    dat.f  inc+1, 0
bdst    dat.f  0, inc+1+away
bjmp    dat.f  0, scan+away
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
