;redcode-94
;name duck
loop jmp 0
