;redcode-94
;name Pebble
;author anon
;assert CORESIZE==8000
step    equ 3044
        org s0
s0      spl    #0, <-500
sl      mov.i  sb, @sp
        add.ab #step, sp
        jmp    sl, <s0-3
sp      dat.f  0, step
sb      dat.f  >1, >1
