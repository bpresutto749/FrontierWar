;redcode-94
;name Pebble2
;author anon
;assert CORESIZE==8000
step    equ 3044
        org sl
sl      mov.i  sb, @sp
        add.ab #step, sp
        jmp    sl, <sl-3
sp      dat.f  0, step
sb      dat.f  >1, >1
