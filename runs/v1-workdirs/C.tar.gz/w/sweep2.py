import subprocess, random, sys, math
from gen_scan import gen
def score(src, rounds, tag):
    p='/tmp/arena_C/w/sw2_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
random.seed(int(sys.argv[1]))
for it in range(int(sys.argv[2])):
    g = random.choice([20,20,40,25])
    m = 8000//g
    while True:
        k = random.randrange(1,m)
        if math.gcd(k,m)==1: break
    step=g*k
    gap = random.randrange(3,g)
    bad=False
    for o in range(-2,10):
        if o!=0 and o%g==0: bad=True
        if o!=gap and (o-gap)%g==0: bad=True
    if bad: continue
    away=random.randrange(150,7850)
    nd=random.choice([30,40,50,60,70])
    pi=random.choice([step, 2*step, random.randrange(100,7900)])
    s=score(gen(step=step,gap=gap,away=away,ndecoy=nd,ptrinit=pi),60,sys.argv[1])
    print(s,step,gap,away,nd,pi,flush=True)
