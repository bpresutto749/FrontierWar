;redcode-94
;name Sickle Moon III
;author anon
;strategy fast mod scanner with spl carpet and d-clear, booted away from a decoy field
;assert CORESIZE==8000
step    equ 1140
away    equ 3021
        org think
ptr     dat.f  0, 1140
top     mov.i  sb, >ptr
scan    seq.i  2*step, 2*step+8
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.b  top, ptr
clr     spl.i  #0, 0
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
sb      spl.i  #0, 0
inc     dat.f  step, step
boot    mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        jmp    @bjmp, 0
bsrc    dat.f  inc+1, 0
bdst    dat.f  0, inc+1+away
bjmp    dat.f  0, scan+away
think   ldp.ab  #0, vr
        ldp.ab  #11, vl
        ldp.ab  #12, vp0
        ldp.ab  #13, vn0
        ldp.ab  #14, vp1
        ldp.ab  #15, vn1
        seq.ab  #-1, vr
        jmp     upd
        jmp     choose
upd     seq.ab  #2, vr
        jmp     u1
        mov.ab  #1, vr
        jmp     gotp
u1      seq.ab  #1, vr
        jmp     gotp
        mov.ab  #3, vr
gotp    jmn.b   us1, vl
        add.b   vr, vp0
        add.ab  #1, vn0
        jmp     choose
us1     add.b   vr, vp1
        add.ab  #1, vn1
choose  slt.ab  #199, vn0
        jmp     pick0
        slt.ab  #199, vn1
        jmp     pick1
        mov.b   vp0, vt0
        mul.b   vn1, vt0
        mov.b   vp1, vt1
        mul.b   vn0, vt1
        slt.b   vt0, vt1
pick0   mov.ab  #0, vl
        jmz.b   store, vl
pick1   mov.ab  #1, vl
store   stp.b   vl, #11
        stp.b   vp0, #12
        stp.b   vn0, #13
        stp.b   vp1, #14
        stp.b   vn1, #15
        jmz.b   boot, vl
sboot   mov.i   sb2, sl+4000+4
        mov.i   sp2, sl+4000+3
        mov.i   sj2, sl+4000+2
        mov.i   sa2, sl+4000+1
        mov.i   sl, sl+4000
        jmp     sl+4000, 0
vr      dat.f   0, 0
vl      dat.f   0, 0
vp0     dat.f   0, 0
vn0     dat.f   0, 0
vp1     dat.f   0, 0
vn1     dat.f   0, 0
vt0     dat.f   0, 0
vt1     dat.f   0, 0
sl      mov.i   sb2, @sp2
sa2     add.ab  #3044, sp2
sj2     jmp     sl, <sl-3
sp2     dat.f   0, 3044
sb2     dat.f   >1, >1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
