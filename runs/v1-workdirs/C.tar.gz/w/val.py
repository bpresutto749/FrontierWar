import sys, subprocess
from gen_scan import gen
def score(src, rounds=150, tag='v'):
    p='/tmp/arena_C/w/val_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
for a in sys.argv[1:]:
    st,gp,aw,nd = map(int,a.split(','))
    print(a, score(gen(step=st,gap=gp,away=aw,ndecoy=nd)), flush=True)
