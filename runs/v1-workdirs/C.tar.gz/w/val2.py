import sys, subprocess, json
from gen_scan import gen
def score(src, rounds=100, tag='v2'):
    p='/tmp/arena_C/w/val_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1]), out
base=dict(step=1140,gap=8,away=3021,ndecoy=40)
for a in sys.argv[1:]:
    kw=dict(base); kw.update(json.loads(a))
    s,out=score(gen(**kw))
    print(a, s, flush=True)
