import sys
from gen_scan import gen
PAPER = """pS      spl 1, 0
        spl 1, 0
        spl 1, 0
pP      spl @0, >{s1}
        mov }}-1, >-1
        spl @0, >{s2}
        mov }}-1, >-1
        mov.i pB, >{s3}
        mov.i {{-5, <1
        jmz.a @0, >{s4}
pB      dat >2667, >5334
"""
def gensw(pk=211, s1=3730, s2=-2210, s3=1561, s4=-1820, scankw={}, ndecoy=30):
    sc = gen(ndecoy=ndecoy, **scankw)
    sc = sc.replace("        org boot\n", "        org think\n")
    sw = f"""think   ldp.ab  #0, pres
        ldp.ab  #{pk}, pstr
        jmn.b   keep, pres
        add.ab  #1, pstr
keep    mod.ab  #2, pstr
        stp.b   pstr, #{pk}
        jmz.b   boot, pstr
        jmp     pS
pres    dat.f   0, 0
pstr    dat.f   0, 0
"""
    sc = sc.replace(";name Sickle Moon", ";name Sickle Moon II")
    return sc + sw + PAPER.format(s1=s1,s2=s2,s3=s3,s4=s4)
if __name__=='__main__':
    print(gensw(), end='')
