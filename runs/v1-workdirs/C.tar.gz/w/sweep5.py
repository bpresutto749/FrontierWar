import subprocess, random, sys
from gen_scan import gen
def score(src, rounds, tag):
    p='/tmp/arena_C/w/sw5_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
random.seed(3)
for it in range(10):
    away=random.randrange(300,7700); nd=random.choice([55,60,65,70]); pi=random.choice([5235, 6740, 13480%8000, random.randrange(100,7900)])
    gap=random.choice([11,11,10,9,12,13])
    s=score(gen(step=6740,gap=gap,away=away,ndecoy=nd,ptrinit=pi,compact=1),300,'a')
    print(s,6740,gap,away,nd,pi,1,flush=True)
