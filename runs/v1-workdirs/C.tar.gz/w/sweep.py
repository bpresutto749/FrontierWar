import subprocess, random, sys, math
sys.path.insert(0,'.')
from gen_scan import gen
def score(src, rounds=40):
    open('/tmp/arena_C/w/tmp_%d.red'%rounds,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py','/tmp/arena_C/w/tmp_%d.red'%rounds,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
random.seed(int(sys.argv[1]) if len(sys.argv)>1 else 1)
res=[]
for it in range(int(sys.argv[2]) if len(sys.argv)>2 else 40):
    g = random.choice([10,20,20,40,16,25,50])
    m = 8000//g
    while True:
        k = random.randrange(1,m)
        if math.gcd(k,m)==1: break
    step = g*k
    gap = random.randrange(3, g) if g>10 else 5
    if g==16: gap = random.choice([5,6,7,8])
    if (gap - g) >= -2: gap = gap  # code range check below
    # code offsets -2..9 ; need no offset o!=gap with o%g==gap%g, and no o!=0 with o%g==0
    bad=False
    for o in range(-2,10):
        if o!=0 and o%g==0: bad=True
        if o!=gap and (o-gap)%g==0: bad=True
    if bad: continue
    away = random.randrange(200, 7800)
    nd = random.choice([20,40,60])
    s = score(gen(step=step,gap=gap,away=away,ndecoy=nd))
    res.append((s,step,gap,away,nd))
    print(s,step,gap,away,nd, flush=True)
res.sort(reverse=True)
print("BEST",res[:8])
