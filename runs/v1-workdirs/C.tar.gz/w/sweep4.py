import subprocess, random, sys, math
from gen_scan import gen
def score(src, rounds, tag):
    p='/tmp/arena_C/w/sw4_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
random.seed(int(sys.argv[1]))
for it in range(int(sys.argv[2])):
    g = 10
    m = 800
    while True:
        k = random.randrange(1,m)
        if math.gcd(k,m)==1: break
    step=g*k
    gap=5
    away=random.randrange(150,7850)
    nd=random.choice([60,70,75])
    pi=random.choice([step, 2*step, random.randrange(100,7900)])
    s=score(gen(step=step,gap=gap,away=away,ndecoy=nd,ptrinit=pi,compact=1),200,sys.argv[1])
    print(s,step,gap,away,nd,pi,1,flush=True)
