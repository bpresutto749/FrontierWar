;redcode-94
;name Sickle Moon
;author anon
;strategy mod-10 0.5c scanner, spl carpet, then d-clear
;assert CORESIZE==8000
step    equ 3030
        org scan
ptr     dat.f  0, step
sb      spl.i  #0, 0
top     mov.i  sb, >ptr
scan    seq.i  2*step, 2*step+5
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.a  top, scan
clr     spl.i  #0, 0
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
inc     dat.f  step, step
