import sys
def gen(step=5620, gap=8, away=2000, ptrinit=None, ndecoy=40, clearkind='d', bomb='spl.i  #0, 0', dstyle='spl5', compact=0):
    if ptrinit is None: ptrinit = step
    body = f"""ptr     dat.f  0, {ptrinit}
top     mov.i  sb, >ptr
scan    seq.i  2*step, 2*step+{gap}
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.b  top, ptr
clr     spl.i  #0, 0
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
sb      {bomb}
inc     dat.f  step, step
"""
    if compact:
        body = f"""ptr     dat.f  0, {ptrinit}
top     mov.i  inc, >ptr
scan    seq.i  2*step, 2*step+{gap}
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.b  top, ptr
inc     spl.i  #step, >step
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
"""
    if compact==2:
        body = f"""ptr     dat.f  0, {ptrinit}
scan    seq.i  2*step, 2*step+{gap}
        mov.ab scan, ptr
        add.f  inc, scan
top     mov.i  inc, >ptr
        jmn.a  scan, scan
inc     spl.i  #step, >step
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
"""
    n = body.count('\n')
    lines = [f";redcode-94",";name Sickle Moon",";author anon",";strategy fast mod scanner with spl carpet and d-clear, booted away from a decoy field",";assert CORESIZE==8000",
             f"step    equ {step}", f"away    equ {away}", "        org boot"]
    lines.append(body.rstrip('\n'))
    # boot: copy n lines from ptr to ptr+away, then jump to scan copy
    lines.append(f"boot    mov.i  {{bsrc, <bdst")
    for i in range(n-1):
        lines.append(f"        mov.i  {{bsrc, <bdst")
    lines.append(f"        jmp    @bjmp, 0")
    lines.append(f"bsrc    dat.f  ptr+%d, 0" % n + "")
    lines.append(f"bdst    dat.f  0, inc+1+away")
    lines.append(f"bjmp    dat.f  0, scan+away")
    dec = ['spl.b  #1, 1','spl.ab #1, @1','spl.ba #1, *1','spl.a  #1, *1','spl.i  #1, #1']
    for i in range(ndecoy):
        if dstyle=='spl5': lines.append("        "+dec[i%len(dec)])
        elif dstyle=='datvar': lines.append("        dat.f  #%d, #%d" % ((i*37+11)%97+1, (i*53+7)%89+1))
        elif dstyle=='splvar': lines.append("        spl.b  #%d, %d" % ((i*37+11)%97+1, (i*53+7)%89+1))
        elif dstyle=='mix': lines.append("        "+dec[(i*7+i//3)%len(dec)].replace('#1','#%d'%(i%7+1)))
    return '\n'.join(lines)+'\n'
if __name__=='__main__':
    kw = {}
    for a in sys.argv[1:]:
        k,v = a.split('=')
        kw[k] = int(v) if v.lstrip('-').isdigit() else v
    print(gen(**kw), end='')
