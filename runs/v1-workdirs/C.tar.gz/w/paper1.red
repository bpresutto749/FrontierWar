;redcode-94
;name Folded Crane
;author anon
;strategy 8-process silk paper with anti-imp carpet
;assert CORESIZE==8000
        org go
go      spl 1, 0
        spl 1, 0
        spl 1, 0
pS      spl @0, >3730
        mov }-1, >-1
        spl @0, >-2210
        mov }-1, >-1
        mov.i pB, >1561
        mov.i {-5, <1
        jmz.a @0, >-1820
pB      dat >2667, >5334
