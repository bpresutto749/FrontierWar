;redcode-94
;name Sickle Moon II
;author anon
;strategy fast mod scanner with spl carpet and d-clear, booted away from a decoy field
;assert CORESIZE==8000
step    equ 5620
away    equ 2000
        org think
ptr     dat.f  0, 5620
top     mov.i  sb, >ptr
scan    seq.i  2*step, 2*step+8
        mov.ab scan, ptr
        add.f  inc, scan
        jmn.b  top, ptr
clr     spl.i  #0, 0
        mov.i  db, >ptr
        djn.f  -1, >ptr
db      dat.f  <2667, db-ptr-1
sb      spl.i  #0, 0
inc     dat.f  step, step
boot    mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        mov.i  {bsrc, <bdst
        jmp    @bjmp, 0
bsrc    dat.f  inc+1, 0
bdst    dat.f  0, inc+1+away
bjmp    dat.f  0, scan+away
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
        spl.b  #1, 1
        spl.ab #1, @1
        spl.ba #1, *1
        spl.a  #1, *1
        spl.i  #1, #1
think   ldp.ab  #0, pres
        ldp.ab  #211, pstr
        jmn.b   keep, pres
        add.ab  #1, pstr
keep    mod.ab  #2, pstr
        stp.b   pstr, #211
        jmz.b   boot, pstr
        jmp     pS
pres    dat.f   0, 0
pstr    dat.f   0, 0
pS      spl 1, 0
        spl 1, 0
        spl 1, 0
pP      spl @0, >3730
        mov }-1, >-1
        spl @0, >-2210
        mov }-1, >-1
        mov.i pB, >1561
        mov.i {-5, <1
        jmz.a @0, >-1820
pB      dat >2667, >5334
