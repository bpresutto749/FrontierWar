import sys, subprocess
from gen_scan import gen
def score(src, rounds, tag):
    p='/tmp/arena_C/w/v3_%s.red'%tag
    open(p,'w').write(src)
    out = subprocess.run(['python3','/tmp/arena_C/tools/battle.py',p,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().split()[-1])
rows=[]
for l in open(sys.argv[1]):
    p=l.split()
    if len(p)==7: rows.append((float(p[0]),)+tuple(map(int,p[1:])))
rows.sort(reverse=True)
N=int(sys.argv[2]); R=int(sys.argv[3])
for r in rows[:N]:
    s,step,gap,away,nd,pi,c=r
    src=gen(step=step,gap=gap,away=away,ndecoy=nd,ptrinit=pi,compact=c)
    v=score(src,R,'x')
    print(round(v,4), r, flush=True)
