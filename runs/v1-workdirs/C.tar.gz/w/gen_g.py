import sys
from gen_scan import gen
def gen_g(K=4, sstep=3044, saway=4000, ndecoy=24, scankw=None, pbase=11):
    scankw = scankw or dict(step=1140,gap=8,away=3021)
    sc = gen(ndecoy=0, **scankw).replace("        org boot\n", "        org think\n")
    PL,PS0,PN0,PS1,PN1 = pbase, pbase+1, pbase+2, pbase+3, pbase+4
    th = f"""think   ldp.ab  #0, vr
        ldp.ab  #{PL}, vl
        ldp.ab  #{PS0}, vp0
        ldp.ab  #{PN0}, vn0
        ldp.ab  #{PS1}, vp1
        ldp.ab  #{PN1}, vn1
        seq.ab  #-1, vr
        jmp     upd
        jmp     choose
upd     seq.ab  #2, vr
        jmp     u1
        mov.ab  #1, vr
        jmp     gotp
u1      seq.ab  #1, vr
        jmp     gotp
        mov.ab  #3, vr
gotp    jmn.b   us1, vl
        add.b   vr, vp0
        add.ab  #1, vn0
        jmp     choose
us1     add.b   vr, vp1
        add.ab  #1, vn1
choose  slt.ab  #{K-1}, vn0
        jmp     pick0
        slt.ab  #{K-1}, vn1
        jmp     pick1
        mov.b   vp0, vt0
        mul.b   vn1, vt0
        mov.b   vp1, vt1
        mul.b   vn0, vt1
        slt.b   vt0, vt1
pick0   mov.ab  #0, vl
        jmz.b   store, vl
pick1   mov.ab  #1, vl
store   stp.b   vl, #{PL}
        stp.b   vp0, #{PS0}
        stp.b   vn0, #{PN0}
        stp.b   vp1, #{PS1}
        stp.b   vn1, #{PN1}
        jmz.b   boot, vl
sboot   mov.i   sb2, sl+{saway}+4
        mov.i   sp2, sl+{saway}+3
        mov.i   sj2, sl+{saway}+2
        mov.i   sa2, sl+{saway}+1
        mov.i   sl, sl+{saway}
        jmp     sl+{saway}, 0
vr      dat.f   0, 0
vl      dat.f   0, 0
vp0     dat.f   0, 0
vn0     dat.f   0, 0
vp1     dat.f   0, 0
vn1     dat.f   0, 0
vt0     dat.f   0, 0
vt1     dat.f   0, 0
sl      mov.i   sb2, @sp2
sa2     add.ab  #{sstep}, sp2
sj2     jmp     sl, <sl-3
sp2     dat.f   0, {sstep}
sb2     dat.f   >1, >1
"""
    dec = ['spl.b  #1, 1','spl.ab #1, @1','spl.ba #1, *1','spl.a  #1, *1','spl.i  #1, #1']
    d = ''.join("        "+dec[i%5]+"\n" for i in range(ndecoy))
    return sc.replace(";name Sickle Moon", ";name Sickle Moon III") + th + d
if __name__=='__main__':
    kw={}
    for a in sys.argv[1:]:
        k,v=a.split('='); kw[k]=int(v)
    print(gen_g(**kw), end='')
