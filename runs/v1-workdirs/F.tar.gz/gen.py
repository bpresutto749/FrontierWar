import sys,subprocess
def gen(gap=2371,step=27,d=2000,bombs=3,spl=True,pl=True):
    s=f""";redcode-94
;name Quill
;author x
;assert CORESIZE==8000
org start
gap equ {gap}
step equ {step}
d equ {d}
start spl go
g0    mov.ab #11, cnt
      mov.ab #3, a
cp    mov.i <a, <b
cnt   djn.b cp, #0
      spl @b, 0
      add.ab #gap+11, b
      jmp g0
a     dat 0, 0
b     dat 0, 2+gap-2
go    add.f  inc, scn
scn   seq.i  100, 100+d
      jmp    found
      jmp    go
found mov.ab scn, ptr
      add.ab #(40+(scn-ptr)), ptr
      slt.ab #81, ptr
      jmp    go
      sub.ab #40, ptr
"""
    for i in range(bombs):
        s+="      mov.i  %s, >ptr\n"%("sp" if (spl and i%2==0) else "dt") if i else "      mov.i  sp, @ptr\n"
    s+="""      jmp    go
inc   dat    step, step
ptr   dat    0, 0
sp    spl    0, <-3
dt    dat    0, <-4
"""
    return s
if __name__=="__main__":
    import itertools
    out=[]
    for kw in [dict(),dict(step=13),dict(step=41),dict(d=777),dict(d=3500),dict(bombs=6),dict(bombs=10),dict(spl=False,bombs=6),dict(gap=1777),dict(gap=3333)]:
        open('t.red','w').write(gen(**kw))
        r=subprocess.run(['python3','tools/battle.py','t.red','--rounds','40'],capture_output=True,text=True).stdout.strip().splitlines()[-1]
        print(kw,r,flush=True)
