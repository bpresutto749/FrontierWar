import subprocess,sys
from concurrent.futures import ThreadPoolExecutor
def run(src,name,r=60):
    open(name,'w').write(src)
    out=subprocess.run(['python3','tools/battle.py',name,'--rounds',str(r)],capture_output=True,text=True).stdout.strip().splitlines()[-1]
    return float(out.split()[-1])
tmpl=""";redcode-94
;name St
;author x
org s
s    add.ab #{st}, p
     mov.i  {b1}, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
sp   spl 0, 0
"""
