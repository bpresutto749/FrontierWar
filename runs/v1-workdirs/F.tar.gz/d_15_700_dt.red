;redcode-94
;name Stone
;author x
org s
s    add.ab #15, p
     mov.i  dt, @p
     djn.b  s, #700
     mov.ab #-1, cp
c    mov.i  dt, >cp
     mov.i  dt, >cp
     jmp c
cp   dat 0, 30
p    dat 0, 0
dt   dat 0, 0
sp   spl 0, <-3
dd   dat 0, <-4
