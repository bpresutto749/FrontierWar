;redcode-94
;name St
;author x
org q
q spl 1
     spl 1
s    add.ab #9, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
