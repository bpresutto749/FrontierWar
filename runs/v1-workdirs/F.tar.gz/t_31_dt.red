;redcode-94
;name St
;author x
org s
s    add.ab #31, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
sp   spl 0, 0
