import sys
from st2 import run
from concurrent.futures import ThreadPoolExecutor
T=""";redcode-94
;name Quill
;author x
org start
gap equ {gap}
start spl s
i0    mov.ab #1+gap, b
g0    mov.ab #10, cnt
      mov.ab #2, a
cp    mov.i <a, <b
cnt   djn.b cp, #0
      spl @b, 0
      add.ab #gap+10, b
      jmp g0
a     dat 0, 0
b     dat 0, 0
s    add.ab #{st}, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
"""
jobs=[(g,st) for g in [1111,2371] for st in [7,15]]
def f(j): return j,run(T.format(gap=j[0],st=j[1]),f"c_{j[0]}_{j[1]}.red",50)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
