;redcode-94
;name Quill
;author x
org start
gap equ 2371
start spl s
i0    mov.ab #1+gap, b
g0    mov.ab #10, cnt
      mov.ab #2, a
cp    mov.i <a, <b
cnt   djn.b cp, #0
      spl @b, 0
      add.ab #gap+10, b
      jmp g0
a     dat 0, 0
b     dat 0, 0
s    add.ab #7, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
