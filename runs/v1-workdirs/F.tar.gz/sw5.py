from st2 import run
from concurrent.futures import ThreadPoolExecutor
D=""";redcode-94
;name Lattice
;author x
org s
s    add.f  inc, p
     mov.i  dt, @p
     mov.i  dt, *p
     jmp s
inc  dat {a}, {b}
p    dat 0, 0
dt   dat 0, 0
"""
js=[(15,15),(15,16),(15,7),(14,15),(15,45),(9,15)]
def f(k): return k,run(D.format(a=k[0],b=k[1]),f"Y{k[0]}_{k[1]}.red",100)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,js): print(j,r,flush=True)
