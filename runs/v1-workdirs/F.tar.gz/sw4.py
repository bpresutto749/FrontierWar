from st2 import run
from concurrent.futures import ThreadPoolExecutor
D=""";redcode-94
;name St
;author x
org s
s    add.ab #15, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   {b}
"""
bs={'dat':'dat 0,0','imp':'mov.i 0,1','spl':'spl 0,0','dat2':'dat <1,<2','jmz':'jmp 0,0','imp2':'mov.i 0,2667'}
def f(k): return k,run(D.format(b=bs[k]),f"X{k}.red",100)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,bs): print(j,r,flush=True)
