;redcode-94
;name Lattice
;author x
org s
s    add.f  inc, p
     mov.i  dt, @p
     mov.i  dt, *p
     jmp s
inc  dat 9, 15
p    dat 0, 0
dt   dat 0, 0
