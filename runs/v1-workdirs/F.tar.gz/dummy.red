;redcode-94
org s
s jmp 0
