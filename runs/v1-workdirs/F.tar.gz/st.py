import subprocess,sys
from concurrent.futures import ThreadPoolExecutor
def run(src,name,r=60):
    open(name,'w').write(src)
    out=subprocess.run(['python3','tools/battle.py',name,'--rounds',str(r)],capture_output=True,text=True).stdout.strip().splitlines()[-1]
    return float(out.split()[-1])
tmpl=""";redcode-94
;name St
;author x
org s
s    add.ab #{st}, p
     mov.i  {b1}, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
sp   spl 0, 0
"""
if __name__!="__main__": raise SystemExit
jobs=[]
for st in [7,9,13,15,17,19,23,27,29,31,37,41]:
    jobs.append((st,'dt'))
for st in [7,13,23]:
    jobs.append((st,'sp'))
def f(j):
    return j,run(tmpl.format(st=j[0],b1=j[1]),f"t_{j[0]}_{j[1]}.red")
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
