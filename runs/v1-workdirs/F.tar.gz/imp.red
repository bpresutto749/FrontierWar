;redcode-94
;name i
;author x
org s
s spl 1
  spl 1
im mov.i #0, 2667
