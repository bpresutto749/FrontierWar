;redcode-94
;name Quill
;author x
;assert CORESIZE==8000
org start
gap equ 2371
step equ 27
d equ 2000
start spl go
g0    mov.ab #11, cnt
      mov.ab #3, a
cp    mov.i <a, <b
cnt   djn.b cp, #0
      spl @b, 0
      add.ab #gap+11, b
      jmp g0
a     dat 0, 0
b     dat 0, 2+gap-2
go    add.f  inc, scn
scn   seq.i  100, 100+d
      jmp    found
      jmp    go
found mov.ab scn, ptr
      add.ab #(40+(scn-ptr)), ptr
      slt.ab #81, ptr
      jmp    go
      sub.ab #40, ptr
      mov.i  sp, @ptr
      mov.i  dt, >ptr
      mov.i  sp, >ptr
      mov.i  dt, >ptr
      mov.i  sp, >ptr
      mov.i  dt, >ptr
      jmp    go
inc   dat    step, step
ptr   dat    0, 0
sp    spl    0, <-3
dt    dat    0, <-4
