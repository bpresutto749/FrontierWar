from st2 import run
from concurrent.futures import ThreadPoolExecutor
D=""";redcode-94
;name St
;author x
org s
s    add.ab #{st}, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
"""
jobs=[s for s in [5,11,12,18,21,25,33,35,45,51,55,65]]
def f(s): return s,run(D.format(st=s),f"W{s}.red",100)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
