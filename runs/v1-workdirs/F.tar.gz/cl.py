import sys
from st2 import run
from concurrent.futures import ThreadPoolExecutor
T=""";redcode-94
;name Stone
;author x
org s
s    add.ab #{st}, p
     mov.i  dt, @p
     djn.b  s, #{N}
     mov.ab #-1, cp
c    mov.i  {b1}, >cp
     mov.i  {b1}, >cp
     jmp c
cp   dat 0, {off}
p    dat 0, 0
dt   dat 0, 0
sp   spl 0, <-3
dd   dat 0, <-4
"""
jobs=[(15,N,b,o) for N in [700,1500] for b in ['dt','sp'] for o in [30]]
jobs+=[(15,N,'dt',30) for N in [300,3000]]
def f(j): return j,run(T.format(st=j[0],N=j[1],b1=j[2],off=j[3]),f"d_{j[0]}_{j[1]}_{j[2]}.red",50)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
