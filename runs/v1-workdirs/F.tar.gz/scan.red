;redcode-94
;name Sweep
;author x
;assert CORESIZE==8000
org go
step equ 9
d    equ 1537
go    add.f  inc, scn
scn   seq.i  100, 100+d
      jmp    found
      jmp    go
found mov.ab scn, ptr
      add.ab #24, ptr
      slt.ab #81, ptr
      jmp    go
      sub.ab #40, ptr
      mov.i  sp, @ptr
      mov.i  dt, >ptr
      mov.i  sp, >ptr
      mov.i  dt, >ptr
      mov.i  sp, >ptr
      mov.i  dt, >ptr
      jmp    go
inc   dat    step, step
ptr   dat    0, 0
sp    spl    0, <-3
dt    dat    0, <-4
