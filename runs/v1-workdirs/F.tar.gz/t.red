;redcode-94
;name St
;author x
org s
s    add.ab #13, p
     mov.i  dt, @p
     jmp s
p    dat 0, 0
dt   dat 0, 0
