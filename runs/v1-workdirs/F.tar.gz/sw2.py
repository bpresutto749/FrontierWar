from st2 import run
from concurrent.futures import ThreadPoolExecutor
D=""";redcode-94
;name St
;author x
org {org}
{pre}
s    add.ab #{st}, p
     mov.i  dt, @p
     jmp s
p    dat 0, {o}
dt   dat 0, 0
"""
if __name__=="__main__":
  pass
jobs=[]
for st in [15,13,17,9]:
    jobs.append((dict(org='s',pre='',st=st,o=0),f"S{st}"))
    jobs.append((dict(org='q',pre='q spl 1\n     spl 1',st=st,o=0),f"T{st}"))
    jobs.append((dict(org='q',pre='q spl 1',st=st,o=0),f"U{st}"))
def f(j): return j[1],run(D.format(**j[0]),j[1]+".red",100)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
