import subprocess,sys
def gen(gap=2371,step=27,d=2000,N=600,bombs=6,off=60):
    s=f""";redcode-94
;name Quill
;author x
;assert CORESIZE==8000
org start
gap equ {gap}
step equ {step}
d equ {d}
start spl go
i0    mov.ab #1+gap, b
g0    mov.ab #10, cnt
      mov.ab #2, a
cp    mov.i <a, <b
cnt   djn.b cp, #0
      spl @b, 0
      add.ab #gap+10, b
      jmp g0
a     dat 0, 0
b     dat 0, 0
go    add.f  inc, scn
scn   seq.i  100, 100+d
      jmp    found
      djn.b  go, #{N}
      jmp    clr
found mov.ab scn, ptr
      add.ab #(40+(scn-ptr)), ptr
      slt.ab #81, ptr
      jmp    go
      sub.ab #40, ptr
      mov.i  sp, @ptr
"""
    for i in range(bombs):
        s+="      mov.i  %s, >ptr\n"%("dt" if i%2==0 else "sp")
    s+=f"""      jmp    go
clr   mov.i  sp, >cp2
      mov.i  dt, >cp2
      jmp clr
cp2   dat    0, {off}
inc   dat    step, step
ptr   dat    0, 0
sp    spl    0, <-3
dt    dat    0, <-4
"""
    return s
if __name__=="__main__":
    for kw in [dict(),dict(N=300),dict(N=1000),dict(N=2000),dict(step=41,N=1000)]:
        open('t.red','w').write(gen(**kw))
        r=subprocess.run(['python3','tools/battle.py','t.red','--rounds','40'],capture_output=True,text=True).stdout.strip().splitlines()[-1]
        print(kw,r,flush=True)
