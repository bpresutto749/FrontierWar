from st2 import run
from concurrent.futures import ThreadPoolExecutor
A=""";redcode-94
;name St
;author x
org s
s    add.ab #{st}, p
     mov.i  dt, @p
     mov.i  dt, <p
     jmp s
p    dat 0, 0
dt   dat 0, 0
"""
B=""";redcode-94
;name St
;author x
org s
s    add.ab #{st}, p
     mov.i  dt, @p
     jmp s
p    dat 0, {o}
dt   dat 0, 0
"""
C=""";redcode-94
;name St
;author x
org s
s    mov.i  dt, @p
     add.ab #{st}, p
     mov.i  dt, @p
     add.ab #{st2}, p
     jmp s
p    dat 0, {o}
dt   dat 0, 0
"""
jobs=[(A,dict(st=s),f"A{s}") for s in [7,9,15,17]]+[(B,dict(st=s,o=o),f"B{s}_{o}") for s in [15,14,16] for o in [0,1000,3000]]+[(C,dict(st=s,st2=s2),f"C{s}_{s2}") for s,s2 in [(7,8),(15,15),(15,16),(9,13)]]
def f(j): return j[2],run(j[0].format(**j[1]),j[2]+".red",100)
with ThreadPoolExecutor(2) as ex:
    for j,r in ex.map(f,jobs): print(j,r,flush=True)
