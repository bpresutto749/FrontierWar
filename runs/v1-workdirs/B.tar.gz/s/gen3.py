import sys, random
def gen(S=3364,GAP=8,BD=5500,ndecoy=40,cnt=1200,S0=None,init=100,SKIP=None,WL=40,WH=20,seed=1,dbomb='dat #dbomb-gate, SKIPV'):
    if S0 is None: S0=(S*3)%8000
    lines=f"""gate    dat   sbomb-gate, {init}
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  {S0}, {(S0+GAP)%8000}
        jmp    found
cnt     djn.b  sstart, #{cnt}
clear   spl    #0, 0
cl      mov    *gate, >gate
        djn.f  cl, >gate
found   mov.ab  sc, tmp
        add.ab  #{WL}, tmp
        slt.ab  #{WL+WH}, tmp
        jmp     cnt
        mov.ab  sc, gate
        jmp     cnt
tmp     dat    0, 0
sbomb   spl    #dbomb-gate, SKIPV
dbomb   {dbomb}
inc     dat    {S}, {S}
"""
    n=len(lines.strip().splitlines())
    if SKIP is None: SKIP=n
    lines=lines.replace('SKIPV',str(SKIP))
    boot="".join(f"        mov.i  gate+{i}, gate+{i}+{BD}\n" for i in range(n))
    boot+=f"        jmp    gate+1+{BD}\n"
    r=random.Random(seed)
    mods=['.a','.b','.ab','.ba','.f','.x','.i']
    modes=['#','$','@','<','>','*','{','}']
    dec=""
    for i in range(ndecoy):
        dec+=f"        {r.choice(['dat','spl','mov','jmz','sne'])}{r.choice(mods)} {r.choice(modes)}{r.randint(1,7999)}, {r.choice(modes)}{r.randint(1,7999)}\n"
    return ";redcode-94\n;name Sweeper\n;author anon\n;strategy booted 0.5c scanner, spl carpet, spl/dat clear, decoy\n;assert CORESIZE==8000\n        org boot\nboot\n"+boot+lines+dec+"end\n"
if __name__=='__main__':
    a=list(map(int,sys.argv[2:]))
    open(sys.argv[1],'w').write(gen(*a))
