import sys
def gen(S,GAP,S0=None,bomb='spl #0, 0',cbomb='dat <2667, cbomb-gate+2'):
    if S0 is None: S0=S
    # sc at offset 0; code spans -3..+8
    lo,hi=-3-2,8+2
    k=0;a=S0;cnt=None
    for k in range(1,8000):
        A=(S0+(k-1)*S)%8000; B=(A+GAP)%8000
        def inside(x):
            x=((x+4000)%8000)-4000
            return lo<=x<=hi
        if inside(A) or inside(B):
            cnt=k-1;break
    if cnt is None: cnt=4000
    return f""";redcode-94
;name Sweeper
;author anon
;strategy 0.5c scanner with spl carpet, then d-clear
;assert CORESIZE==8000
        org loop
gate    dat   0, 0
loop    mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  {S0-S}, {S0-S+GAP}
        mov.ab sc, gate
        djn.b  loop, #{cnt}
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   {cbomb}
inc     dat    {S}, {S}
sbomb   {bomb}
end
""",cnt
if __name__=='__main__':
    S=int(sys.argv[1]);G=int(sys.argv[2])
    src,c=gen(S,G); open(sys.argv[3],'w').write(src); print(c)
