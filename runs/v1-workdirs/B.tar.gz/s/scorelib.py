import random, subprocess, sys, os, re
from concurrent.futures import ThreadPoolExecutor
H='/tmp/arena_B'
opps=sorted(os.path.join(H,'sparring',f) for f in os.listdir(H+'/sparring'))
def score(path, rounds=40):
    def one(o):
        p=subprocess.run([H+'/bin/pmars','-b','-k','-r',str(rounds),'-f',path,o],capture_output=True,text=True)
        l=[x for x in p.stdout.strip().splitlines() if x.split() and x.split()[0].lstrip('-').isdigit()]
        w1,t1=map(int,l[-2].split()[:2]); return (3*w1+t1)/(3*rounds)
    with ThreadPoolExecutor(2) as ex: r=list(ex.map(one,opps))
    return sum(r)/len(r)
