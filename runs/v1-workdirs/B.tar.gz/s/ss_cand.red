;redcode-94
;name Sweeper
;author anon
;strategy 0.5c scanner with spl carpet, then d-clear
;assert CORESIZE==8000
        org loop
gate    dat   0, 0
loop    mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  7992, 3
        mov.ab sc, gate
        djn.b  loop, #508
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   dat <2667, cbomb-gate+2
inc     dat    7057, 7057
sbomb   spl #-1, <-2
end
