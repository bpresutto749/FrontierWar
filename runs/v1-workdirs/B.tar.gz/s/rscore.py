import subprocess, sys, os
from concurrent.futures import ThreadPoolExecutor
H='/tmp/arena_B'
opps=sorted(os.path.join(H,'sparring',f) for f in os.listdir(H+'/sparring'))
def one(a):
    path,o,r=a
    p=subprocess.run([H+'/bin/pmars','-b','-k','-r',str(r),path,o],capture_output=True,text=True)
    l=[x for x in p.stdout.strip().splitlines() if x.split() and x.split()[0].lstrip('-').isdigit()]
    w1,t1=map(int,l[-2].split()[:2]); return (3*w1+t1)/(3*r)
for path in sys.argv[2:]:
    with ThreadPoolExecutor(2) as ex: res=list(ex.map(one,[(path,o,int(sys.argv[1])) for o in opps]))
    print(path, round(sum(res)/len(res),3), ' '.join(f'{x:.2f}' for x in res))
