import sys, math
LO,HI=-3,8
def best_s0(S,GAP,margin=2):
    W=list(range(LO-margin,HI+margin+1))
    g=math.gcd(S,8000); N=8000//g
    first=[None]*8000
    for k in range(N+5):
        for w in W:
            for off in (0,GAP):
                s0=(w-off-k*S)%8000
                if first[s0] is None: first[s0]=k
    # S0 = position at k=0 ... ensure min distance from self large too
    cands=[(first[s] if first[s] is not None else 10**6, s) for s in range(8000)]
    f,s=max(cands)
    return s,f,N
def gen(S,GAP,bomb='spl #0, 0',cbomb='dat <2667, cbomb-gate+2',name='Sweeper'):
    s0,f,N=best_s0(S,GAP)
    cnt=min(f, 4000)
    # scan starts at sc.A=s0 after first add => initial A = s0 - S
    return f""";redcode-94
;name {name}
;author anon
;strategy 0.5c scanner with spl carpet, then d-clear
;assert CORESIZE==8000
        org loop
gate    dat   0, 0
loop    mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  {(s0-S)%8000}, {(s0-S+GAP)%8000}
        mov.ab sc, gate
        djn.b  loop, #{cnt}
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   {cbomb}
inc     dat    {S}, {S}
sbomb   {bomb}
end
""",(s0,f,N)
if __name__=='__main__':
    S=int(sys.argv[1]);G=int(sys.argv[2])
    src,c=gen(S,G); open(sys.argv[3],'w').write(src); print(c)
