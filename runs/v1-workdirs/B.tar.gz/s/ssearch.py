import random, sys
sys.path.insert(0,'/tmp/arena_B/s')
from gensc2 import gen
from scorelib import score
random.seed(int(sys.argv[2]))
best=-1
bombs=['spl #0, 0','spl #1, #1','spl.i #0, >1','spl #-1, <-2']
for i in range(int(sys.argv[1])):
    S=random.randint(2,7998); G=random.randint(1,30); b=random.choice(bombs)
    src,info=gen(S,G,bomb=b)
    if info[1]<150: continue
    fn='/tmp/arena_B/s/ss_cand.red'; open(fn,'w').write(src)
    s=score(fn,30)
    if s>best:
        best=s; open('/tmp/arena_B/s/ss_best.red','w').write(src); print(i,round(s,3),S,G,b,info,flush=True)
