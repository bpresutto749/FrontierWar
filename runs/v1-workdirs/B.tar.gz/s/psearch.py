import random, sys
sys.path.insert(0,'/tmp/arena_B/s')
from gen2p import gen
from gencombo import best_s0
from scorelib import score
random.seed(int(sys.argv[2]))
best=-1
for i in range(int(sys.argv[1])):
    S=random.randint(2,7998); G=random.randint(1,20); BD=random.randint(200,7800)
    s0,cnt=best_s0(S,G,-3,8)
    if cnt<300: continue
    src=gen(S,G,BD,40)
    fn='/tmp/arena_B/s/ps_cand.red'; open(fn,'w').write(src)
    s=score(fn,40)
    if s>best:
        best=s; open('/tmp/arena_B/s/ps_best.red','w').write(src); print(i,round(s,3),S,G,BD,cnt,flush=True)
