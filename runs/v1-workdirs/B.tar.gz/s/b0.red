;redcode-94
;name Sweeper
;author anon
;strategy booted 0.5c scanner, spl carpet, d-clear, decoy
;assert CORESIZE==8000
        org boot
boot
        mov.i  gate+0, gate+0+4000
        mov.i  gate+1, gate+1+4000
        mov.i  gate+2, gate+2+4000
        mov.i  gate+3, gate+3+4000
        mov.i  gate+4, gate+4+4000
        mov.i  gate+5, gate+5+4000
        mov.i  gate+6, gate+6+4000
        mov.i  gate+7, gate+7+4000
        mov.i  gate+8, gate+8+4000
        mov.i  gate+9, gate+9+4000
        mov.i  gate+10, gate+10+4000
        mov.i  gate+11, gate+11+4000
        jmp    gate+1+4000
gate    dat   0, 0
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  6, 14
        mov.ab sc, gate
        djn.b  sstart, #477
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   dat <2667, cbomb-gate+2
inc     dat    3364, 3364
sbomb   spl #0, 0
end
