;redcode-94
;name Switchblade
;author anon
;strategy p-space switch: scanner / paper
;assert CORESIZE==8000
        org think
think   ldp.ab #0, in
        ldp.ab #77, sel
        jmn.b  keep, in
        add.ab #1, sel
keep    mod.ab #2, sel
        stp.b  sel, #77
        jmz.b  sstart, sel
        jmp    pstart
in      dat 0, 0
sel     dat 0, 0
pstart  spl 1, <-500
        spl 1, <-1500
        spl 1, <-2500
p1      spl @0, >5537
        mov.i }-1, >-1
p2      spl @0, >4265
        mov.i }-1, >-1
        mov.i pbmb, >984
        mov.i pbmb, }-984
pbmb    dat <2667, <5334
gate    dat   0, 0
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  7986, 7994
        mov.ab sc, gate
        djn.b  sstart, #282
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   dat    <2667, cbomb-gate+2
inc     dat    3364, 3364
sbomb   spl #0, 0
end
