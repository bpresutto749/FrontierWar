;redcode-94
;name Switchblade
;author anon
;strategy p-space switch: scanner / paper
;assert CORESIZE==8000
        org think
think   ldp.ab #0, in
        ldp.ab #77, sel
        jmn.b  keep, in
        add.ab #1, sel
keep    mod.ab #2, sel
        stp.b  sel, #77
        jmz.b  sstart, sel
        jmp    istart
in      dat 0, 0
sel     dat 0, 0
istart  spl  stone
        spl  1
        mov  -1, 0
        spl  1
        spl  2
        jmp  @0, imp
        add  #2667, -1
        dat  0, 0
imp     mov.i #2667, *0
        dat 0,0
stone   spl  #0, <-30
slp     mov  sbmb, @sptr
        add  #3315, sptr
        djn.f slp, <-40
sptr    dat  0, 3315
sbmb    dat  >-1, >1
gate    dat   0, 0
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  7980, 7988
        mov.ab sc, gate
        djn.b  sstart, #282
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   dat    <2667, cbomb-gate+2
inc     dat    3364, 3364
sbomb   spl #0, 0
end
