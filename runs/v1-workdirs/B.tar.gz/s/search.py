import random, subprocess, sys, os, re
from concurrent.futures import ThreadPoolExecutor
H='/tmp/arena_B'
opps=sorted(os.path.join(H,'sparring',f) for f in os.listdir(H+'/sparring'))
def score(path, rounds=40):
    def one(o):
        p=subprocess.run([H+'/bin/pmars','-b','-k','-r',str(rounds),'-f',path,o],capture_output=True,text=True)
        l=[x for x in p.stdout.strip().splitlines() if x.split() and x.split()[0].lstrip('-').isdigit()]
        w1,t1=map(int,l[-2].split()[:2]); return (3*w1+t1)/(3*rounds)
    with ThreadPoolExecutor(2) as ex: r=list(ex.map(one,opps))
    return sum(r)/len(r)
tmpl=open(sys.argv[1]).read()
names=sys.argv[2].split(',')
n=int(sys.argv[3]); tag=sys.argv[4]
best=(-1,None)
random.seed(int(sys.argv[5]) if len(sys.argv)>5 else None)
for i in range(n):
    vals={k:random.randint(100,7900) for k in names}
    src=tmpl
    for k,v in vals.items(): src=src.replace('@'+k+'@',str(v))
    fn=f'/tmp/arena_B/s/{tag}_cand.red'; open(fn,'w').write(src)
    s=score(fn)
    if s>best[0]:
        best=(s,vals); open(f'/tmp/arena_B/s/{tag}_best.red','w').write(src)
        print(i,round(s,3),vals,flush=True)
