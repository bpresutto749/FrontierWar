import random, sys
sys.path.insert(0,'/tmp/arena_B/s')
from gen2p import gen
from gencombo import best_s0
from scorelib import score
random.seed(int(sys.argv[2]))
cur=dict(S=3364,GAP=8,BD=5500,nd=40,init=100)
def mk(p):
    return gen(p['S'],p['GAP'],p['BD'],p['nd'],init=p['init'])
fn='/tmp/arena_B/s/ls_cand.red'
open(fn,'w').write(mk(cur)); best=score(fn,100); print('base',best,flush=True)
for i in range(int(sys.argv[1])):
    p=dict(cur); k=random.choice(['S','S','GAP','BD','nd','init'])
    if k=='S': p['S']=random.randint(2,7998) if random.random()<0.5 else (p['S']+random.randint(-50,50))%8000
    elif k=='GAP': p['GAP']=max(1,p['GAP']+random.randint(-4,4))
    elif k=='BD': p['BD']=random.randint(200,7800)
    elif k=='nd': p['nd']=random.choice([0,10,20,30,40,50,60])
    else: p['init']=random.randint(1,7999)
    s0,cnt=best_s0(p['S'],p['GAP'],-3,8)
    if cnt<300: continue
    open(fn,'w').write(mk(p)); s=score(fn,100)
    if s>best:
        best=s; cur=p; open('/tmp/arena_B/s/ls_best.red','w').write(mk(p)); print(i,round(s,3),p,cnt,flush=True)
