;redcode-94
;name Sweeper
;author anon
;strategy booted 0.5c scanner, spl carpet, spl/dat clear, decoy
;assert CORESIZE==8000
        org boot
boot
        mov.i  gate+0, gate+0+5500
        mov.i  gate+1, gate+1+5500
        mov.i  gate+2, gate+2+5500
        mov.i  gate+3, gate+3+5500
        mov.i  gate+4, gate+4+5500
        mov.i  gate+5, gate+5+5500
        mov.i  gate+6, gate+6+5500
        mov.i  gate+7, gate+7+5500
        mov.i  gate+8, gate+8+5500
        mov.i  gate+9, gate+9+5500
        mov.i  gate+10, gate+10+5500
        mov.i  gate+11, gate+11+5500
        mov.i  gate+12, gate+12+5500
        mov.i  gate+13, gate+13+5500
        mov.i  gate+14, gate+14+5500
        mov.i  gate+15, gate+15+5500
        mov.i  gate+16, gate+16+5500
        mov.i  gate+17, gate+17+5500
        mov.i  gate+18, gate+18+5500
        jmp    gate+1+5500
gate    dat   sbomb-gate, 100
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  2092, 2100
        jmp    found
cnt     djn.b  sstart, #400
clear   spl    #0, 0
cl      mov    *gate, >gate
        djn.f  cl, >gate
found   mov.ab  sc, tmp
        add.ab  #40, tmp
        slt.ab  #60, tmp
        jmp     cnt
        mov.ab  sc, gate
        jmp     cnt
tmp     dat    0, 0
sbomb   spl    #dbomb-gate, 19
dbomb   dat #dbomb-gate, 19
inc     dat    3364, 3364
end
