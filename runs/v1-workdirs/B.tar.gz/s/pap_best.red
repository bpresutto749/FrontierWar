;redcode-94
;name Papyrus
;author anon
;strategy silk paper
;assert CORESIZE==8000
s1 equ 5537
s2 equ 4265
bs equ 984
go      spl 1, <-500
        spl 1, <-1500
        spl 1, <-2500
p1      spl @0, >s1
        mov.i }-1, >-1
p2      spl @0, >s2
        mov.i }-1, >-1
        mov.i bmb, >bs
        mov.i bmb, }-bs
bmb     dat <2667, <5334
end go
