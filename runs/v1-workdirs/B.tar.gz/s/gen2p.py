import sys, random
from gencombo import best_s0
def gen(S=3364,GAP=8,BD=5500,ndecoy=40,init=100,SKIP=12,seed=1,dbomb='dat #dbomb-gate, 12'):
    s0,cnt=best_s0(S,GAP,-3,8)
    sc=f"""gate    dat   sbomb-gate, {init}
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  {(s0-S)%8000}, {(s0-S+GAP)%8000}
        mov.ab sc, gate
        djn.b  sstart, #{cnt}
clear   spl    #0, 0
cl      mov    *gate, >gate
        djn.f  cl, >gate
sbomb   spl    #dbomb-gate, {SKIP}
dbomb   {dbomb}
inc     dat    {S}, {S}
"""
    n=12
    boot="".join(f"        mov.i  gate+{i}, gate+{i}+{BD}\n" for i in range(n))
    boot+=f"        jmp    gate+1+{BD}\n"
    r=random.Random(seed)
    mods=['.a','.b','.ab','.ba','.f','.x','.i']
    modes=['#','$','@','<','>','*','{','}']
    dec=""
    for i in range(ndecoy):
        dec+=f"        {r.choice(['dat','spl','mov','jmz','sne'])}{r.choice(mods)} {r.choice(modes)}{r.randint(1,7999)}, {r.choice(modes)}{r.randint(1,7999)}\n"
    return ";redcode-94\n;name Sweeper\n;author anon\n;strategy booted 0.5c scanner, spl carpet, spl/dat clear, decoy\n;assert CORESIZE==8000\n        org boot\nboot\n"+boot+sc+dec+"end\n"
if __name__=='__main__':
    open(sys.argv[1],'w').write(gen(int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])))
