import math, sys
def best_s0(S,GAP,LO,HI,margin=2):
    W=list(range(LO-margin,HI+margin+1))
    g=math.gcd(S,8000); N=8000//g
    first=[None]*8000
    for k in range(N+5):
        for w in W:
            for off in (0,GAP):
                s0=(w-off-k*S)%8000
                if first[s0] is None: first[s0]=k
    f,s=max(((first[s] if first[s] is not None else 10**6), s) for s in range(8000))
    return s,min(f,4000)
def scanner(S,GAP,LO,HI,bomb='spl #0, 0'):
    s0,cnt=best_s0(S,GAP,LO,HI)
    return f"""gate    dat   0, 0
sstart  mov.i  sbomb, >gate
        add.f  inc, sc
sc      seq.i  {(s0-S)%8000}, {(s0-S+GAP)%8000}
        mov.ab sc, gate
        djn.b  sstart, #{cnt}
clear   spl    #0, 0
cl      mov    cbomb, >gate
        djn.f  cl, >gate
cbomb   dat    <2667, cbomb-gate+2
inc     dat    {S}, {S}
sbomb   {bomb}
"""
def paper(s1=5537,s2=4265,bs=984):
    return f"""pstart  spl 1, <-500
        spl 1, <-1500
        spl 1, <-2500
p1      spl @0, >{s1}
        mov.i }}-1, >-1
p2      spl @0, >{s2}
        mov.i }}-1, >-1
        mov.i pbmb, >{bs}
        mov.i pbmb, }}-{bs}
pbmb    dat <2667, <5334
"""
def stoneimp(step=3315):
    return f"""istart  spl  stone
        spl  1
        mov  -1, 0
        spl  1
        spl  2
        jmp  @0, imp
        add  #2667, -1
        dat  0, 0
imp     mov.i #2667, *0
        dat 0,0
stone   spl  #0, <-30
slp     mov  sbmb, @sptr
        add  #{step}, sptr
        djn.f slp, <-40
sptr    dat  0, {step}
sbmb    dat  >-1, >1
"""
def think(other,PS=77):
    return f"""think   ldp.ab #0, in
        ldp.ab #{PS}, sel
        jmn.b  keep, in
        add.ab #1, sel
keep    mod.ab #2, sel
        stp.b  sel, #{PS}
        jmz.b  sstart, sel
        jmp    {other}
in      dat 0, 0
sel     dat 0, 0
"""
def combo(S=3364,GAP=8,other='paper',**kw):
    o = paper(**kw) if other=='paper' else stoneimp(**kw)
    lab = 'pstart' if other=='paper' else 'istart'
    pre = think(lab)+o
    npre=len([l for l in pre.splitlines() if l.strip()])
    # sc is at offset npre+3 from start; code spans start..end
    LO=-(npre+3); HI=8
    body=pre+scanner(S,GAP,LO,HI)
    return ";redcode-94\n;name Switchblade\n;author anon\n;strategy p-space switch: scanner / paper\n;assert CORESIZE==8000\n        org think\n"+body+"end\n"
if __name__=='__main__':
    open(sys.argv[1],'w').write(combo(other=sys.argv[2]))
