;redcode-94
;name sitter
 jmp 0
