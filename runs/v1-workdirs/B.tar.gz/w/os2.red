;redcode-94
;name OneShotTest2
;author anon
;assert CORESIZE==8000
STEP equ 3359
GAP  equ 1678
LAG  equ 40
SKIP equ (inc-gate+2)
        org scan
gate    dat   0, 0
scan    add.f inc, comp
comp    sne.i 400, 400+GAP
        jmp   scan
        mov.ab comp, gate
        mov.ab comp, gate
        mov.a  comp, gate
        sub.a  #LAG, gate
clr     spl   #0, 0
cl      mov   sb, >gate
        mov   db, }gate
        jmp   cl
sb      spl   #SKIP, SKIP
db      dat   SKIP, SKIP
inc     dat   STEP, STEP
end
