;redcode-94
;name OneShotTest
;author anon
;assert CORESIZE==8000
STEP equ 3359
GAP  equ 1678
        org scan
gate    dat   0, 0
scan    add.f inc, comp
comp    sne.i 400, 400+GAP
        jmp   scan
        mov.ab comp, gate
clr     spl   #0, 0
cl      mov   bomb, >gate
        djn.f cl, >gate
bomb    dat   <2667, bomb-gate+2
inc     dat   STEP, STEP
end
