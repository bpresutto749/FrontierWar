;redcode-94
;name StoneImp
;author anon
;assert CORESIZE==8000
is   equ 2667
step equ 3315
go      spl  stone
        spl  1
        mov  -1, 0
        spl  1
        spl  2
        jmp  @0, imp
        add  #is, -1
        dat  0, 0
imp     mov.i #is, *0
        dat 0,0
        dat 0,0
stone   spl  #0, <-30
lp      mov  bmb, @ptr
        add  #step, ptr
        djn.f lp, <-40
ptr     dat  0, step
bmb     dat  >-1, >1
end go
