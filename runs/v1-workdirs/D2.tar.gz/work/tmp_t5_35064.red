;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy quick probe sets the carpet start, then boot away a 0.4c seq scanner
;strategy with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     qgo
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2

qgo
        seq.i   ptr+300, ptr+4300
        mov.ab  #-7429, ptr
        seq.i   ptr+616, ptr+4616
        mov.ab  #-7113, ptr
        seq.i   ptr+932, ptr+4932
        mov.ab  #-6797, ptr
        seq.i   ptr+1248, ptr+5248
        mov.ab  #-6481, ptr
        seq.i   ptr+1564, ptr+5564
        mov.ab  #-6165, ptr
        seq.i   ptr+1880, ptr+5880
        mov.ab  #-5849, ptr
        seq.i   ptr+2196, ptr+6196
        mov.ab  #-5533, ptr
        seq.i   ptr+2512, ptr+6512
        mov.ab  #-5217, ptr
        seq.i   ptr+2828, ptr+6828
        mov.ab  #-4901, ptr
        seq.i   ptr+3144, ptr+7144
        mov.ab  #-4585, ptr
        seq.i   ptr+3460, ptr+7460
        mov.ab  #-4269, ptr
        seq.i   ptr+3776, ptr+7776
        mov.ab  #-3953, ptr
        seq.i   ptr+191, ptr+4191
        mov.ab  #-7538, ptr
        seq.i   ptr+507, ptr+4507
        mov.ab  #-7222, ptr
        seq.i   ptr+823, ptr+4823
        mov.ab  #-6906, ptr
        seq.i   ptr+1139, ptr+5139
        mov.ab  #-6590, ptr
        seq.i   ptr+1455, ptr+5455
        mov.ab  #-6274, ptr
        seq.i   ptr+1771, ptr+5771
        mov.ab  #-5958, ptr
        seq.i   ptr+2087, ptr+6087
        mov.ab  #-5642, ptr
        seq.i   ptr+2403, ptr+6403
        mov.ab  #-5326, ptr
        seq.i   ptr+2719, ptr+6719
        mov.ab  #-5010, ptr
        seq.i   ptr+3035, ptr+7035
        mov.ab  #-4694, ptr
        seq.i   ptr+3351, ptr+7351
        mov.ab  #-4378, ptr
        seq.i   ptr+3667, ptr+7667
        mov.ab  #-4062, ptr
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
