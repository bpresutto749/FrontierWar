;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     6140
off     equ     9
        org     boot
gate    dat     0,      0
ptr     dat     0,      6140
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        dat.f   >3,   >3
        spl.f   {5,   #9
        spl.f   >2,   >1
        dat.f   #2,   }6
        spl.a   >8,   #1
        spl.ba   >2,   @6
        spl.ab   $8,   >2
        spl.f   @2,   @9
        mov.i   }6,   {7
        spl.a   <8,   #2
        spl.x   }2,   $7
        spl.i   *8,   {1
        spl.f   *4,   @1
        spl.b   $2,   @1
        spl.ab   }1,   }9
        spl.ab   <9,   }7
        spl.a   {9,   <9
        dat.f   @6,   }5
        mov.i   $6,   $6
        mov.i   {1,   }8
        spl.b   *6,   @8
        spl.b   *5,   $4
        spl.i   #7,   >8
        dat.f   #3,   $8
        spl.x   $9,   *9
        mov.i   *3,   *7
        spl.ba   <4,   {8
        spl.ba   @8,   $8
        jmp.b   *1,   >7
        jmp.b   <4,   *6
boot
        mov.i   gate+0,  gate+6793+0
        mov.i   gate+1,  gate+6793+1
        mov.i   gate+2,  gate+6793+2
        mov.i   gate+3,  gate+6793+3
        mov.i   gate+4,  gate+6793+4
        mov.i   gate+5,  gate+6793+5
        mov.i   gate+6,  gate+6793+6
        mov.i   gate+7,  gate+6793+7
        mov.i   gate+8,  gate+6793+8
        mov.i   gate+9,  gate+6793+9
        mov.i   gate+10,  gate+6793+10
        mov.i   gate+11,  gate+6793+11
        jmp     top+6793
        spl.x   #9,   @1
        mov.i   >5,   $2
        spl.i   }1,   #7
        spl.i   #6,   <1
        spl.ab   @8,   }2
        spl.f   >8,   {2
        spl.a   $3,   >9
        spl.f   #4,   >8
        spl.x   {7,   $1
        spl.b   >2,   #4
        spl.i   *2,   {5
        spl.b   >6,   @5
        mov.i   <3,   *8
        mov.i   >2,   }3
        mov.i   @6,   {9
        spl.ab   {4,   #4
        spl.ba   <9,   *1
        dat.f   @1,   <8
        spl.ab   <9,   >9
        mov.i   #7,   <6
        spl.f   }6,   <3
        spl.ab   <3,   {4
        spl.ba   $2,   >4
        spl.ab   @3,   <8
        mov.i   @6,   *1
        mov.i   }5,   {2
        mov.i   {3,   }6
        spl.f   #3,   }4
        jmp.b   <2,   $3
        dat.f   @6,   <1
