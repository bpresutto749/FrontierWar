;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        jmp.b   <6,   #8
        spl.ba   #3,   $6
        mov.i   *7,   $4
        spl.a   *7,   <3
        spl.i   @2,   @8
        spl.ab   @1,   #4
        spl.ba   @3,   <6
        spl.ba   *3,   *7
        spl.f   #6,   {3
        spl.ab   <2,   >5
        jmp.b   #6,   $5
        spl.x   <8,   >3
        mov.i   }3,   #5
        spl.a   >7,   #9
        spl.i   >7,   #8
        spl.a   @4,   $4
        mov.i   >9,   >9
        spl.f   }2,   >5
        spl.a   {2,   *6
        dat.f   >3,   >5
boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
        dat.f   $5,   >5
        spl.ab   $3,   <8
        spl.ab   #2,   {1
        spl.ba   >5,   }7
        spl.ab   #1,   }6
        spl.ba   @3,   {2
        spl.ab   {6,   @1
        spl.i   <3,   }3
        dat.f   }8,   >8
        spl.f   <8,   {3
        spl.b   {9,   @8
        spl.x   @2,   }5
        dat.f   >2,   >1
        spl.f   >9,   <8
        spl.f   <6,   @1
        mov.i   <6,   <8
        spl.f   >6,   <6
        spl.i   >3,   }6
        spl.x   @9,   @4
        spl.x   }5,   $7
