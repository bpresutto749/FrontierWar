;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     5530
off     equ     5
        org     boot
gate    dat     0,      0
ptr     dat     0,      4000
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.ab   $5,   $8
        mov.i   }7,   *2
        mov.i   #7,   {1
        mov.i   <4,   $6
        spl.a   #1,   #7
        spl.ba   {1,   *8
        mov.i   *6,   *4
        mov.i   <1,   {9
        spl.b   @5,   $6
        dat.f   {9,   *5
        spl.f   }9,   {1
        mov.i   *7,   {3
        spl.x   >2,   }9
        spl.b   @9,   {6
        mov.i   #8,   #5
        jmp.b   {3,   @9
        spl.ba   #4,   *7
        dat.f   >6,   }5
        dat.f   #7,   @9
        dat.f   *7,   #8
        spl.x   *9,   {8
        spl.x   {6,   #9
        dat.f   >8,   #4
        spl.ab   @2,   <1
        spl.b   $1,   }1
        spl.f   *5,   $3
        spl.x   <2,   @3
        spl.f   @5,   <8
        spl.x   }8,   $1
        spl.f   {6,   {4
        spl.f   $5,   *7
        spl.a   *1,   {3
        spl.a   @8,   {9
        spl.ba   }4,   #7
        jmp.b   >7,   #5
        spl.ab   *1,   <2
        spl.b   <5,   @7
boot
        mov.i   gate+0,  gate+2101+0
        mov.i   gate+1,  gate+2101+1
        mov.i   gate+2,  gate+2101+2
        mov.i   gate+3,  gate+2101+3
        mov.i   gate+4,  gate+2101+4
        mov.i   gate+5,  gate+2101+5
        mov.i   gate+6,  gate+2101+6
        mov.i   gate+7,  gate+2101+7
        mov.i   gate+8,  gate+2101+8
        mov.i   gate+9,  gate+2101+9
        mov.i   gate+10,  gate+2101+10
        mov.i   gate+11,  gate+2101+11
        jmp     top+2101
        jmp.b   <3,   #9
        spl.a   *8,   @9
        spl.a   {4,   >2
        spl.ba   {4,   }2
        spl.i   <9,   }1
        spl.x   {5,   #3
        spl.ba   >3,   >7
        spl.ba   <2,   {9
        spl.x   }9,   *2
        spl.a   $3,   @3
        dat.f   *5,   >9
        spl.f   >6,   >2
        spl.f   *8,   @9
        spl.b   >1,   {2
        spl.i   @3,   >2
        jmp.b   {2,   *2
        spl.f   >5,   $8
        spl.f   $1,   <1
        jmp.b   #2,   {2
        spl.a   *4,   {3
        spl.b   }3,   *3
        spl.b   {7,   <9
        spl.f   }6,   $4
        spl.x   #1,   #5
        jmp.b   >8,   {6
        spl.i   $2,   >8
        spl.b   <4,   }6
        spl.f   @9,   *5
        spl.ba   *6,   $5
        spl.b   }2,   >4
        spl.i   <1,   >3
        spl.x   <4,   >2
        dat.f   $4,   *1
        spl.ba   {2,   <9
        spl.b   $1,   #5
        spl.x   }8,   @2
        dat.f   >2,   @3
