;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     5780
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      100
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.x   >7,   *2
        spl.x   #1,   @7
        spl.x   $5,   >6
        spl.f   @9,   #8
        dat.f   }8,   >4
        spl.x   >1,   @1
        spl.b   }9,   *6
        spl.b   @2,   <5
        spl.f   *7,   {1
        spl.f   >7,   {2
        jmp.b   *8,   >4
        spl.a   <3,   *3
        spl.f   {1,   }3
        spl.ab   $1,   }5
        spl.a   @1,   >3
        spl.b   <4,   @3
        spl.a   $4,   >5
        spl.b   >5,   $4
        jmp.b   @8,   <3
        spl.x   @1,   $9
        mov.i   >7,   @1
        spl.ba   #7,   {2
        spl.f   }9,   #1
        spl.b   @4,   {9
        spl.f   @5,   #6
        spl.ba   *9,   <6
        spl.i   {8,   @2
        dat.f   <6,   }2
        spl.ab   }7,   $3
        mov.i   *3,   $6
boot
        mov.i   gate+0,  gate+7288+0
        mov.i   gate+1,  gate+7288+1
        mov.i   gate+2,  gate+7288+2
        mov.i   gate+3,  gate+7288+3
        mov.i   gate+4,  gate+7288+4
        mov.i   gate+5,  gate+7288+5
        mov.i   gate+6,  gate+7288+6
        mov.i   gate+7,  gate+7288+7
        mov.i   gate+8,  gate+7288+8
        mov.i   gate+9,  gate+7288+9
        mov.i   gate+10,  gate+7288+10
        mov.i   gate+11,  gate+7288+11
        jmp     top+7288
        mov.i   <7,   @4
        dat.f   }9,   @9
        dat.f   $3,   <5
        jmp.b   *4,   @3
        spl.ba   <7,   <3
        spl.i   }9,   <2
        spl.i   *1,   {4
        spl.ba   >7,   #1
        spl.f   @7,   <3
        mov.i   *2,   >3
        spl.ba   }8,   >6
        spl.i   #4,   *9
        spl.f   {8,   }9
        spl.x   <8,   *6
        mov.i   <2,   *4
        spl.i   $4,   @9
        spl.x   $3,   {7
        spl.ab   $2,   >5
        spl.ab   @4,   }5
        spl.f   <6,   {6
        spl.ba   @6,   *1
        jmp.b   *4,   $9
        jmp.b   $3,   <8
        spl.a   @1,   >5
        spl.a   @6,   <3
        spl.f   }2,   #9
        spl.i   {5,   #8
        dat.f   $9,   >9
        mov.i   *3,   @8
        spl.f   @1,   <8
