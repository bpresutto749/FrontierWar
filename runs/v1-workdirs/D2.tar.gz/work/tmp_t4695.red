;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2

boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727

