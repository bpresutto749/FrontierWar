;redcode-94nop
;name Lattice Weave
;author Barthelemy Presutto
;strategy p-space switch: booted 0.4c seq scanner with spl carpet + clear / silk paper
;assert CORESIZE==8000
step    equ     190
off     equ     5
        org     sboot
gate    dat     0,      0
ptr     dat     0,      100
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.ab   $5,   $8
        mov.i   }7,   *2
        mov.i   #7,   {1
        mov.i   <4,   $6
        spl.a   #1,   #7
        spl.ba   {1,   *8
        mov.i   *6,   *4
        mov.i   <1,   {9
        spl.b   @5,   $6
        dat.f   {9,   *5
        spl.f   }9,   {1
        mov.i   *7,   {3
        spl.x   >2,   }9
        spl.b   @9,   {6
        mov.i   #8,   #5
sboot
        mov.i   gate+0,  gate+4000+0
        mov.i   gate+1,  gate+4000+1
        mov.i   gate+2,  gate+4000+2
        mov.i   gate+3,  gate+4000+3
        mov.i   gate+4,  gate+4000+4
        mov.i   gate+5,  gate+4000+5
        mov.i   gate+6,  gate+4000+6
        mov.i   gate+7,  gate+4000+7
        mov.i   gate+8,  gate+4000+8
        mov.i   gate+9,  gate+4000+9
        mov.i   gate+10,  gate+4000+10
        mov.i   gate+11,  gate+4000+11
        jmp     top+4000
        jmp.b   {3,   @9
        spl.ba   #4,   *7
        dat.f   >6,   }5
        dat.f   #7,   @9
        dat.f   *7,   #8
        spl.x   *9,   {8
        spl.x   {6,   #9
        dat.f   >8,   #4
        spl.ab   @2,   <1
        spl.b   $1,   }1
        spl.f   *5,   $3
        spl.x   <2,   @3
        spl.f   @5,   <8
        spl.x   }8,   $1
        spl.f   {6,   {4
think   ldp.ab  #0,     pres
        ldp.ab  #123,   pst
        jmz.b   swap,   pres
        mod.b   #2, pres
        jmn.b   keep,   pres
        jmz.b   keep,   pst
swap    add.b   #1,     pst
keep    mod.b   #2,     pst
        stp.b   pst,    #123
        jmn.b   pgo,    pst
        jmp     sboot
pres    dat     0,      0
pst     dat     0,      0
pgo    spl     1,      <-400
        spl     1,      <-800
        spl     1,      <-1200
pste   spl     @0,     >1313
        mov.i   }-1,    >-1
        spl     2900
        mov.i   >-1,    }-1
        mov.i   pbmb,   >7482
        mov.i   <-3,    <1
        djn.f   @0,     >4129
pbmb   dat     >5334,  >2667

