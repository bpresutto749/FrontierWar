import sys; sys.path.insert(0,'.')
import gen5, subprocess
from concurrent.futures import ThreadPoolExecutor
def score(src, rounds=300):
    fn=f'tmp_t5_{abs(hash(src))%100000}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
vars=[dict(nq=20,ndecoy=0),dict(nq=10,ndecoy=40),dict(nq=14,ndecoy=40),dict(nq=8,ndecoy=40,qr0=900),dict(nq=24,ndecoy=0,qd=4000),dict(nq=12,ndecoy=40,qd=3800)]
def f(v): return v, score(gen5.gen(**v))
with ThreadPoolExecutor(2) as ex:
    for v,s in ex.map(f,vars): print(v,s,flush=True)
