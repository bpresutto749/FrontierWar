;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     190
off     equ     5
        org     boot
gate    dat     0,      0
ptr     dat     0,      100
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.ab   $5,   $8
        mov.i   }7,   *2
        mov.i   #7,   {1
        mov.i   <4,   $6
        spl.a   #1,   #7
        spl.ba   {1,   *8
        mov.i   *6,   *4
        mov.i   <1,   {9
        spl.b   @5,   $6
        dat.f   {9,   *5
        spl.f   }9,   {1
        mov.i   *7,   {3
        spl.x   >2,   }9
        spl.b   @9,   {6
        mov.i   #8,   #5
        jmp.b   {3,   @9
        spl.ba   #4,   *7
        dat.f   >6,   }5
        dat.f   #7,   @9
        dat.f   *7,   #8
        spl.x   *9,   {8
        spl.x   {6,   #9
        dat.f   >8,   #4
        spl.ab   @2,   <1
        spl.b   $1,   }1
        spl.f   *5,   $3
        spl.x   <2,   @3
        spl.f   @5,   <8
        spl.x   }8,   $1
        spl.f   {6,   {4
boot
        mov.i   gate+0,  gate+1234+0
        mov.i   gate+1,  gate+1234+1
        mov.i   gate+2,  gate+1234+2
        mov.i   gate+3,  gate+1234+3
        mov.i   gate+4,  gate+1234+4
        mov.i   gate+5,  gate+1234+5
        mov.i   gate+6,  gate+1234+6
        mov.i   gate+7,  gate+1234+7
        mov.i   gate+8,  gate+1234+8
        mov.i   gate+9,  gate+1234+9
        mov.i   gate+10,  gate+1234+10
        mov.i   gate+11,  gate+1234+11
        jmp     top+1234
        spl.f   $5,   *7
        spl.a   *1,   {3
        spl.a   @8,   {9
        spl.ba   }4,   #7
        jmp.b   >7,   #5
        spl.ab   *1,   <2
        spl.b   <5,   @7
        jmp.b   <3,   #9
        spl.a   *8,   @9
        spl.a   {4,   >2
        spl.ba   {4,   }2
        spl.i   <9,   }1
        spl.x   {5,   #3
        spl.ba   >3,   >7
        spl.ba   <2,   {9
        spl.x   }9,   *2
        spl.a   $3,   @3
        dat.f   *5,   >9
        spl.f   >6,   >2
        spl.f   *8,   @9
        spl.b   >1,   {2
        spl.i   @3,   >2
        jmp.b   {2,   *2
        spl.f   >5,   $8
        spl.f   $1,   <1
        jmp.b   #2,   {2
        spl.a   *4,   {3
        spl.b   }3,   *3
        spl.b   {7,   <9
        spl.f   }6,   $4

