import sys, random
def gen(step=190, off=5, pinit=100, D=4000, ndecoy=60, seed=1, bomb="spl     #0,     0", satk="", dba="<2667", rt="ab", clr2=False, name="Lattice Sweep"):
    body = f"""gate    dat     0,      0
ptr     dat     0,      {pinit}
cbomb   {bomb}
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, {satk}2*step+off
        mov.{rt}  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
""" + ("""        mov.i   dbomb,  >gate
        jmp     clr,    <gate-50
""" if clr2 else """        djn.f   clr,    >gate
""") + f"""dbomb   dat     {dba},  dbomb-gate+2
"""
    n = len(body.strip().splitlines())
    rnd = random.Random(seed)
    ops = ["spl.a","spl.b","spl.ab","spl.ba","spl.f","spl.x","spl.i","mov.i","dat.f","jmp.b"]
    modes = ["#","$","@","*","<",">","{","}"]
    dec = []
    for i in range(ndecoy):
        dec.append(f"        {rnd.choice(ops)}   {rnd.choice(modes)}{rnd.randint(1,9)},   {rnd.choice(modes)}{rnd.randint(1,9)}")
    boot = []
    for i in range(n):
        boot.append(f"        mov.i   gate+{i},  gate+{D}+{i}")
    boot.append(f"        jmp     top+{D}")
    return f""";redcode-94nop
;name {name}
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     {step}
off     equ     {off}
        org     boot
""" + body + "\n".join(dec[:ndecoy//2]) + "\nboot\n" + "\n".join(boot) + "\n" + "\n".join(dec[ndecoy//2:]) + "\n"
if __name__=="__main__":
    a=sys.argv[1:]
    print(gen(*map(int,a)))
