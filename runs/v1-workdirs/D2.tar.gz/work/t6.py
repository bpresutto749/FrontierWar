import sys, random; sys.path.insert(0,'.')
import gen2, subprocess
from concurrent.futures import ThreadPoolExecutor
def score(src, rounds=300):
    fn=f'tmp_t6_{abs(hash(src))%100000}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
base=dict(step=1060, off=11, pinit=1060, D=7727, ndecoy=40, seed=20, bomb='spl     #step,  >step', satk='}')
rnd=random.Random(7)
vars=[]
for i in range(16):
    v=dict(base)
    k=rnd.choice(['step','D','seed','pinit','nd'])
    if k=='step':
        import math
        while True:
            s=rnd.randrange(20,8000,20)
            if math.gcd(s,8000)==20: break
        v['step']=s; v['pinit']=s
    elif k=='D': v['D']=rnd.randint(300,7700)
    elif k=='seed': v['seed']=rnd.randint(0,999)
    elif k=='pinit': v['pinit']=rnd.randint(50,7950)
    else: v['ndecoy']=rnd.choice([30,50,60,74])
    vars.append(v)
def f(v): return v, score(gen2.gen(**v))
res=[]
with ThreadPoolExecutor(2) as ex:
    for v,s in ex.map(f,vars):
        d={k:v[k] for k in v if v[k]!=base[k]}; print(d,s,flush=True); res.append((s,v))
res.sort(key=lambda x:-x[0]); print(res[0])
