import subprocess, sys, itertools, importlib, random
sys.path.insert(0,'.')
import gen_scan
def score(src):
    open('tmp_sw.red','w').write(src)
    out=subprocess.run(['python3','../tools/battle.py','tmp_sw.red'],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
res=[]
for step in [70,90,110,130,150,170,190,230,3330,2370,1990,5630,3150,770,1230]:
    for off in [5]:
        s=score(gen_scan.gen(step,off,100))
        res.append((s,step,off)); print(step,off,s,flush=True)
res.sort(); print(res[-5:])
