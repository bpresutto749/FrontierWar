;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.i   @3,   @3
        spl.ba   *7,   *1
        spl.a   <6,   }1
        mov.i   >2,   $8
        mov.i   $4,   #5
        dat.f   >7,   #6
        mov.i   #9,   @6
        dat.f   >7,   $3
        mov.i   {7,   <1
        spl.b   @3,   #8
        dat.f   }6,   >2
        spl.ba   *8,   }8
        mov.i   <7,   }3
        spl.f   $7,   #1
        spl.x   #2,   @6
        spl.x   @4,   *7
        spl.x   @4,   @1
        mov.i   #7,   *5
        spl.f   {6,   #2
        jmp.b   *1,   }7
boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
        spl.ab   {9,   {7
        mov.i   *8,   >9
        spl.i   *1,   #1
        spl.x   #8,   }6
        mov.i   {7,   *7
        spl.b   @2,   }9
        spl.a   #5,   @3
        spl.ab   *6,   #4
        mov.i   $6,   @8
        jmp.b   $1,   <3
        spl.f   {8,   @2
        jmp.b   #3,   <8
        spl.x   <3,   @1
        spl.ba   $3,   *2
        jmp.b   {2,   >8
        dat.f   <5,   <7
        dat.f   *4,   <4
        dat.f   *1,   >9
        spl.f   $4,   #7
        dat.f   *2,   >2
