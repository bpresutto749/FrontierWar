;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     7340
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      24
cbomb   spl     #-1,    >-1
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, >2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.x   }7,   *5
        spl.a   {4,   <5
        mov.i   }4,   $6
        spl.f   *6,   #1
        spl.i   {4,   >9
        mov.i   #2,   {3
        spl.b   *2,   <2
        dat.f   $1,   #4
        mov.i   }3,   {8
        dat.f   {3,   #8
        spl.i   *8,   >7
        spl.ab   @1,   @9
        spl.b   #3,   $9
        dat.f   {7,   {2
        spl.ab   #9,   #8
        spl.b   *1,   <8
        jmp.b   $9,   $1
        spl.x   >2,   $7
        spl.b   $6,   {7
        mov.i   }6,   >1
        spl.f   {9,   #4
        spl.x   $4,   }4
        spl.i   <9,   <3
        dat.f   <8,   #4
        dat.f   }7,   }9
        spl.ba   $7,   <8
        mov.i   $2,   @4
        spl.f   *9,   }5
        mov.i   @2,   }5
        spl.ab   }8,   >4
        spl.ab   #2,   }2
        spl.i   <1,   {2
        spl.f   *6,   @3
        spl.ab   $1,   *1
        jmp.b   >3,   }7
        spl.ab   #6,   <9
        spl.ab   {6,   @9
boot
        mov.i   gate+0,  gate+774+0
        mov.i   gate+1,  gate+774+1
        mov.i   gate+2,  gate+774+2
        mov.i   gate+3,  gate+774+3
        mov.i   gate+4,  gate+774+4
        mov.i   gate+5,  gate+774+5
        mov.i   gate+6,  gate+774+6
        mov.i   gate+7,  gate+774+7
        mov.i   gate+8,  gate+774+8
        mov.i   gate+9,  gate+774+9
        mov.i   gate+10,  gate+774+10
        mov.i   gate+11,  gate+774+11
        jmp     top+774
        dat.f   *9,   <4
        spl.f   #8,   @3
        mov.i   }1,   *3
        spl.b   >5,   @5
        spl.f   }7,   <7
        spl.x   >5,   >2
        spl.i   <3,   <7
        spl.b   #2,   #1
        spl.b   $1,   @2
        spl.i   <4,   {8
        mov.i   @8,   $3
        jmp.b   $9,   >9
        spl.x   #6,   >6
        spl.ba   @9,   @9
        spl.a   <3,   @3
        spl.x   $3,   *2
        spl.i   }8,   $7
        spl.i   >4,   $9
        spl.x   >6,   {9
        spl.x   <8,   @7
        spl.x   *5,   {1
        jmp.b   @8,   <2
        spl.ba   #6,   $4
        jmp.b   {8,   {6
        dat.f   }1,   }8
        dat.f   $7,   >6
        spl.ba   >3,   <6
        spl.x   @9,   @3
        spl.x   #2,   <8
        spl.f   @3,   *9
        spl.x   <1,   #8
        jmp.b   *9,   <3
        spl.f   $7,   #2
        mov.i   *1,   <9
        jmp.b   *9,   }3
        spl.ba   {4,   }9
        spl.ab   }2,   *8
