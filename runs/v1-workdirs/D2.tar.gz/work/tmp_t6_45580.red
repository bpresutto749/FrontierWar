;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.f   $2,   @4
        spl.a   >1,   *4
        spl.i   <6,   #9
        spl.b   {3,   <6
        jmp.b   $7,   {3
        spl.f   {2,   @3
        spl.ab   }4,   {3
        spl.a   $7,   }6
        spl.a   $4,   *1
        spl.a   @6,   #2
        jmp.b   {7,   @5
        spl.i   >9,   <6
        spl.ba   {4,   >7
        spl.ab   #8,   *5
        dat.f   @1,   *7
        spl.a   *4,   *9
        spl.i   <6,   >8
        spl.b   >1,   {5
        mov.i   >9,   <2
        dat.f   >4,   #8
boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
        spl.b   *5,   <6
        spl.i   }3,   <9
        spl.ba   *7,   }9
        spl.i   }6,   <2
        spl.i   {7,   >8
        spl.b   @2,   #9
        spl.ba   *4,   }7
        spl.b   <9,   }9
        mov.i   {5,   >4
        dat.f   @1,   *2
        spl.f   <9,   >9
        mov.i   $6,   >7
        jmp.b   {7,   {1
        spl.ab   #4,   $8
        spl.a   $4,   {1
        spl.ab   {2,   {7
        spl.x   *3,   @8
        spl.b   {6,   <8
        spl.ba   $4,   #3
        spl.i   >4,   @5
