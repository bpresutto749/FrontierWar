def paper_body(c1=1313, c2=2900, c3=4129, b1=7482, pfx="p"):
    return f"""{pfx}go    spl     1,      <-400
        spl     1,      <-800
        spl     1,      <-1200
{pfx}ste   spl     @0,     >{c1}
        mov.i   }}-1,    >-1
        spl     {c2}
        mov.i   >-1,    }}-1
        mov.i   {pfx}bmb,   >{b1}
        mov.i   <-3,    <1
        djn.f   @0,     >{c3}
{pfx}bmb   dat     >5334,  >2667
"""
def gen(**kw):
    return ";redcode-94nop\n;name Paper test\n;author Barthelemy Presutto\n;assert CORESIZE==8000\n        org pgo\n" + paper_body(**kw)
if __name__=="__main__":
    import sys
    a=list(map(int,sys.argv[1:]))
    print(gen(c1=a[0],c2=a[1],c3=a[2],b1=a[3]) if a else gen())
