;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     70
off     equ     5
        org     top
gate    dat     0,      0
ptr     dat     0,      2000
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2

