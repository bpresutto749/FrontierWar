;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     4940
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      4940
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        dat.f   {5,   >5
        spl.ab   <2,   #4
        spl.i   {5,   >7
        spl.ab   #3,   *3
        dat.f   *6,   $2
        spl.f   {2,   }3
        spl.i   >1,   {6
        jmp.b   #6,   #8
        spl.x   #7,   *2
        dat.f   *4,   >1
        spl.f   $5,   *9
        dat.f   @5,   <6
        spl.x   @6,   $5
        spl.x   #1,   >1
        mov.i   <8,   #4
        spl.f   <2,   }1
        jmp.b   @7,   }7
        spl.ab   *5,   @2
        spl.ba   #9,   <6
        spl.x   #3,   {2
        spl.f   <7,   }2
        dat.f   $9,   *4
        dat.f   <3,   <1
        mov.i   {8,   *9
        spl.i   }2,   }4
        spl.ba   }6,   *6
        jmp.b   #9,   {1
        spl.x   @9,   *6
        spl.x   @4,   <7
        spl.x   }2,   $9
boot
        mov.i   gate+0,  gate+1315+0
        mov.i   gate+1,  gate+1315+1
        mov.i   gate+2,  gate+1315+2
        mov.i   gate+3,  gate+1315+3
        mov.i   gate+4,  gate+1315+4
        mov.i   gate+5,  gate+1315+5
        mov.i   gate+6,  gate+1315+6
        mov.i   gate+7,  gate+1315+7
        mov.i   gate+8,  gate+1315+8
        mov.i   gate+9,  gate+1315+9
        mov.i   gate+10,  gate+1315+10
        mov.i   gate+11,  gate+1315+11
        jmp     top+1315
        spl.a   *9,   @8
        mov.i   }9,   @9
        dat.f   }8,   #5
        spl.f   @1,   }6
        spl.x   *1,   <2
        dat.f   #1,   $8
        spl.f   *2,   #8
        dat.f   *1,   {2
        spl.i   #9,   #4
        dat.f   <5,   >6
        dat.f   {7,   #9
        spl.x   $1,   <6
        spl.x   $6,   @9
        spl.ba   }5,   }2
        spl.f   *2,   {5
        spl.ba   }6,   @4
        dat.f   @5,   $7
        mov.i   {9,   @9
        spl.ab   @9,   >8
        spl.f   {2,   *3
        spl.ab   *7,   >9
        mov.i   @5,   *8
        spl.f   *6,   #2
        spl.x   }2,   {2
        dat.f   {4,   @2
        spl.f   $5,   >8
        spl.x   @3,   <5
        spl.i   >9,   @7
        spl.b   <4,   *4
        dat.f   >7,   {5
