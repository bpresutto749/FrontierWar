;redcode-94nop
;name Lattice Shot
;author Barthelemy Presutto
;strategy 0.67c one-shot seq scanner -> spl carpet near target -> dat clear
;assert CORESIZE==8000
step    equ     190
off     equ     5
        org     loop
gate    dat     0,      0
loop    add.f   inc,    scan
scan    sne.i   step,   step+off
        djn     loop,   #798
found   mov.ab  scan,   gate
        sub.b   #0, gate
cl      mov.i   sbomb,  >gate
        djn     cl,     #100
cl2     mov.i   dbomb,  >gate
        djn.f   cl2,    >gate
dbomb   dat     <2667,  dbomb-gate+2
sbomb   spl     #0,     0
inc     dat     step,   step
