import subprocess, sys, random, math, os
sys.path.insert(0,'.')
import gen2
def score(src, rounds=100, tag='x'):
    fn=f'tmp_{tag}.red'
    open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
rnd=random.Random(int(sys.argv[1]))
bombs=["spl     #0,     0","spl     #1,     #1","spl     #0,     <1","spl.b   #-1,    >-1","spl     #step,  >step"]
best=[]
N=int(sys.argv[2])
for it in range(N):
    while True:
        step=rnd.randrange(10,8000,10)
        if math.gcd(step,8000)==10: break
    p=dict(step=step, off=5, pinit=rnd.choice([100,-100,200,1000,4000,rnd.randint(1,7999)]), D=rnd.randint(200,7800), ndecoy=60, seed=rnd.randint(0,99), bomb=rnd.choice(bombs))
    s=score(gen2.gen(**p),100,sys.argv[1])
    best.append((s,p)); best.sort(key=lambda x:-x[0])
    print(it, s, p, flush=True)
print("TOP")
for b in best[:8]: print(b)
