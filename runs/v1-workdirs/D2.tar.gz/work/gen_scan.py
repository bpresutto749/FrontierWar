import sys
def gen(step=70, off=5, pinit=4000, name="Lattice Sweep"):
    return f""";redcode-94nop
;name {name}
;author Barthelemy Presutto
;strategy 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     {step}
off     equ     {off}
        org     top
gate    dat     0,      0
ptr     dat     0,      {pinit}
cbomb   spl     #0,     0
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
"""
if __name__=="__main__":
    a=sys.argv[1:]
    print(gen(int(a[0]),int(a[1]),int(a[2])))
