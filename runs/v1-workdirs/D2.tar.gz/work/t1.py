import sys; sys.path.insert(0,'.')
import gen2, subprocess
def score(src, rounds=200, tag='t1'):
    fn=f'tmp_{tag}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
for nd in [0,20,40,60,74]:
    print(nd, score(gen2.gen(step=190,off=5,pinit=100,D=4000,ndecoy=nd)), score(gen2.gen(step=5530,off=5,pinit=4000,D=2101,ndecoy=nd,bomb="spl     #step,  >step")))
