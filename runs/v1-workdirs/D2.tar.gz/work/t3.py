import sys; sys.path.insert(0,'.')
import gen3, subprocess
def score(src, rounds=100, tag='t3', full=False):
    fn=f'tmp_{tag}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    if full: print(out)
    return float(out.strip().splitlines()[-1].split()[-1])
print(score(gen3.gen(),full=True))
