;redcode-94nop
;name Paper test
;author Barthelemy Presutto
;assert CORESIZE==8000
        org pgo
pgo    spl     1,      <-400
        spl     1,      <-800
        spl     1,      <-1200
pst    spl     @0,     >3511
        mov.i   }-1,    >-1
        spl     1801
        mov.i   >-1,    }-1
        mov.i   pbmb,   >2373
        mov.i   <-3,    <1
        djn.f   @0,     >6217
pbmb   dat     >5334,  >2667

