;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     2260
off     equ     12
        org     boot
gate    dat     0,      0
ptr     dat     0,      4000
cbomb   spl     #1,     #1
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.b   #5,   *4
        spl.ab   $9,   $7
        spl.a   #2,   *4
        dat.f   #9,   *9
        spl.i   *8,   <1
        spl.ab   {6,   <3
        spl.ba   >2,   $7
        spl.b   >6,   <1
        mov.i   $7,   $9
        spl.f   >4,   $1
        spl.ba   <2,   *2
        spl.i   <8,   >3
        spl.x   >4,   <2
        jmp.b   @9,   *3
        mov.i   {5,   *6
        spl.a   *1,   >7
        spl.f   $4,   >4
        mov.i   {8,   @5
        spl.ab   *9,   <7
        jmp.b   {6,   *3
        dat.f   }2,   #2
        spl.ab   @7,   $7
        spl.i   }9,   <9
        spl.a   $9,   <6
        spl.b   <7,   @8
        spl.a   <9,   @9
        spl.b   <9,   *3
        spl.x   @9,   #6
        mov.i   #2,   >5
        spl.ba   #4,   $2
        mov.i   $9,   @3
        mov.i   @5,   {4
        dat.f   *5,   {6
        mov.i   }2,   *4
        spl.b   >1,   *4
        spl.a   $1,   *2
        spl.a   >2,   *5
boot
        mov.i   gate+0,  gate+4304+0
        mov.i   gate+1,  gate+4304+1
        mov.i   gate+2,  gate+4304+2
        mov.i   gate+3,  gate+4304+3
        mov.i   gate+4,  gate+4304+4
        mov.i   gate+5,  gate+4304+5
        mov.i   gate+6,  gate+4304+6
        mov.i   gate+7,  gate+4304+7
        mov.i   gate+8,  gate+4304+8
        mov.i   gate+9,  gate+4304+9
        mov.i   gate+10,  gate+4304+10
        mov.i   gate+11,  gate+4304+11
        jmp     top+4304
        mov.i   *9,   @8
        spl.ba   }7,   *2
        spl.b   {6,   {7
        mov.i   #2,   #7
        spl.x   $4,   *4
        dat.f   }3,   {3
        spl.f   }4,   $8
        dat.f   $1,   #2
        spl.ba   @7,   }8
        spl.ba   {1,   @7
        spl.a   {5,   }5
        spl.i   }3,   *5
        spl.ba   #9,   #6
        spl.a   #8,   @1
        dat.f   $3,   $2
        spl.ba   {2,   *1
        jmp.b   $7,   >5
        spl.ba   >4,   <7
        spl.ab   <8,   >2
        spl.a   }2,   $9
        spl.ba   <3,   >2
        spl.ba   >5,   @8
        dat.f   <9,   #9
        spl.f   $3,   <2
        spl.b   @5,   <4
        spl.x   *5,   }5
        spl.a   $7,   <1
        spl.a   >3,   <3
        mov.i   {9,   #2
        spl.b   @9,   #6
        jmp.b   @7,   @1
        spl.f   >1,   >4
        spl.ba   $6,   {3
        spl.ba   @3,   {1
        spl.ab   >7,   *5
        spl.ab   $7,   #8
        spl.ba   *8,   >5
