import random, sys
def gen(step=1060, off=11, pinit=1060, D=7727, ndecoy=30, seed=20, bomb="spl     #step,  >step", satk="}", dba="<2667",
        nq=20, qs=None, qd=None, qr0=300, qoff=-2, name="Lattice Sweep"):
    body = f"""gate    dat     0,      0
ptr     dat     0,      {pinit}
cbomb   {bomb}
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, {satk}2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     {dba},  dbomb-gate+2
"""
    n = len(body.strip().splitlines())
    rnd = random.Random(seed)
    ops = ["spl.a","spl.b","spl.ab","spl.ba","spl.f","spl.x","spl.i","mov.i","dat.f","jmp.b"]
    modes = ["#","$","@","*","<",">","{","}"]
    dec = [f"        {rnd.choice(ops)}   {rnd.choice(modes)}{rnd.randint(1,9)},   {rnd.choice(modes)}{rnd.randint(1,9)}" for i in range(ndecoy)]
    boot = [f"        mov.i   gate+{i},  gate+{D}+{i}" for i in range(n)] + [f"        jmp     top+{D}"]
    span = 7600
    if qs is None: qs = span // nq
    if qd is None: qd = qs // 2
    q = []
    Rs = []
    r = qr0
    while len(Rs) < nq:
        if not (D-40 <= r <= D+40 or D-40 <= r+qd <= D+40) and 150 <= r and r+qd <= 7850:
            Rs.append(r)
        r += qs
        if r > 7850: r = r - 7700 + 7
    for R in Rs:
        q.append(f"        seq.i   ptr+{R}, ptr+{R+qd}")
        q.append(f"        mov.ab  #{R-D+qoff}, ptr")
    return f""";redcode-94nop
;name {name}
;author Barthelemy Presutto
;strategy quick probe sets the carpet start, then boot away a 0.4c seq scanner
;strategy with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     {step}
off     equ     {off}
        org     qgo
""" + body + "\n".join(dec) + "\nqgo\n" + "\n".join(q) + "\n" + "\n".join(boot) + "\n"
if __name__=="__main__":
    print(gen())
