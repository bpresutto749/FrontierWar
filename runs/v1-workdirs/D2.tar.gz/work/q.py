import sys; sys.path.insert(0,'.')
from search import score
