import sys; sys.path.insert(0,'.')
import gen2, subprocess
def score(src, rounds=300, tag='t4'):
    fn=f'tmp_{tag}{abs(hash(src))%1000}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
base=dict(step=1060, off=11, pinit=1060, D=7727, ndecoy=40, seed=20, bomb='spl     #step,  >step', satk='}')
from concurrent.futures import ThreadPoolExecutor
vars=[{'rt':'b '},{'rt':'b ','seed':5},{'rt':'b ','off':9},{'rt':'b ','off':10},]#{},{'dba':'>2667'},{'dba':'0'},{'dba':'<5334'},{'dba':'>-1'},{'ndecoy':0},{'ndecoy':74},{'seed':5},{'off':9},{'off':10},{'off':12},{'pinit':4000},{'D':3000}]
def f(v):
    p=dict(base); p.update(v); return v, score(gen2.gen(**p))
with ThreadPoolExecutor(2) as ex:
    for v,s in ex.map(f,vars): print(v,s,flush=True)
