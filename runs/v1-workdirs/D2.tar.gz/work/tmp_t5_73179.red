;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy quick probe sets the carpet start, then boot away a 0.4c seq scanner
;strategy with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     qgo
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.ab   <2,   >3
        spl.a   {7,   $2
        spl.ab   >8,   }7
        spl.ba   *6,   >6
        spl.i   $9,   }7
        spl.b   *4,   #4
        spl.b   $4,   <5
        spl.f   <3,   $1
        spl.f   *4,   *1
        spl.a   <5,   @6
        jmp.b   }3,   <9
        spl.i   @3,   {2
        spl.ab   {6,   *2
        jmp.b   #9,   *7
        spl.ab   @2,   $5
        spl.a   >7,   }9
        spl.a   @2,   }9
        spl.x   #2,   $2
        spl.x   <2,   <1
        spl.a   *4,   #3
        spl.a   @5,   @7
        spl.f   $7,   $4
        spl.ba   *4,   $5
        spl.ab   {3,   $8
        mov.i   #3,   *5
        spl.i   $5,   *6
        jmp.b   <3,   $1
        spl.f   #7,   >5
        spl.i   }2,   $8
        spl.ba   #9,   $9
        jmp.b   >1,   @5
        spl.f   $1,   #4
        spl.ba   {2,   >5
        mov.i   #3,   {9
        spl.i   {5,   #8
        spl.b   }6,   *4
        spl.f   }6,   {4
        jmp.b   #6,   @2
        spl.x   #2,   }4
        dat.f   @5,   #3
qgo
        seq.i   ptr+300, ptr+4100
        mov.ab  #-7429, ptr
        seq.i   ptr+933, ptr+4733
        mov.ab  #-6796, ptr
        seq.i   ptr+1566, ptr+5366
        mov.ab  #-6163, ptr
        seq.i   ptr+2199, ptr+5999
        mov.ab  #-5530, ptr
        seq.i   ptr+2832, ptr+6632
        mov.ab  #-4897, ptr
        seq.i   ptr+3465, ptr+7265
        mov.ab  #-4264, ptr
        seq.i   ptr+203, ptr+4003
        mov.ab  #-7526, ptr
        seq.i   ptr+836, ptr+4636
        mov.ab  #-6893, ptr
        seq.i   ptr+1469, ptr+5269
        mov.ab  #-6260, ptr
        seq.i   ptr+2102, ptr+5902
        mov.ab  #-5627, ptr
        seq.i   ptr+2735, ptr+6535
        mov.ab  #-4994, ptr
        seq.i   ptr+3368, ptr+7168
        mov.ab  #-4361, ptr
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
