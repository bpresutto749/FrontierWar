import random, sys
sys.path.insert(0,'.')
from gen_paper import paper_body
def gen(step=190, off=5, pinit=100, D=4000, ndecoy=30, seed=1, bomb="spl     #0,     0",
        c1=1313, c2=2900, c3=4129, b1=7482, pidx=123, tieswitch=1, name="Lattice Weave"):
    body = f"""gate    dat     0,      0
ptr     dat     0,      {pinit}
cbomb   {bomb}
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
"""
    n = len(body.strip().splitlines())
    rnd = random.Random(seed)
    ops = ["spl.a","spl.b","spl.ab","spl.ba","spl.f","spl.x","spl.i","mov.i","dat.f","jmp.b"]
    modes = ["#","$","@","*","<",">","{","}"]
    dec = [f"        {rnd.choice(ops)}   {rnd.choice(modes)}{rnd.randint(1,9)},   {rnd.choice(modes)}{rnd.randint(1,9)}" for i in range(ndecoy)]
    boot = [f"        mov.i   gate+{i},  gate+{D}+{i}" for i in range(n)] + [f"        jmp     top+{D}"]
    # think: strategy 0 = scanner, 1 = paper
    think = f"""think   ldp.ab  #0,     pres
        ldp.ab  #{pidx},   pst
        jmz.b   swap,   pres
        mod.ab  #{2 if tieswitch else 99}, pres
        jmn.b   keep,   pres
        jmz.b   keep,   pst
swap    add.ab  #1,     pst
keep    mod.ab  #2,     pst
        stp.b   pst,    #{pidx}
        jmn.b   pgo,    pst
        jmp     sboot
pres    dat     0,      0
pst     dat     0,      0
"""
    return f""";redcode-94nop
;name {name}
;author Barthelemy Presutto
;strategy p-space switch: booted 0.4c seq scanner with spl carpet + clear / silk paper
;assert CORESIZE==8000
step    equ     {step}
off     equ     {off}
        org     think
""" + body + "\n".join(dec[:ndecoy//2]) + "\nsboot\n" + "\n".join(boot) + "\n" + "\n".join(dec[ndecoy//2:]) + "\n" + think + paper_body(c1,c2,c3,b1)
if __name__=="__main__":
    print(gen())
