;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     410
off     equ     5
        org     boot
gate    dat     0,      0
ptr     dat     0,      -100
cbomb   spl.b   #-1,    >-1
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, 2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        mov.i   {8,   #9
        mov.i   >2,   >2
        spl.f   <8,   >8
        spl.f   {1,   {9
        jmp.b   }4,   @4
        spl.ab   <8,   @8
        spl.a   <1,   $1
        spl.f   >4,   #2
        spl.i   $5,   >9
        spl.b   }5,   <4
        spl.ba   {1,   #5
        spl.x   }5,   #9
        spl.ab   }1,   <9
        spl.x   @6,   <7
        mov.i   }2,   {5
        spl.x   }6,   $5
        spl.i   {6,   #9
        dat.f   }6,   >7
        jmp.b   $6,   @1
        spl.i   <4,   >8
        spl.ba   @9,   *1
        spl.i   }6,   }4
        spl.a   {6,   $6
        spl.ab   @5,   *5
        mov.i   {8,   @7
        spl.ab   {2,   >4
        spl.ba   #9,   >9
        mov.i   <8,   *6
        spl.ab   >8,   #4
        spl.i   <5,   #3
boot
        mov.i   gate+0,  gate+6634+0
        mov.i   gate+1,  gate+6634+1
        mov.i   gate+2,  gate+6634+2
        mov.i   gate+3,  gate+6634+3
        mov.i   gate+4,  gate+6634+4
        mov.i   gate+5,  gate+6634+5
        mov.i   gate+6,  gate+6634+6
        mov.i   gate+7,  gate+6634+7
        mov.i   gate+8,  gate+6634+8
        mov.i   gate+9,  gate+6634+9
        mov.i   gate+10,  gate+6634+10
        mov.i   gate+11,  gate+6634+11
        jmp     top+6634
        spl.b   {4,   >3
        jmp.b   #4,   }9
        spl.x   >3,   >9
        spl.ab   #1,   >4
        spl.f   @3,   *3
        spl.i   $9,   <8
        spl.i   *3,   $7
        spl.ab   >3,   }4
        spl.f   *1,   }1
        jmp.b   {2,   $3
        spl.b   #6,   #4
        spl.ab   @2,   }4
        spl.f   $3,   }7
        spl.f   $1,   {8
        spl.a   >4,   }4
        dat.f   }4,   $9
        spl.b   <1,   *7
        spl.ba   $3,   $3
        spl.a   >3,   #2
        spl.f   #3,   $4
        spl.x   <1,   <2
        spl.ab   @6,   {2
        spl.i   *5,   >9
        jmp.b   #5,   $8
        jmp.b   #1,   @2
        spl.i   $6,   $1
        spl.ba   <1,   #8
        dat.f   >5,   @2
        mov.i   >6,   >1
        spl.a   @5,   $7
