import subprocess, sys, random, math
sys.path.insert(0,'.')
import gen2
def score(src, rounds=100, tag='x'):
    fn=f'tmp_{tag}.red'; open(fn,'w').write(src)
    out=subprocess.run(['python3','../tools/battle.py',fn,'--rounds',str(rounds)],capture_output=True,text=True).stdout
    return float(out.strip().splitlines()[-1].split()[-1])
rnd=random.Random(int(sys.argv[1]))
bombs=["spl     #0,     0","spl     #1,     #1","spl     #0,     <1","spl     #step,  >step","spl     #0,     {1","spl     #-1,    >-1"]
best=[]
for it in range(int(sys.argv[2])):
    g=rnd.choice([20,20,40])
    while True:
        step=rnd.randrange(g,8000,g)
        if math.gcd(step,8000)==g: break
    off = rnd.choice([8,9,10,11,12]) if g==20 else rnd.choice([15,18,20,22,25])
    if g==10: off=rnd.choice([4,5,6]) if False else 5
    p=dict(step=step, off=off, pinit=rnd.choice([100,4000,step,rnd.randint(1,7999)]), D=rnd.randint(200,7800), ndecoy=rnd.choice([40,60,74]), seed=rnd.randint(0,99), bomb=rnd.choice(bombs), satk=rnd.choice(['','}','>']))
    s=score(gen2.gen(**p),100,sys.argv[1])
    best.append((s,p)); best.sort(key=lambda x:-x[0])
print("TOP")
for b in best[:6]:
    print(round(score(gen2.gen(**b[1]),400,sys.argv[1]),3), b)
