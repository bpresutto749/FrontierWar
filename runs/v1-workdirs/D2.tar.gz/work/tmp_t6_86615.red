;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        spl.f   *2,   {9
        dat.f   }3,   $8
        spl.f   {7,   }6
        jmp.b   }6,   >9
        mov.i   #8,   >6
        spl.ba   $1,   {5
        mov.i   >8,   >3
        spl.x   #4,   >4
        spl.b   <7,   <8
        spl.f   @3,   @7
        dat.f   >4,   @3
        spl.ba   }4,   >3
        jmp.b   $6,   >8
        mov.i   #5,   <8
        spl.x   >3,   >9
        spl.b   #1,   $5
        spl.i   }4,   #2
        dat.f   $3,   #9
        spl.x   }2,   @9
        spl.ab   #8,   *2
boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
        mov.i   *9,   #9
        spl.b   @3,   {2
        mov.i   #6,   }2
        spl.ab   }7,   }1
        dat.f   {3,   *9
        spl.x   *4,   *8
        jmp.b   *4,   #8
        spl.a   <1,   }2
        dat.f   }8,   {3
        spl.b   #5,   *9
        spl.i   >6,   }2
        dat.f   *2,   }7
        spl.i   }1,   @7
        spl.i   $5,   @8
        spl.a   >6,   >8
        dat.f   }8,   #3
        spl.f   $1,   *3
        spl.a   *5,   @2
        spl.b   }8,   *7
        dat.f   <1,   >9
