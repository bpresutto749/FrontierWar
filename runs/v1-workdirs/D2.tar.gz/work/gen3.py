import sys
def gen(step=190, off=5, margin=2, cnt=None, sbcount=100, sbomb="spl     #0,     0", dbomb="dat     <2667,  dbomb-gate+2", name="Lattice Shot"):
    if cnt is None: cnt = 8000//10 - 2
    return f""";redcode-94nop
;name {name}
;author Barthelemy Presutto
;strategy 0.67c one-shot seq scanner -> spl carpet near target -> dat clear
;assert CORESIZE==8000
step    equ     {step}
off     equ     {off}
        org     loop
gate    dat     0,      0
loop    add.f   inc,    scan
scan    sne.i   step,   step+off
        djn     loop,   #{cnt}
found   mov.ab  scan,   gate
        sub.b   #{margin-2}, gate
cl      mov.i   sbomb,  >gate
        djn     cl,     #{sbcount}
cl2     mov.i   dbomb,  >gate
        djn.f   cl2,    >gate
dbomb   {dbomb}
sbomb   {sbomb}
inc     dat     step,   step
"""
