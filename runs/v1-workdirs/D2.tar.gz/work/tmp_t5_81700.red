;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy quick probe sets the carpet start, then boot away a 0.4c seq scanner
;strategy with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     qgo
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2

qgo
        seq.i   ptr+300, ptr+490
        mov.ab  #-7429, ptr
        seq.i   ptr+680, ptr+870
        mov.ab  #-7049, ptr
        seq.i   ptr+1060, ptr+1250
        mov.ab  #-6669, ptr
        seq.i   ptr+1440, ptr+1630
        mov.ab  #-6289, ptr
        seq.i   ptr+1820, ptr+2010
        mov.ab  #-5909, ptr
        seq.i   ptr+2200, ptr+2390
        mov.ab  #-5529, ptr
        seq.i   ptr+2580, ptr+2770
        mov.ab  #-5149, ptr
        seq.i   ptr+2960, ptr+3150
        mov.ab  #-4769, ptr
        seq.i   ptr+3340, ptr+3530
        mov.ab  #-4389, ptr
        seq.i   ptr+3720, ptr+3910
        mov.ab  #-4009, ptr
        seq.i   ptr+4100, ptr+4290
        mov.ab  #-3629, ptr
        seq.i   ptr+4480, ptr+4670
        mov.ab  #-3249, ptr
        seq.i   ptr+4860, ptr+5050
        mov.ab  #-2869, ptr
        seq.i   ptr+5240, ptr+5430
        mov.ab  #-2489, ptr
        seq.i   ptr+5620, ptr+5810
        mov.ab  #-2109, ptr
        seq.i   ptr+6000, ptr+6190
        mov.ab  #-1729, ptr
        seq.i   ptr+6380, ptr+6570
        mov.ab  #-1349, ptr
        seq.i   ptr+6760, ptr+6950
        mov.ab  #-969, ptr
        seq.i   ptr+7140, ptr+7330
        mov.ab  #-589, ptr
        seq.i   ptr+207, ptr+397
        mov.ab  #-7522, ptr
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
