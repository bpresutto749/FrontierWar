;redcode-94nop
;name Lattice Sweep
;author Barthelemy Presutto
;strategy boot away, 0.5c seq scanner with spl carpet, then spl/dat clear
;assert CORESIZE==8000
step    equ     1060
off     equ     11
        org     boot
gate    dat     0,      0
ptr     dat     0,      1060
cbomb   spl     #step,  >step
top     mov.i   cbomb,  >ptr
scan    seq.i   2*step, }2*step+off
        mov.ab  scan,   ptr
        add.f   inc,    scan
        jmn.a   top,    scan
inc     spl     #step,  #step
clr     mov.i   dbomb,  >gate
        djn.f   clr,    >gate
dbomb   dat     <2667,  dbomb-gate+2
        jmp.b   $1,   >1
        spl.ba   }7,   @1
        spl.i   {2,   }5
        spl.a   <5,   @1
        spl.ab   $6,   #6
        spl.ba   *1,   @8
        spl.i   >6,   }8
        spl.ab   >3,   $9
        spl.ba   }7,   *6
        spl.a   }6,   *4
        spl.ab   @5,   #9
        jmp.b   <2,   }4
        mov.i   $9,   <6
        spl.i   <5,   {2
        spl.i   @3,   <1
        spl.i   @2,   {9
        spl.b   $1,   $2
        dat.f   $9,   @6
        spl.i   >8,   {8
        spl.a   <5,   @8
boot
        mov.i   gate+0,  gate+7727+0
        mov.i   gate+1,  gate+7727+1
        mov.i   gate+2,  gate+7727+2
        mov.i   gate+3,  gate+7727+3
        mov.i   gate+4,  gate+7727+4
        mov.i   gate+5,  gate+7727+5
        mov.i   gate+6,  gate+7727+6
        mov.i   gate+7,  gate+7727+7
        mov.i   gate+8,  gate+7727+8
        mov.i   gate+9,  gate+7727+9
        mov.i   gate+10,  gate+7727+10
        mov.i   gate+11,  gate+7727+11
        jmp     top+7727
        jmp.b   <9,   *5
        spl.i   }2,   {7
        spl.i   <2,   $1
        spl.f   @1,   <8
        spl.ab   {6,   *5
        mov.i   *8,   $3
        mov.i   $8,   >4
        spl.x   @3,   {3
        spl.ba   }4,   >6
        dat.f   $5,   <9
        jmp.b   *9,   <6
        spl.b   #2,   #7
        spl.a   @1,   *5
        spl.i   <2,   <4
        mov.i   }9,   *2
        jmp.b   @8,   <4
        spl.a   >5,   @6
        spl.ba   #6,   $4
        spl.i   #2,   $9
        dat.f   }6,   }4
