;redcode-94
;name Sieve
;author Barthelemy Presutto
;strategy 0.66c paired scan, spl stun on hits, then forward dat clear
;assert CORESIZE==8000
ST equ 5330
DD equ 2003
        org loop
inc     dat.f  #ST, #ST
loop    add.f  inc, scn
scn     sne.i  0, DD
cnt     djn.b  loop, #596
        jmz.b  clr, cnt
        mov.i  sbm, @scn
        mov.i  sbm, *scn
        jmp    loop
sbm     spl.f #0, 0
gate    dat.f  0, 0
clr     mov.i  cbomb, >gate
        djn.f  clr, >gate
cbomb   dat.f <2667, cbomb-gate+2
