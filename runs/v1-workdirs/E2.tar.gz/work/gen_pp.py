import sys
def gen(S1=6089,S2=5846,S3=2636,S4=1234,SS=3044,PK=37,sbomb='dat.f >2667, >5334',rule='loss'):
    L=[';redcode-94',';name Lattice',';author Barthelemy Presutto',';strategy p-space switch between a silk-style paper and a multi-process stone',';assert CORESIZE==8000',
       'S1 equ %d'%S1,'S2 equ %d'%S2,'S3 equ %d'%S3,'S4 equ %d'%S4,'SS equ %d'%SS,'PK equ %d'%PK,'        org sel']
    L+=['sel     ldp.ab  #0, res','        ldp.ab  #PK, st']
    if rule=='loss':
        L+=['        jmn.b   go, res']
    else:
        L+=['        sne.ab  #1, res','        jmp     go']
    L+=['        add.ab  #1, st','go      mod.ab  #2, st','        stp.b   st, #PK','        jmz.b   pgo, st','        jmp     stn','res     dat 0,0','st      dat 0,0']
    L+=['pgo     spl  1, <300','        spl  1, <400','        spl  1, <500',
        'silk    spl  @0, >S1','        mov.i }silk, >silk','silk2   spl  @0, >S2','        mov.i }silk2, >silk2',
        'silk3   spl  @0, >S3','        mov.i }silk3, >silk3','        spl  @0, >S4','        mov.i }-1, >-1','        dat 0,0']
    L+=['stn     spl   #0, 0','loop    mov.i  sbomb, @sptr','        add.ab #SS, sptr','        jmp    loop','sbomb   '+sbomb,'sptr    dat 0, SS+stn-sptr']
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('=',1); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
