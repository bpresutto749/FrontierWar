import random, sys
from ev import score
from gen_p import gen
seed=int(sys.argv[1]); N=int(sys.argv[2])
kw={'b1':'spl  @0, >S4|mov.i }-1, >-1','bomb':'dat 0,0'}
random.seed(seed)
fn='/tmp/arena_E2/work/sw3_%d.red'%seed
res=[]
for i in range(N):
    S=[random.randint(100,7900) for _ in range(4)]
    open(fn,'w').write(gen(S1=S[0],S2=S[1],S3=S[2],S4=S[3],**kw))
    s=score(fn)
    res.append((s,S))
    res.sort(reverse=True)
    print(i,'%.3f'%s,S,'top:',['%.3f %s'%(a,b) for a,b in res[:5]],flush=True)
