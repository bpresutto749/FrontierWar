import sys
def gen(ST=5330,DD=2003,CNT=596,NH=2,sbm='spl.f #0, 0',cbomb='dat.f <2667, cbomb-gate+2',hm='>'):
    L=[';redcode-94',';name Sieve',';author Barthelemy Presutto',';strategy 0.66c paired scan, spl stun on hits, then forward dat clear',';assert CORESIZE==8000',
       'ST equ %d'%ST,'DD equ %d'%DD,'        org loop',
       'inc     dat.f  #ST, #ST','loop    add.f  inc, scn','scn     sne.i  0, DD','cnt     djn.b  loop, #%d'%CNT,
       '        jmz.b  clr, cnt']
    for i in range(NH):
        L.append('        mov.i  sbm, %sscn'%hm)
        L.append('        mov.i  sbm, %sscn'%{'>':'}','<':'{','@':'*'}[hm])
    L+=['        jmp    cnt','sbm     '+sbm,'gate    dat.f  0, 0','clr     mov.i  cbomb, >gate','        djn.f  clr, >gate','cbomb   '+cbomb]
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
