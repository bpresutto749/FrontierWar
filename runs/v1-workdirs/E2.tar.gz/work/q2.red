;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy quick scan, then silk-style paper
;assert CORESIZE==8000
S1 equ 6089
S2 equ 5846
S3 equ 2636
QD equ 3840
        org qs
pgo     spl  1, <300
        spl  1, <400
        spl  1, <500
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
silk3   spl  @0, >S3
        mov.i }silk3, >silk3
        mov.i bomb, >1234
bomb    dat.f >2667, >5334
qs      seq.i  qs+150, qs+3990
        mov.ab #qs+150-qptr, qptr
        seq.i  qs+278, qs+4118
        mov.ab #qs+278-qptr, qptr
        seq.i  qs+406, qs+4246
        mov.ab #qs+406-qptr, qptr
        seq.i  qs+534, qs+4374
        mov.ab #qs+534-qptr, qptr
        seq.i  qs+662, qs+4502
        mov.ab #qs+662-qptr, qptr
        seq.i  qs+790, qs+4630
        mov.ab #qs+790-qptr, qptr
        seq.i  qs+918, qs+4758
        mov.ab #qs+918-qptr, qptr
        seq.i  qs+1046, qs+4886
        mov.ab #qs+1046-qptr, qptr
        seq.i  qs+1174, qs+5014
        mov.ab #qs+1174-qptr, qptr
        seq.i  qs+1302, qs+5142
        mov.ab #qs+1302-qptr, qptr
        seq.i  qs+1430, qs+5270
        mov.ab #qs+1430-qptr, qptr
        seq.i  qs+1558, qs+5398
        mov.ab #qs+1558-qptr, qptr
        seq.i  qs+1686, qs+5526
        mov.ab #qs+1686-qptr, qptr
        seq.i  qs+1814, qs+5654
        mov.ab #qs+1814-qptr, qptr
        seq.i  qs+1942, qs+5782
        mov.ab #qs+1942-qptr, qptr
        seq.i  qs+2070, qs+5910
        mov.ab #qs+2070-qptr, qptr
        seq.i  qs+2198, qs+6038
        mov.ab #qs+2198-qptr, qptr
        seq.i  qs+2326, qs+6166
        mov.ab #qs+2326-qptr, qptr
        seq.i  qs+2454, qs+6294
        mov.ab #qs+2454-qptr, qptr
        seq.i  qs+2582, qs+6422
        mov.ab #qs+2582-qptr, qptr
        seq.i  qs+2710, qs+6550
        mov.ab #qs+2710-qptr, qptr
        seq.i  qs+2838, qs+6678
        mov.ab #qs+2838-qptr, qptr
        seq.i  qs+2966, qs+6806
        mov.ab #qs+2966-qptr, qptr
        seq.i  qs+3094, qs+6934
        mov.ab #qs+3094-qptr, qptr
        seq.i  qs+3222, qs+7062
        mov.ab #qs+3222-qptr, qptr
        seq.i  qs+3350, qs+7190
        mov.ab #qs+3350-qptr, qptr
        seq.i  qs+3478, qs+7318
        mov.ab #qs+3478-qptr, qptr
        seq.i  qs+3606, qs+7446
        mov.ab #qs+3606-qptr, qptr
        seq.i  qs+3734, qs+7574
        mov.ab #qs+3734-qptr, qptr
        seq.i  qs+3862, qs+7702
        mov.ab #qs+3862-qptr, qptr
        jmz.b  pgo, qptr
        seq.i  qnull, @qptr
        jmp    qb
        add.ab #QD, qptr
qb      sub.ab #8, qptr
ql      mov.i  qbomb, @qptr
        add.ab #3, qptr
        djn    ql, #9
        jmp    pgo
qbomb   dat.f #0, #0
qptr    dat.f  #0, #0
qnull   dat.f  $0, $0
