;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy p-space switch (after repeated losses) between a silk-style paper and a stun-carpet scanner
;assert CORESIZE==8000
S1 equ 6089
S2 equ 5846
S3 equ 2636
S4 equ 1234
PK equ 37
        org sel
sel     ldp.ab  #0, res
        ldp.ab  #PK, st
        ldp.ab  #PK+1, cn
        jmz.b   lost, res
        mov.ab  #0, cn
        jmp     go
lost    add.ab  #1, cn
        slt.ab  #0, cn
        jmp     go
        add.ab  #1, st
        mov.ab  #0, cn
go      mod.ab  #2, st
        stp.b   st, #PK
        stp.b   cn, #PK+1
        jmz.b   pgo, st
        jmp     top
res     dat 0,0
st      dat 0,0
cn      dat 0,0
pgo     spl  1, <300
        spl  1, <400
        spl  1, <500
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
silk3   spl  @0, >S3
        mov.i }silk3, >silk3
        spl  @0, >S4
        mov.i }-1, >-1
        dat 0,0
S equ 5830
D equ 11
LEN equ 29
NC equ (CORESIZE-LEN-2)/2
ptr     dat.f  0, 0
sb      spl.f  #0, LEN+1-ptr
db      dat.f <2667, <5334
tmp     dat.f  0, 0
top     mov.i  sb, >ptr
scan    seq.i  S, S+D
        jmp    hit
adv     add.f  inc, scan
        jmn.a  top, scan
clr     mov.ab #LEN+1, ptr
c1      mov.i  sb, >ptr
        mov.i  sb, >ptr
n1      djn.b  c1, #NC
again   mov.ab #LEN+1, ptr
        mov.ab #NC, n2
c2      mov.i  db, >ptr
        mov.i  db, >ptr
n2      djn.b  c2, #NC
        jmp    again
hit     mov.ab scan, tmp
        add.ab #10+D+K, tmp
        slt.ab #LEN+D+K+12, tmp
        jmp    adv
        mov.ab scan, ptr
        add.ab #scan-ptr-K, ptr
        jmp    adv
inc     dat.f  S, S
