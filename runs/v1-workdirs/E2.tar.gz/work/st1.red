;redcode-94
;name Stone test
;assert CORESIZE==8000
SS equ 3044
stn     spl   #0, 0
loop    mov.i  sbomb, @sptr
        add.ab #SS, sptr
        jmp    loop
sbomb   dat.f >2667, >5334
sptr    dat 0, SS+stn-sptr
