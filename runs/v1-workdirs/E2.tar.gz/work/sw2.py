import random, sys
from ev import score
from gen_p import gen
seed=int(sys.argv[1]); N=int(sys.argv[2]); kw=eval(sys.argv[3]) if len(sys.argv)>3 else {}
random.seed(seed)
best=(-1,None)
fn='/tmp/arena_E2/work/sw2_%d.red'%seed
for i in range(N):
    S=[random.randint(100,7900) for _ in range(4)]
    open(fn,'w').write(gen(S1=S[0],S2=S[1],S3=S[2],S4=S[3],**kw))
    s=score(fn)
    if s>best[0]:
        best=(s,S); print(i,best,flush=True)
