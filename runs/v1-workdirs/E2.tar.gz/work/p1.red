;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy silk-style paper
;assert CORESIZE==8000
S1 equ 3620
S2 equ 1840
S3 equ 2550
        spl  1, <300
        spl  1, <400
        spl  1, <500
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
        mov.i bomb, >S3
        mov.i bomb, }S3+7
        jmp  -2
bomb    dat  >2667, >5334
