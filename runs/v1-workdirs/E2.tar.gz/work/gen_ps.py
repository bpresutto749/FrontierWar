import sys
from gen_p import gen as gp
def gen(SS=3044,sbomb='dat.f >2667, >5334',S1=6089,S2=5846,S3=2636,S4=1234,mode='both',stn='spl   #0, 0'):
    L=[';redcode-94',';name Lattice',';author Barthelemy Presutto',';strategy silk-style paper plus a multi-process stone',';assert CORESIZE==8000',
       'S1 equ %d'%S1,'S2 equ %d'%S2,'S3 equ %d'%S3,'S4 equ %d'%S4,'SS equ %d'%SS,'        org start']
    L+=['start   spl  stn, <300','        spl  1, <400','        spl  1, <500','        spl  1, <600',
        'silk    spl  @0, >S1','        mov.i }silk, >silk','silk2   spl  @0, >S2','        mov.i }silk2, >silk2',
        'silk3   spl  @0, >S3','        mov.i }silk3, >silk3','        spl  @0, >S4','        mov.i }-1, >-1','        dat 0,0']
    L+=['stn     '+stn,'loop    mov.i  sbomb, @sptr','        add.ab #SS, sptr','        jmp    loop','sbomb   '+sbomb,'sptr    dat 0, SS+stn-sptr']
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('=',1); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
