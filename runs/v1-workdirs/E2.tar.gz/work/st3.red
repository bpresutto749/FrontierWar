;redcode-94
;name Stone test
;assert CORESIZE==8000
SS equ 3364
stn     spl   #0, 0
loop    mov.i  sbomb, @sptr
sptr    mov.i  sbomb, *SS+1
        add.f  inc, sptr
        djn.f  loop, <-200
sbomb   dat.f >1, >1
inc     dat    SS*2, SS*2
