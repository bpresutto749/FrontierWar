;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy paired-cell scan with stun carpet aimed at hits, then spl pass and dat pass
;assert CORESIZE==8000
S equ 5830
D equ 11
LEN equ 29
NC equ (CORESIZE-LEN-2)/2
        org top
ptr     dat.f  0, 0
sb      spl.f  #0, LEN+1-ptr
db      dat.f <2667, <5334
tmp     dat.f  0, 0
top     mov.i  sb, >ptr
scan    seq.i  S, S+D
        jmp    hit
adv     add.f  inc, scan
        jmn.a  top, scan
clr     mov.ab #LEN+1, ptr
c1      mov.i  sb, >ptr
        mov.i  sb, >ptr
n1      djn.b  c1, #NC
again   mov.ab #LEN+1, ptr
        mov.ab #NC, n2
c2      mov.i  db, >ptr
        mov.i  db, >ptr
n2      djn.b  c2, #NC
        jmp    again
hit     mov.ab scan, tmp
        add.ab #10+D+K, tmp
        slt.ab #LEN+D+K+12, tmp
        jmp    adv
        mov.ab scan, ptr
        add.ab #scan-ptr-K, ptr
        jmp    adv
inc     dat.f  S, S
