import sys
def gen(S1=6089,S2=5846,S3=2636,S4=1234,b1='mov.i bomb, >S4',bomb='dat.f >2667, >5334',pre='spl  1, <300|spl  1, <400|spl  1, <500',extra=''):
    L=[';redcode-94',';name Lattice',';author Barthelemy Presutto',';strategy silk-style paper',';assert CORESIZE==8000',
       'S1 equ %d'%S1,'S2 equ %d'%S2,'S3 equ %d'%S3,'S4 equ %d'%S4]
    L+=['        '+x for x in pre.split('|')]
    L+=['silk    spl  @0, >S1','        mov.i }silk, >silk','silk2   spl  @0, >S2','        mov.i }silk2, >silk2',
        'silk3   spl  @0, >S3','        mov.i }silk3, >silk3']
    L+=['        '+x for x in b1.split('|')]
    L+=['bomb    '+bomb]
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('=',1); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
