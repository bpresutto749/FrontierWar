import random, sys, math
from ev import score
from gen_b import gen
random.seed(int(sys.argv[1]))
best=(-1,None)
fn='/tmp/arena_E2/work/swb_%s.red'%sys.argv[1]
for i in range(int(sys.argv[2])):
    m=random.choice([10,10,8,4,2])
    while True:
        u=random.randint(1,8000//m-1)
        if math.gcd(u,8000//m)==1: break
    S=u*m; D=random.choice([m//2, m//2+1, 3,5,7, m-1, m+1]) if m>2 else random.choice([1,3,5,7,9])
    db=random.choice(['dat.f <2667, <5334','dat.f 0, 0'])
    open(fn,'w').write(gen(S=S,D=D,db=db))
    s=score(fn)
    if s>best[0]:
        best=(s,(S,D,db)); print(i,best,flush=True)
