;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy quick scan, then silk-style paper
;assert CORESIZE==8000
S1 equ 6089
S2 equ 5846
S3 equ 2636
S4 equ 1234
QD equ 3800
        org qs
pgo     spl  1, <300
        spl  1, <400
        spl  1, <500
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
silk3   spl  @0, >S3
        mov.i }silk3, >silk3
        spl  @0, >S4
        mov.i }-1, >-1
bomb    dat 0,0
qs      seq.i  qs+150, qs+3950
        mov.ab #qs+150-qptr, qptr
        seq.i  qs+340, qs+4140
        mov.ab #qs+340-qptr, qptr
        seq.i  qs+530, qs+4330
        mov.ab #qs+530-qptr, qptr
        seq.i  qs+720, qs+4520
        mov.ab #qs+720-qptr, qptr
        seq.i  qs+910, qs+4710
        mov.ab #qs+910-qptr, qptr
        seq.i  qs+1100, qs+4900
        mov.ab #qs+1100-qptr, qptr
        seq.i  qs+1290, qs+5090
        mov.ab #qs+1290-qptr, qptr
        seq.i  qs+1480, qs+5280
        mov.ab #qs+1480-qptr, qptr
        seq.i  qs+1670, qs+5470
        mov.ab #qs+1670-qptr, qptr
        seq.i  qs+1860, qs+5660
        mov.ab #qs+1860-qptr, qptr
        seq.i  qs+2050, qs+5850
        mov.ab #qs+2050-qptr, qptr
        seq.i  qs+2240, qs+6040
        mov.ab #qs+2240-qptr, qptr
        seq.i  qs+2430, qs+6230
        mov.ab #qs+2430-qptr, qptr
        seq.i  qs+2620, qs+6420
        mov.ab #qs+2620-qptr, qptr
        seq.i  qs+2810, qs+6610
        mov.ab #qs+2810-qptr, qptr
        seq.i  qs+3000, qs+6800
        mov.ab #qs+3000-qptr, qptr
        seq.i  qs+3190, qs+6990
        mov.ab #qs+3190-qptr, qptr
        seq.i  qs+3380, qs+7180
        mov.ab #qs+3380-qptr, qptr
        seq.i  qs+3570, qs+7370
        mov.ab #qs+3570-qptr, qptr
        seq.i  qs+3760, qs+7560
        mov.ab #qs+3760-qptr, qptr
        jmz.b  pgo, qptr
        seq.i  qnull, @qptr
        jmp    qb
        add.ab #QD, qptr
qb      sub.ab #8, qptr
ql      mov.i  qbomb, @qptr
        add.ab #3, qptr
        djn    ql, #9
        jmp    pgo
qbomb   dat.f #0, #0
qptr    dat.f  #0, #0
qnull   dat.f  $0, $0
