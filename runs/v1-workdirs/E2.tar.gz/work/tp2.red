;redcode-94
;name t
;assert CORESIZE==8000
S1 equ @S1@
S2 equ @S2@
S3 equ @S3@
        spl  1, <300
        spl  1, <400
        spl  1, <500
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
silk3   spl  @0, >S3
        mov.i }silk3, >silk3
        mov.i bomb, >1234
bomb    dat  >2667, >5334
