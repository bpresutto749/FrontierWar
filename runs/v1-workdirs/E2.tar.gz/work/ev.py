import subprocess, sys, os, re
from concurrent.futures import ThreadPoolExecutor
HERE='/tmp/arena_E2'
OPP=sorted(os.path.join(HERE,'sparring',f) for f in os.listdir(HERE+'/sparring'))
def battle(a,b,rounds=100):
    p=subprocess.run([HERE+'/bin/pmars','-b','-k','-r',str(rounds),'-f',a,b],capture_output=True,text=True,timeout=300)
    lines=[l for l in p.stdout.strip().splitlines() if l.split() and l.split()[0].lstrip('-').isdigit()]
    if len(lines)<2: return None
    w1,t1=map(int,lines[-2].split()[:2]); w2,_=map(int,lines[-1].split()[:2])
    return (3*w1+t1)/(3*rounds)
def score(path,rounds=100,detail=False):
    with ThreadPoolExecutor(4) as ex:
        r=list(ex.map(lambda o: battle(path,o,rounds),OPP))
    if detail: return r
    if any(x is None for x in r): return -1
    return sum(r)/len(r)
if __name__=='__main__':
    for f in sys.argv[1:]:
        r=score(f,detail=True)
        print(f, ' '.join('%.2f'%x if x is not None else 'ERR' for x in r), '%.3f'%(sum(x or 0 for x in r)/len(r)))
