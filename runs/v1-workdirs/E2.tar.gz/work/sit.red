;redcode-94
;name sit
l jmp 0
