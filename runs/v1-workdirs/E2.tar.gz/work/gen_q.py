import sys
def gen(S1=6089,S2=5846,S3=2636,NC=30,SP=128,BASE=150,BOFF=8,BST=3,NB=9,bomb='dat.f >2667, >5334',qbomb='dat.f #0, #0',paper='p2'):
    QD=SP*NC
    L=[';redcode-94',';name Lattice',';author Barthelemy Presutto',';strategy quick scan, then silk-style paper',';assert CORESIZE==8000',
       'S1 equ %d'%S1,'S2 equ %d'%S2,'S3 equ %d'%S3,'QD equ %d'%QD,'        org qs']
    L+=['pgo     spl  1, <300','        spl  1, <400','        spl  1, <500',
        'silk    spl  @0, >S1','        mov.i }silk, >silk','silk2   spl  @0, >S2','        mov.i }silk2, >silk2',
        'silk3   spl  @0, >S3','        mov.i }silk3, >silk3','        mov.i bomb, >1234','bomb    '+bomb]
    for k in range(NC):
        T=BASE+SP*k
        lab='qs' if k==0 else '  '
        L.append('%-7s seq.i  qs+%d, qs+%d'%(lab,T,T+QD))
        L.append('        mov.ab #qs+%d-qptr, qptr'%T)
    L+=['        jmz.b  pgo, qptr','        seq.i  qnull, @qptr','        jmp    qb','        add.ab #QD, qptr',
        'qb      sub.ab #%d, qptr'%BOFF,
        'ql      mov.i  qbomb, @qptr','        add.ab #%d, qptr'%BST,'        djn    ql, #%d'%NB,'        jmp    pgo',
        'qbomb   '+qbomb,'qptr    dat.f  #0, #0','qnull   dat.f  $0, $0']
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('='); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
