import random, sys
from ev import score
T=open(sys.argv[1]).read()
best=(-1,None)
random.seed(int(sys.argv[3]) if len(sys.argv)>3 else 1)
for i in range(int(sys.argv[2])):
    S1=random.randint(100,7900); S2=random.randint(100,7900); S3=random.randint(100,7900)
    src=T.replace('@S1@',str(S1)).replace('@S2@',str(S2)).replace('@S3@',str(S3))
    fn='/tmp/arena_E2/work/tmp_%s.red'%sys.argv[3] if len(sys.argv)>3 else '/tmp/arena_E2/work/tmp.red'
    open(fn,'w').write(src)
    s=score(fn)
    if s>best[0]:
        best=(s,(S1,S2,S3)); print(i,best,flush=True)
