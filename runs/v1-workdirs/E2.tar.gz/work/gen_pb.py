import sys
from gen_b import gen as gb
def gen(S1=6089,S2=5846,S3=2636,S4=1234,PK=37,TH=1,S=5830,D=11):
    b=gb(S=S,D=D).split('\n')
    body=[l for l in b if l and not l.startswith(';') and 'org top' not in l]
    L=[';redcode-94',';name Lattice',';author Barthelemy Presutto',';strategy p-space switch (after repeated losses) between a silk-style paper and a stun-carpet scanner',';assert CORESIZE==8000',
       'S1 equ %d'%S1,'S2 equ %d'%S2,'S3 equ %d'%S3,'S4 equ %d'%S4,'PK equ %d'%PK,'        org sel']
    L+=['sel     ldp.ab  #0, res','        ldp.ab  #PK, st','        ldp.ab  #PK+1, cn','        jmz.b   lost, res',
        '        mov.ab  #0, cn','        jmp     go','lost    add.ab  #1, cn','        slt.ab  #%d, cn'%TH,'        jmp     go',
        '        add.ab  #1, st','        mov.ab  #0, cn','go      mod.ab  #2, st','        stp.b   st, #PK','        stp.b   cn, #PK+1',
        '        jmz.b   pgo, st','        jmp     top','res     dat 0,0','st      dat 0,0','cn      dat 0,0']
    L+=['pgo     spl  1, <300','        spl  1, <400','        spl  1, <500',
        'silk    spl  @0, >S1','        mov.i }silk, >silk','silk2   spl  @0, >S2','        mov.i }silk2, >silk2',
        'silk3   spl  @0, >S3','        mov.i }silk3, >silk3','        spl  @0, >S4','        mov.i }-1, >-1','        dat 0,0']
    L+=body
    return '\n'.join(L)+'\n'
if __name__=='__main__':
    kw={}
    for a in sys.argv[2:]:
        k,v=a.split('=',1); kw[k]=int(v) if v.lstrip('-').isdigit() else v
    open(sys.argv[1],'w').write(gen(**kw))
