;redcode-94
;name t
;assert CORESIZE==8000
        spl 1, <300
        spl 1, <400
        spl 1, <500
        spl 1, <600
        spl  @0, >5431
        mov.i }-1, >-1
        spl  @0, >1838
        mov.i }-1, >-1
        spl  @0, >2172
        mov.i }-1, >-1
        spl  @0, >1610
        mov.i }-1, >-1
        spl  @0, >7427
        mov.i }-1, >-1
        spl  @0, >444
        mov.i }-1, >-1
        spl  @0, >3131
        mov.i }-1, >-1
        spl  @0, >2404
        mov.i }-1, >-1
        dat 0,0
