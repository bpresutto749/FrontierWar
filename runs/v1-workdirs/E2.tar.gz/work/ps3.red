;redcode-94
;name Lattice
;author Barthelemy Presutto
;strategy silk-style paper plus a multi-process stone
;assert CORESIZE==8000
S1 equ 6089
S2 equ 5846
S3 equ 2636
S4 equ 1234
SS equ 3044
        org start
start   spl  stn, <300
        spl  1, <400
        spl  1, <500
        spl  1, <600
silk    spl  @0, >S1
        mov.i }silk, >silk
silk2   spl  @0, >S2
        mov.i }silk2, >silk2
silk3   spl  @0, >S3
        mov.i }silk3, >silk3
        spl  @0, >S4
        mov.i }-1, >-1
        dat 0,0
stn     spl   #0, 0
loop    mov.i  sbomb, @sptr
        add.ab #SS, sptr
        jmp    loop
sbomb   dat.f <2667, <5334
sptr    dat 0, SS+stn-sptr
