# Write a Core War warrior

Write a Redcode warrior and save it as `submission.red` in this directory.

## How it is scored

Your warrior plays a hidden hill of 30 human-written competitive warriors
(taken from the public history of the ICWS '94 King-of-the-Hill, ranging from
mid-strength to among the strongest ever submitted). Against each hill warrior
it plays 100 rounds with pMARS 0.9.4 in standard '94 settings: coresize 8000,
80000 cycles, 8000 processes, max warrior length 100, min distance 100,
ICWS '94 instruction set with the pMARS extensions (p-space is allowed).

Per round: win = 3 points, tie = 1, loss = 0. The reward is your mean points
per round over the whole hill divided by 3, so 1.0 means you won every round.
A file that does not assemble scores 0. pMARS hangs on very long source lines, so
comment lines are cut to 200 characters and a code line longer than 200
characters makes the file invalid.

## What you have

- `bin/pmars` — the exact simulator used for scoring (`bin/pmars -h`).
- `doc/` — the Redcode language reference (opcodes, modifiers, addressing modes,
  p-space), the ICWS '94 draft standard and the pMARS manual. It contains no
  strategy guides.
- `sparring/` — 10 public warriors of the same kind as the hidden hill. None of
  them is on the hidden hill.
- `tools/battle.py` — `python3 tools/battle.py submission.red` battles your
  warrior against the sparring pool with the scoring rules above.

Original work only: a near-copy of a published warrior (the sparring pool or
any of about 580 public warriors in our corpus) scores 0. Using published ideas
and techniques is fine; submitting someone else's warrior is not.

You have a wall-clock budget of 45 minutes. No internet access. Your score is
whatever `submission.red` contains at the end, so keep a valid one saved.
