;redcode-94
;name Pebble Imp
;author anon
;strategy stone + 3-point imp spiral
;assert CORESIZE==8000

step    equ     {st}
isz     equ     2667

start   spl     stone,  <-{g1}
        spl     4
        spl     2
        jmp     imp+(0*isz)
        jmp     imp+(1*isz)
        spl     2
        jmp     imp+(2*isz)
        jmp     imp+(3*isz)
imp     mov.i   #0,     isz
        dat     0,      0
stone   nop     0,     <-20
loop    mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   loop,   <-{g2}
sptr    dat     #step+{o},  #2*step+{o}
sinc    dat     #2*step, #2*step
bomb    dat     <2667,  <5334
end start
