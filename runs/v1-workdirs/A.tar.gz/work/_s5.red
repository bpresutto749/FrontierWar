;redcode-94
;name Pebble Imp
;author anon
;strategy stone + 3-point imp spiral
;assert CORESIZE==8000

step    equ     2891
isz     equ     2667

start   spl     stone,  <-300
        spl     4
        spl     2
        jmp     imp+(0*isz)
        jmp     imp+(1*isz)
        spl     2
        jmp     imp+(2*isz)
        jmp     imp+(3*isz)
stone   spl     #0,     <-20
loop    mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   loop,   <-30
sptr    dat     #step+1807,  #2*step+1807
sinc    dat     #2*step, #2*step
bomb    dat     <2667,  <5334
imp     mov.i   #0,     isz
end start
