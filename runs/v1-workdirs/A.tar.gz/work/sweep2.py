import random, sys, json
sys.path.insert(0,'/tmp/arena_A/work')
from sweep import score
tmpl=open(sys.argv[1]).read(); n=int(sys.argv[2]); seed=int(sys.argv[3]); spec=json.loads(sys.argv[4])
rounds=int(sys.argv[5]) if len(sys.argv)>5 else 60
random.seed(seed); best=(-1,None); seen=set()
for i in range(n):
    vals={}
    for k,v in spec.items():
        if isinstance(v,list) and v and v[0]=='m10':
            while True:
                m=random.randint(1,799)
                if m%2 and m%5: break
            vals[k]=10*m
        elif isinstance(v,list) and v and v[0]=='choice': vals[k]=random.choice(v[1:])
        else: vals[k]=random.randint(v[0],v[1])
    key=tuple(sorted(vals.items()))
    if key in seen: continue
    seen.add(key)
    src=tmpl
    for k,v in vals.items(): src=src.replace('{'+k+'}',str(v))
    fn=f'/tmp/arena_A/work/_t{seed}.red'; open(fn,'w').write(src)
    s,r=score(fn,rounds)
    if s>best[0]:
        best=(s,vals); print(i, round(s,3), vals, [round(x,2) for x in r], flush=True)
