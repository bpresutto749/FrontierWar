;redcode-94
;name Sieve
;author anon
;strategy 0.66c seq scanner, spl bombs on hit, then d-clear
;assert CORESIZE==8000

step    equ     70
gap     equ     5

scan    seq.i   step,   step+gap
        jmp     hit
next    add.f   incr,   scan
        jmn.a   scan,   scan
        jmp     clr
hit     slt.ab  #21,    scan
        jmp     next
        mov.i   sbomb,  *scan
        mov.i   sbomb,  @scan
        jmp     next
incr    dat     step,   step
sbomb   spl     #0,     0
gate    dat     0,      cbomb-gate+1
clr     spl     #0,     0
cl      mov.i   cbomb,  >gate
        jmp     cl
cbomb   dat     <2667,  cbomb-gate+1
end scan
