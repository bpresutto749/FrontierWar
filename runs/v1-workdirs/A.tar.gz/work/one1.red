;redcode-94
;name Single Shot
;author anon
;strategy seq scanner, on first hit spl carpet then dat clear from target
;assert CORESIZE==8000

step    equ     70
gap     equ     5

scan    seq.i   step,   step+gap
        jmp     hit
next    add.f   incr,   scan
        jmn.a   scan,   scan
        jmp     clr
hit     slt.ab  #100,   scan
        jmp     next
        mov.b   scan,   gate
        add.ab  #scan-gate-8, gate
        mov.b   gate,   save
sloop   mov.i   sbomb,  >gate
        djn.b   sloop,  #30
        mov.b   save,   gate
        jmp     clr
gate    dat     0,      last-gate+1
clr     spl     #0,     0
cl      mov.i   cbomb,  >gate
        jmp     cl
cbomb   dat     <2667,  last-gate+1
save    dat     0,      0
sbomb   spl     #0,     0
last
incr    dat     step,   step
end scan
