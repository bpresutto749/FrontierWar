;redcode-94
;name Carpet Weaver PS
;author anon
;strategy p-space loss-count bandit between a 0.5c spl-carpet scanner and a silk paper
;assert CORESIZE==8000

step    equ     7770
gap     equ     5
d1      equ     2528
d2      equ     1090
d3      equ     6187
PS      equ     21
PL0     equ     PS+1
PL1     equ     PS+2

incr    dat     step,   step
ptr     dat     0,      -1000
sb      spl     #0,     0
top     mov.i   sb,     >ptr
scan    seq.i   step,   step+gap
        mov.ab  scan,   ptr
        add.f   incr,   scan
        jmn.a   top,    scan
clr     spl     #0,     0
cl      mov.i   cb,     <gate
        jmp     cl
        dat     0,      0
gate    dat     0,      incr-gate
cb      dat     <2667,  incr-gate
for 26
        dat     0,      0
rof
paper   spl     1,      <-300
        spl     1,      <-500
        spl     1,      <-700
silk1   spl     @0,     }d1
        mov.i   }-1,    >-1
silk2   spl     @0,     }d2
        mov.i   }-1,    >-1
        mov.i   pbomb,  }d3
        mov.i   pbomb,  >-1000
        jmp     silk2,  <-2000
pbomb   dat     <2667,  <5334
start   ldp.ab  #0,     res
        ldp.ab  #PS,    sel
        ldp.ab  #PL0,   l0
        ldp.ab  #PL1,   l1
        jmn.b   nolos,  res
        jmz.b   inc0,   sel
        add.ab  #1,     l1
        stp.b   l1,     #PL1
        jmp     nolos
inc0    add.ab  #1,     l0
        stp.b   l0,     #PL0
nolos   slt.b   l1,     l0
        jmp     go0
        stp.ab  #1,     #PS
        jmp     paper
go0     stp.ab  #0,     #PS
        jmp     top
res     dat     0,      0
sel     dat     0,      0
l0      dat     0,      0
l1      dat     0,      0
end start
