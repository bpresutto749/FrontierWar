import random, subprocess, sys, re, os
from concurrent.futures import ThreadPoolExecutor
HERE='/tmp/arena_A'
OPP=sorted(os.path.join(HERE,'sparring',f) for f in os.listdir(HERE+'/sparring'))
def score(path, rounds=60):
    def one(o):
        p=subprocess.run([HERE+'/bin/pmars','-b','-k','-r',str(rounds),'-f',path,o],capture_output=True,text=True,timeout=300)
        ls=[l for l in p.stdout.strip().splitlines() if l.split() and l.split()[0].lstrip('-').isdigit()]
        if len(ls)<2: return None
        w1,t1=map(int,ls[-2].split()[:2]); return (3*w1+t1)/(3*rounds)
    with ThreadPoolExecutor(2) as ex: r=list(ex.map(one,OPP))
    if None in r: return -1, r
    return sum(r)/len(r), r
if __name__=='__main__':
    tmpl=open(sys.argv[1]).read(); n=int(sys.argv[2]); seed=int(sys.argv[3]) if len(sys.argv)>3 else 0
    random.seed(seed)
    params=re.findall(r'\{(\w+)\}',tmpl); params=sorted(set(params))
    best=(-1,None)
    for i in range(n):
        vals={p:random.randint(100,7900) for p in params}
        src=tmpl
        for p,v in vals.items(): src=src.replace('{'+p+'}',str(v))
        fn=f'/tmp/arena_A/work/_s{seed}.red'; open(fn,'w').write(src)
        s,r=score(fn)
        if s>best[0]:
            best=(s,vals); print(i, round(s,3), vals, [round(x,2) for x in r], flush=True)
