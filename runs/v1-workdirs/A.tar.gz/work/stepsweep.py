import random, sys
sys.path.insert(0,'/tmp/arena_A/work')
from ev import ev
tmpl=open(sys.argv[1]).read(); n=int(sys.argv[2]); random.seed(int(sys.argv[3]))
res=[]
for i in range(n):
    while True:
        m=random.randint(1,799)
        if m%2 and m%5: break
    src=tmpl.replace('{st}',str(10*m)).replace('{ip}','-1000')
    fn='/tmp/arena_A/work/_ss.red'; open(fn,'w').write(src)
    s,per=ev(fn,2); res.append((s,10*m)); print(10*m, round(s,3), flush=True)
res.sort(reverse=True); print(res[:8])
