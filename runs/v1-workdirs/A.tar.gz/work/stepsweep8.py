import random, sys
sys.path.insert(0,'/tmp/arena_A/work')
from ev import ev
tmpl=open(sys.argv[1]).read(); n=int(sys.argv[2]); random.seed(int(sys.argv[3])); mult=int(sys.argv[4]); mod=int(sys.argv[5])
res=[]
for i in range(n):
    while True:
        m=random.randint(1,mod-1)
        if m%2 and m%5: break
    src=tmpl.replace('{st}',str(mult*m))
    fn='/tmp/arena_A/work/_s8.red'; open(fn,'w').write(src)
    s,per=ev(fn,2); res.append((s,mult*m)); print(mult*m, round(s,3), flush=True)
res.sort(reverse=True); print(res[:8])
