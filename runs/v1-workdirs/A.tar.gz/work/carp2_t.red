;redcode-94
;name Carpet Weaver
;author anon
;strategy 0.5c seq scanner laying a spl carpet from each hit, then backward dat clear
;assert CORESIZE==8000

step    equ     {st}
gap     equ     5

incr    dat     step,   step
ptr     dat     0,      {ip}
sb      spl     #0,     {sbb}
top     mov.i   sb,     >ptr
scan    seq.i   step,   step+gap
        mov.ab  scan,   ptr
        add.f   incr,   scan
        jmn.a   top,    scan
clr     spl     #0,     {clb}
cl      mov.i   cb,     <gate
        jmp     cl,     {jb}
        dat     0,      0
gate    dat     0,      incr-gate
cb      dat     {cba},  incr-gate
end top
