;redcode-94
;name Carpet Weaver
;author anon
;strategy 0.5c seq scanner laying a spl carpet from each hit, then backward dat clear
;assert CORESIZE==8000

step    equ     5870
gap     equ     5

incr    dat     step,   step
ptr     dat     0,      -3000
sb      spl     #0,     0
top     mov.i   sb,     >ptr
scan    seq.i   step,   step+gap
        mov.ab  scan,   ptr
        add.f   incr,   scan
        jmn.a   top,    scan
clr     spl     #0,     0
cl      mov.i   cb,     <gate
        jmp     cl
        dat     0,      0
gate    dat     0,      incr-gate
cb      dat     <2667,  incr-gate
for 10
        dat     0,      0
rof
stone   spl     #0,     <-20
sloop   mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   sloop,  <-30
sptr    dat     #3044+7,  #2*3044+7
sinc    dat     #2*3044, #2*3044
bomb    dat     <2667,  <5334
start   ldp.ab  #0,     res
        ldp.ab  #21,    sel
        ldp.ab  #22,    l0
        ldp.ab  #23,    l1
        jmn.b   nolos,  res
        jmz.b   inc0,   sel
        add.ab  #3,     l1
        stp.b   l1,     #23
        jmp     nolos
inc0    add.ab  #1,     l0
        stp.b   l0,     #22
nolos   slt.b   l1,     l0
        jmp     go0
        stp.ab  #1,     #21
        jmp     stone
go0     stp.ab  #0,     #21
        jmp     top
res     dat     0,      0
sel     dat     0,      0
l0      dat     0,      0
l1      dat     0,      0
end start
