;redcode-94
;name Pebble
;author anon
;strategy spl-stone, 2 bombs per loop, then imp ring
;assert CORESIZE==8000

step    equ     3044

stone   spl     #0,     <-20
loop    mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   loop,   <-30
sptr    dat     #step+7, #2*step+7
sinc    dat     #2*step, #2*step
bomb    dat     <2667,  <5334
end stone
