;redcode-94
;name Two Minds
;author anon
;strategy p-space switch on loss: silk paper / stone + imp spiral
;assert CORESIZE==8000

PS      equ     11
PL0     equ     12
PL1     equ     13
d1      equ     {d1}
d2      equ     {d2}
d3      equ     {d3}
step    equ     {st}
isz     equ     2667

start   ldp.ab  #0,     res
        ldp.ab  #PS,    sel
        ldp.ab  #PL0,   l0
        ldp.ab  #PL1,   l1
        jmn.b   nolos,  res
        jmz.b   inc0,   sel
        add.ab  #1,     l1
        stp.b   l1,     #PL1
        jmp     nolos
inc0    add.ab  #1,     l0
        stp.b   l0,     #PL0
nolos   slt.b   l1,     l0
        jmp     go0
        stp.ab  #1,     #PS
        jmp     stimp
go0     stp.ab  #0,     #PS
        jmp     paper
res     dat     0,      0
sel     dat     0,      0
l0      dat     0,      0
l1      dat     0,      0

paper   spl     1,      <-300
        spl     1,      <-500
        spl     1,      <-700
silk1   spl     @0,     }d1
        mov.i   }-1,    >-1
silk2   spl     @0,     }d2
        mov.i   }-1,    >-1
        mov.i   pbomb,  }d3
        mov.i   pbomb,  >-1000
        jmp     silk2,  <-2000
pbomb   dat     <2667,  <5334

stimp   spl     stone,  <-300
        spl     4
        spl     2
        jmp     imp+(0*isz)
        jmp     imp+(1*isz)
        spl     2
        jmp     imp+(2*isz)
        jmp     imp+(3*isz)
stone   spl     #0,     <-20
loop    mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   loop,   <-30
sptr    dat     #step+7,  #2*step+7
sinc    dat     #2*step, #2*step
bomb    dat     <2667,  <5334
imp     mov.i   #0,     isz
end start
