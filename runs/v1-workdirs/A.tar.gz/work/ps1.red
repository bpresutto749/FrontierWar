;redcode-94
;name Two Minds
;author anon
;strategy p-space switch on loss: silk paper / stone + imp spiral
;assert CORESIZE==8000

PC      equ     123
d1      equ     2528
d2      equ     1090
d3      equ     6187
step    equ     3044
isz     equ     2667

start   ldp.ab  #0,     res
        ldp.ab  #PC,    sel
        jmn.b   keep,   res
        add.ab  #1,     sel
keep    mod.ab  #2,     sel
        stp.b   sel,    #PC
        jmz.b   paper,  sel
        jmp     stimp
res     dat     0,      0
sel     dat     0,      0

paper   spl     1,      <-300
        spl     1,      <-500
        spl     1,      <-700
silk1   spl     @0,     }d1
        mov.i   }-1,    >-1
silk2   spl     @0,     }d2
        mov.i   }-1,    >-1
        mov.i   pbomb,  }d3
        mov.i   pbomb,  >-1000
        jmp     silk2,  <-2000
pbomb   dat     <2667,  <5334

stimp   spl     stone,  <-300
        spl     4
        spl     2
        jmp     imp+(0*isz)
        jmp     imp+(1*isz)
        spl     2
        jmp     imp+(2*isz)
        jmp     imp+(3*isz)
stone   spl     #0,     <-20
loop    mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        add.f   sinc,   sptr
        djn.f   loop,   <-30
sptr    dat     #step+7,  #2*step+7
sinc    dat     #2*step, #2*step
bomb    dat     <2667,  <5334
imp     mov.i   #0,     isz
end start
