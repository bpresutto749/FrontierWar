;redcode-94
;name Folded Paper
;author anon
;strategy silk paper
;assert CORESIZE==8000

d1      equ     {d1}
d2      equ     {d2}
d3      equ     {d3}

        spl     1,      <-300
        spl     1,      <-500
        spl     1,      <-700
silk1   spl     @0,     }d1
        mov.i   }-1,    >-1
silk2   spl     @0,     }d2
        mov.i   }-1,    >-1
        mov.i   bomb,   }d3
        mov.i   bomb,   >-1000
        jmp     silk2,  <-2000
bomb    dat     <2667,  <5334
end silk1-3
