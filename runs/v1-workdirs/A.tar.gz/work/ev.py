import subprocess, sys, os, random
from concurrent.futures import ThreadPoolExecutor
HERE='/tmp/arena_A'
OPP=sorted(os.path.join(HERE,'sparring',f) for f in os.listdir(HERE+'/sparring'))
def one(args):
    w,o,seed=args
    p=subprocess.run([HERE+'/bin/pmars','-b','-k','-r','60','-F',str(seed),w,o],capture_output=True,text=True,timeout=300)
    ls=[l for l in p.stdout.strip().splitlines() if l.split() and l.split()[0].lstrip('-').isdigit()]
    w1,t1=map(int,ls[-2].split()[:2]); return (3*w1+t1)/180
def ev(w,reps=5):
    jobs=[(w,o,100+137*r+11*i) for i,o in enumerate(OPP) for r in range(reps)]
    with ThreadPoolExecutor(2) as ex: res=list(ex.map(one,jobs))
    per=[sum(res[i*reps:(i+1)*reps])/reps for i in range(len(OPP))]
    return sum(per)/len(per), per
if __name__=='__main__':
    reps=int(sys.argv[1])
    for w in sys.argv[2:]:
        s,per=ev(w,reps); print(f"{os.path.basename(w):20s} {s:.3f} ", ' '.join(f"{x:.2f}" for x in per), flush=True)
