;redcode-94
;name m2a
;author anon
;assert CORESIZE==8000
step    equ 3044
        org boot
boot
        mov.i   stone+0, stone+2900+0
        mov.i   stone+1, stone+2900+1
        mov.i   stone+2, stone+2900+2
        mov.i   stone+3, stone+2900+3
        mov.i   stone+4, stone+2900+4
        mov.i   stone+0, stone+5900+0
        mov.i   stone+1, stone+5900+1
        mov.i   stone+2, stone+5900+2
        mov.i   stone+3, stone+5900+3
        mov.i   stone+4, stone+5900+4
        spl     stone+2900
        jmp     stone+5900
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
