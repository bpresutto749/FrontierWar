;redcode-94
;name ptest
;assert 1
        org go
go      ldp.ab  #5, x
x       jmn.b   die, #0
        stp.ab  #1, #5
l       jmp     l
die     dat     0, 0
