;redcode-94
;name duck
;assert 1
loop jmp loop
