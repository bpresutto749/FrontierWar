;redcode-94
;name Toggle3
;author anon
;strategy p-space explore-then-commit between a booted stone and a silk paper
;assert CORESIZE==8000
step    equ 3044
BD      equ 5900
EXPL    equ 16
        org think
think   ldp.ab  #0, res
        ldp.ab  #1, n
        ldp.ab  #2, t0
        ldp.ab  #3, t1
        ldp.ab  #4, last
        jmz.b   noscore, n
res     sne.ab  #1, #0
        mov.ab  #3, pts
        sne.ab  #2, res
        mov.ab  #1, pts
last    jmz.b   add0, #0
        add.b   pts, t1
        jmp     noscore
add0    add.b   pts, t0
noscore add.ab  #1, n
        stp.b   t0, #2
        stp.b   t1, #3
        stp.b   n, #1
        slt.ab  #EXPL, n
        jmp     explore
        slt.b   t0, t1
        jmp     gost
        jmp     gopa
explore mov.b   n, tmp
        mod.ab  #2, tmp
        jmn.b   gost, tmp
gopa    stp.ab  #1, #4
        jmp     paper
gost    stp.ab  #0, #4
        mov.i   stone, stone+BD
        mov.i   stone+1, stone+BD+1
        mov.i   stone+2, stone+BD+2
        mov.i   stone+3, stone+BD+3
        mov.i   stone+4, stone+BD+4
        jmp     stone+BD
n       dat     0, 0
t0      dat     0, 0
t1      dat     0, 0
pts     dat     0, 0
tmp     dat     0, 0
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
paper   spl  1
        spl  1
        spl  1
        spl  1
s1      spl  @0, }3620
        mov.i }-1, >-1
s2      spl  @0, }2512
        mov.i }-1, >-1
        mov.i pbmb, >1234
        mov.i pbmb, >3333
        jmp  s1
pbmb    dat  <2667, <5334
