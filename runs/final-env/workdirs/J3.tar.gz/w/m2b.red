;redcode-94
;name m2b
;author anon
;assert CORESIZE==8000
step    equ 3044
        org boot
boot
        mov.i   stone+0, stone+1900+0
        mov.i   stone+1, stone+1900+1
        mov.i   stone+2, stone+1900+2
        mov.i   stone+3, stone+1900+3
        mov.i   stone+4, stone+1900+4
        mov.i   stone+0, stone+4800+0
        mov.i   stone+1, stone+4800+1
        mov.i   stone+2, stone+4800+2
        mov.i   stone+3, stone+4800+3
        mov.i   stone+4, stone+4800+4
        spl     stone+1900
        jmp     stone+4800
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
