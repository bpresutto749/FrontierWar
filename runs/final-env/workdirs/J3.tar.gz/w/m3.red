;redcode-94
;name m3
;author anon
;assert CORESIZE==8000
step    equ 3044
        org boot
boot
        mov.i   stone+0, stone+2000+0
        mov.i   stone+1, stone+2000+1
        mov.i   stone+2, stone+2000+2
        mov.i   stone+3, stone+2000+3
        mov.i   stone+4, stone+2000+4
        mov.i   stone+0, stone+4200+0
        mov.i   stone+1, stone+4200+1
        mov.i   stone+2, stone+4200+2
        mov.i   stone+3, stone+4200+3
        mov.i   stone+4, stone+4200+4
        mov.i   stone+0, stone+6300+0
        mov.i   stone+1, stone+6300+1
        mov.i   stone+2, stone+6300+2
        mov.i   stone+3, stone+6300+3
        mov.i   stone+4, stone+6300+4
        spl     stone+2000
        spl     stone+4200
        jmp     stone+6300
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
