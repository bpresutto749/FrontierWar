;redcode-94
;name Toggle
;author anon
;strategy p-space switch: stone vs paper, switch on loss
;assert CORESIZE==8000
PST     equ 77
step    equ 3044
        org think
think   ldp.ab  #0, res
        ldp.ab  #PST, sel
res     jmn.b   keep, #0
        add.ab  #1, sel
        mod.ab  #2, sel
keep    stp.b   sel, #PST
sel     jmz.b   stone, #0
        jmp     paper
        for 6
        dat 0,0
        rof
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
        for 6
        dat 0,0
        rof
paper   spl  1
        spl  1
        spl  1
s1      spl  @0, }3620
        mov.i }-1, >-1
s2      spl  @0, }2512
        mov.i }-1, >-1
        mov.i pbmb, >1234
        jmp  s1
pbmb    dat  <2667, <5334
