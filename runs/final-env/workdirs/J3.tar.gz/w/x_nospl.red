;redcode-94
;name xa
;author anon
;assert CORESIZE==8000
step    equ 3044
BD      equ 5900
        org boot
boot
        mov.i   stone+0, stone+BD+0
        mov.i   stone+1, stone+BD+1
        mov.i   stone+2, stone+BD+2
        mov.i   stone+3, stone+BD+3
        jmp     stone+BD
stone   mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  stone, <-40
bmb     dat  >-1, >1
