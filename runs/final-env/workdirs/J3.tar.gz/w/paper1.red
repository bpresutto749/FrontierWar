;redcode-94
;name Papyr
;author anon
;strategy silk paper
;assert CORESIZE==8000
        org start
start   spl  1
        spl  1
        spl  1
s1      spl  @0, }3620
        mov.i }-1, >-1
s2      spl  @0, }2512
        mov.i }-1, >-1
        mov.i bmb, >1234

        jmp  s1
bmb     dat  <2667, <5334
