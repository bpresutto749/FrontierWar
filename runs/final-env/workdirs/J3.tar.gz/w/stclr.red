;redcode-94
;name Flint4
;author anon
;assert CORESIZE==8000
step    equ 3044
        org loop
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        djn.b  loop, #1990
clr     spl  #0, 0
        mov.i  cb, >cptr
        djn.f  -1, >cptr
cptr    dat    0, 2
cb      dat    0, 0
bmb     dat  >-1, >1
