;redcode-94
;name Oneshot-like
;author anon
;strategy scan until a find, then spl sweep from the find around the core, then dat sweeps
;assert CORESIZE==8000
step    equ 3044
nown    equ 6
        org scan
scan    add.ab  #step, ptr
ptr     jmz.f   scan, 400
        mov.ba  ptr, tt
        add.a   #8, tt
tt      slt.ab  #0, #(last-ptr+10)
        jmp     atk
        djn.b   scan, #nown
        jmp     pass2
atk     mov.ab  #(cl-ptr), ccnt
        sub.b   ptr, ccnt
        mov.b   ptr, cptr
        add.ab  #(ptr-cptr), cptr
        sub.ab  #2, cptr
cl      mov.i   sb, >cptr
ccnt    djn.b   cl, #0
pass2   mov.ab  #(8000-(last-cl+1)), dcnt
        mov.ab  #(last-cptr+1), cptr
dl      mov.i   db, >cptr
dcnt    djn.b   dl, #0
        jmp     pass2
sb      spl     #0, 0
db      dat     0, 0
cptr    dat     0, 0
last    dat     0, 0
