;redcode-94
;name Flint7
;author anon
;assert CORESIZE==8000
step    equ 3044
BD      equ 5900
        org boot
boot    mov.i   stone, stone+BD
        mov.i   stone+1, stone+BD+1
        mov.i   stone+2, stone+BD+2
        mov.i   stone+3, stone+BD+3
        mov.i   stone+4, stone+BD+4
        spl     stone+BD
        jmp     paper
stone   spl  #0, <-30
loop    mov.i bmb, @ptr
ptr     add.ab #step, #step
        jmp  loop, <-40
bmb     dat  >-1, >1
paper   spl  1
        spl  1
        spl  1
s1      spl  @0, }3620
        mov.i }-1, >-1
s2      spl  @0, }2512
        mov.i }-1, >-1
        mov.i pbmb, >1234
        mov.i pbmb, >3333
        jmp  s1
pbmb    dat  <2667, <5334
