;redcode-94
;name ptest2
;assert 1
        org go
go      ldp.ab  #0, x
x       jmz.b   die, #0
l       jmp     l
die     dat     0, 0
