;redcode-94
;name impt
;assert 1
istep   equ 2667
        org pump
pump    spl  #0, 0
        add.a #istep, jp
jp      jmp  imp-istep, 0
imp     mov.i #0, istep
