;redcode-94
;name imp0
;assert 1
 mov.i #0,1
