;redcode-94
;name Lurker
;author anon
;strategy jmz scanner, spl carpet on finds, then dat clear
;assert CORESIZE==8000
step    equ 3044
nfind   equ 14
nown    equ 5
        org scan
scan    add.ab  #step, ptr
ptr     jmz.f   scan, 400
        mov.ba  ptr, tt
        add.a   #8, tt
tt      slt.ab  #0, #(last-ptr+10)
        jmp     atk
        djn.b   scan, #nown
        jmp     clear
atk     mov.i   sb, >ptr
cnt     djn.b   atk, #8
        mov.ab  #8, cnt
        sub.ab  #8, ptr
        djn.b   scan, #nfind
clear   mov.ab  #(8000-(last-scan+1)), ccnt
        mov.ab  #1, last
cl      mov.i   db, >last
ccnt    djn.b   cl, #0
        jmp     clear
sb      spl     #0, 0
db      dat     0, 0
last    dat     0, 1
