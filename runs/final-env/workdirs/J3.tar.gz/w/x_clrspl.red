;redcode-94
;name xc
;author anon
;assert CORESIZE==8000
step    equ 3044
BD      equ 5900
        org boot
boot
        mov.i   stone+0, stone+BD+0
        mov.i   stone+1, stone+BD+1
        mov.i   stone+2, stone+BD+2
        mov.i   stone+3, stone+BD+3
        mov.i   stone+4, stone+BD+4
        mov.i   stone+5, stone+BD+5
        mov.i   stone+6, stone+BD+6
        mov.i   stone+7, stone+BD+7
        mov.i   stone+8, stone+BD+8
        mov.i   stone+9, stone+BD+9
        mov.i   stone+10, stone+BD+10
        jmp     stone+BD
stone   mov.i bmb, @ptr
ptr     add.ab #step, #step
        djn.b  stone, #1995
clr     mov.ab #(8000-(cp-stone+1)), cc
        mov.ab #1, cp
c2      mov.i  cb, >cp
cc      djn.b  c2, #0
        jmp    clr
bmb     dat  >-1, >1
cb      spl  #0, 0
cp      dat  0, 1
