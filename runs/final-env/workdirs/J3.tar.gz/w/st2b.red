;redcode-94
;name Flint3
;author anon
;assert CORESIZE==8000
step    equ 3044
        org stone
stone   spl  #0, <-30
loop    mov.i bmb, *ptr
        mov.i bmb, @ptr
        add.f inc, ptr
        jmp  loop, <-40
ptr     dat  step, step+step/2
inc     dat  step*2, step*2
bmb     dat  >-1, >1
