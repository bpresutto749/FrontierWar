;redcode-94
;name sit
        org a
a       jmp 0
