import sys
def scan(name, step, nf, first, sb="spl #0, 0", cb="dat >1, >1"):
    return f""";redcode-94
;name {name}
;author Bart
;assert CORESIZE==8000
        org loop
loop    add.ab  #{step}, ptr
ptr     jmz.f   loop, {first}
        mov.i   sbmb, @ptr
        mov.i   sbmb, <ptr
        djn.b   loop, #{nf}
clear   spl     #0, 0
cl      mov.i   cbmb, >cptr
        mov.i   cbmb, >cptr
        mov.i   cbmb, >cptr
        jmp     cl
cptr    dat     0, 3
sbmb    {sb}
cbmb    {cb}
"""
if __name__ == "__main__":
    import itertools
    i = 0
    for step in [3359, 2377, 5129, 3141]:
        for nf in [10, 40]:
            open(f"w/sc{i}.red","w").write(scan(f"sc{i}", step, nf, step))
            print(f"sc{i}", step, nf); i += 1
