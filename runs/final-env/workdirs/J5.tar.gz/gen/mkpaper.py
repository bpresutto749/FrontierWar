import sys, random
def paper(name, s1, s2, s3, b1, b2, nspl=3, bomb="dat >2667, >5334", extra=True):
    L = [";redcode-94", f";name {name}", ";author Bart", ";assert CORESIZE==8000", "        org start"]
    L.append("start   spl 1")
    for _ in range(nspl-1): L.append("        spl 1")
    L += [f"s1      spl @0, }}{s1}", "        mov.i }s1, >s1",
          f"s2      spl @0, }}{s2}", "        mov.i }s2, >s2",
          f"s3      spl @0, }}{s3}", "        mov.i }s3, >s3",
          f"        mov.i bomb, >{b1}"]
    if extra: L.append(f"        mov.i bomb, }}{b2}")
    L += ["        jmp s1", f"bomb    {bomb}"]
    return "\n".join(L) + "\n"
if __name__ == "__main__":
    random.seed(int(sys.argv[1]))
    n = int(sys.argv[2])
    for i in range(n):
        s = [random.randrange(200, 7800) for _ in range(5)]
        bomb = random.choice(["dat >2667, >5334", "dat <2667, <5334", "spl #2667, <5334", "dat #0, <2667"])
        ns = random.choice([2,3])
        ex = random.choice([True, False])
        open(f"w/pg{i}.red","w").write(paper(f"pg{i}", *s, nspl=ns, bomb=bomb, extra=ex))
        print(i, s, bomb, ns, ex)
