;redcode-94
;name imp
        org imp
imp     mov.i   #0, 1
