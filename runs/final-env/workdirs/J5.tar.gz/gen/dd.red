;redcode-94
;name dd
        org a
a       dat 0, 0
