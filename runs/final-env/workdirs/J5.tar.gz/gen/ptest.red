;redcode-94
;name ptest
        org go
go      ldp.ab  #5, x
        jmn.b   imp, x
        stp.b   one, #5
        dat     0, 0
x       dat     0, 0
one     dat     0, 1
imp     mov.i   #0, 1
