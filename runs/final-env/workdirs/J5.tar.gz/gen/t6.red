;redcode-94
;name T
;author Bart
;assert CORESIZE==8000
EXP     equ 20
        org think
think   ldp.ab  #0, res
        ldp.ab  #1, rnd
        ldp.ab  #5, cur
        jmz.b   noupd, rnd
        slt.ab  #EXP, rnd
        jmp     doupd
        jmp     noupd
doupd   mov.b   cur, idx
        add.ab  #2, idx
        mov.ba  idx, idx
        ldp.ab  idx, acc
        mov.b   res, tp
        add.b   @tp, acc
        stp.b   acc, idx
noupd   add.ab  #1, rnd
        stp.b   rnd, #1
        slt.ab  #EXP, rnd
        jmp     explore
        ldp.ab  #2, va
        ldp.ab  #3, vb
        ldp.ab  #4, vc
        mov.ab  #0, cur
        slt.b   va, vb
        jmp     c1
        mov.ab  #1, cur
        mov.b   vb, va
c1      slt.b   va, vc
        jmp     go
        mov.ab  #2, cur
        jmp     go
explore mov.b   rnd, cur
        mod.ab  #2, cur
go      stp.b   cur, #5
        jmz.b   z0_imp, cur
        slt.ab  #1, cur
        jmp     z1_a
        jmp     z0_imp
res     dat 0, 0
rnd     dat 0, 0
cur     dat 0, 0
idx     dat 0, 0
acc     dat 0, 0
va      dat 0, 0
vb      dat 0, 0
vc      dat 0, 0
tp      dat 0, 0
        dat 0, 3
        dat 0, 1
z0_imp     mov.i   #0, 1
z1_a       dat 0, 0
