;redcode-94
;name p0
;assert 1
        org go
go      ldp.ab  #0, x
        seq.ab  #2, x
        jmp     stone
        jmp     0
x       dat 0, 0
stone   add #3044, ptr
        mov bmb, @ptr
        jmp stone
ptr     dat 0, 0
bmb     dat >1, >1
