import sys
src = open(sys.argv[1]).read().split("\n")
out = []
for l in src:
    if l.strip().startswith("org"):
        out.append("        org launch")
        continue
    out.append(l)
out = [l for l in out if l.strip()]
out += ["launch  spl  start", "        spl  i3", "        spl  i4", "        jmp  imp+2667", "i3      jmp  imp", "i4      jmp  imp+5334", "imp     mov.i #0, 2667"]
open(sys.argv[2], "w").write("\n".join(out) + "\n")
