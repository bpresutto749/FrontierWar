;redcode-94
        org a
a       dat 0, 0
