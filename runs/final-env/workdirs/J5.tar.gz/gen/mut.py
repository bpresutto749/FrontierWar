import sys, random, re
src = open(sys.argv[1]).read(); seed=int(sys.argv[2]); n=int(sys.argv[3]); pre=sys.argv[4]
rng = random.Random(seed)
BOMBS = ["dat >2667, >5334", "dat <2667, <5334", "dat }2667, }5334", "dat {2667, {5334", "spl #0, <2667", "dat #0, <2667", "dat >1, >1"]
for i in range(n):
    lines = src.split("\n")
    nm = rng.choice([1,1,2])
    for _ in range(nm):
        idxs = [k for k,l in enumerate(lines) if re.search(r"[<>{}]\d+\s*$", l)]
        r = rng.random()
        if r < 0.75:
            k = rng.choice(idxs)
            m = re.search(r"([<>{}])(\d+)\s*$", lines[k])
            if rng.random() < 0.5:
                v = rng.randrange(100, 7900)
            else:
                v = (int(m.group(2)) + rng.randint(-200, 200)) % 8000
            mode = m.group(1)
            if "mov.i bomb" in lines[k] and rng.random() < 0.3: mode = rng.choice("<>{}")
            lines[k] = lines[k][:m.start()] + mode + str(v)
        else:
            k = [k for k,l in enumerate(lines) if l.startswith("bomb")][0]
            lines[k] = "bomb    " + rng.choice(BOMBS)
    t = "\n".join(lines).replace(";name pa11", f";name {pre}{i}")
    open(f"w/{pre}{i}.red","w").write(t)
