import sys, random
BOMBS = ["dat >2667, >5334", "dat <2667, <5334", "dat #0, <2667", "spl #0, <2667", "dat <5334, <2667", "dat >1, >1", "dat }2667, }5334"]
def paper(name, rng):
    nst = rng.choice([2,3,3,4])
    nspl = rng.choice([3,3,4])
    nb = rng.choice([1,2,2,3])
    bomb = rng.choice(BOMBS)
    L = [";redcode-94", f";name {name}", ";author Bart", ";assert CORESIZE==8000", "        org start"]
    L.append("start   spl 1")
    for _ in range(nspl-1): L.append("        spl 1")
    for k in range(nst):
        s = rng.randrange(200, 7800)
        L += [f"s{k}      spl @0, }}{s}", f"        mov.i }}s{k}, >s{k}"]
    for k in range(nb):
        m = rng.choice([">", "}", "<", "{"])
        L.append(f"        mov.i bomb, {m}{rng.randrange(200,7800)}")
    L += ["        jmp s0", f"bomb    {bomb}"]
    desc = f"nst={nst} nspl={nspl} nb={nb} bomb={bomb}"
    return "\n".join(L) + "\n", desc
if __name__ == "__main__":
    seed = int(sys.argv[1]); n = int(sys.argv[2]); pre = sys.argv[3]
    rng = random.Random(seed)
    for i in range(n):
        txt, d = paper(f"{pre}{i}", rng)
        open(f"w/{pre}{i}.red","w").write(txt)
        print(f"{pre}{i}", d)
