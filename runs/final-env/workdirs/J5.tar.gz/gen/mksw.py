import sys
THINK = """;redcode-94
;name {name}
;author Bart
;assert CORESIZE==8000
EXP     equ {exp}
        org think
think   ldp.ab  #0, res
        ldp.ab  #1, rnd
        ldp.ab  #5, cur
        jmz.b   noupd, rnd
        slt.ab  #EXP, rnd
        jmp     doupd
        jmp     noupd
doupd   mov.b   cur, idx
        add.ab  #2, idx
        mov.ba  idx, idx
        ldp.ab  idx, acc
        mov.b   res, tp
        add.b   @tp, acc
sx1     stp.b   acc, idx
noupd   add.ab  #1, rnd
sx2     stp.b   rnd, #1
        slt.ab  #EXP, rnd
        jmp     explore
        ldp.ab  #2, va
        ldp.ab  #3, vb
        ldp.ab  #4, vc
        mov.ab  #0, cur
        slt.b   va, vb
        jmp     c1
        mov.ab  #1, cur
        mov.b   vb, va
c1      slt.b   va, vc
        jmp     go
        mov.ab  #2, cur
        jmp     go
explore mov.b   rnd, cur
        mod.ab  #{ns}, cur
go      stp.b   cur, #5
        mov.i   kill, sx1
        mov.i   kill, sx2
        mov.i   kill, go
        jmz.b   st0, cur
        slt.ab  #1, cur
        jmp     st1
        jmp     st2
kill    dat 0, 0
res     dat 0, 0
rnd     dat 0, 0
cur     dat 0, 0
idx     dat 0, 0
acc     dat 0, 0
va      dat 0, 0
vb      dat 0, 0
vc      dat 0, 0
tp      dat 0, 0
        dat 0, 3
        dat 0, 1
"""
def body(path, lab):
    lines = open(path).read().split("\n")
    out = []
    labels = set()
    import re
    for l in lines:
        if not l.strip() or l.strip().startswith(";") or l.strip().startswith("org"): continue
        m = re.match(r"^(\w+)\s", l)
        if m: labels.add(m.group(1))
        out.append(l)
    txt = "\n".join(out)
    # find start label from org
    org = [l.split()[1] for l in lines if l.strip().startswith("org")][0]
    for L in sorted(labels, key=len, reverse=True):
        txt = re.sub(r"\b%s\b" % L, f"{lab}_{L}", txt)
    org = f"{lab}_{org}"
    return txt, org
if __name__ == "__main__":
    name, exp, out = sys.argv[1], sys.argv[2], sys.argv[3]
    parts = sys.argv[4:]
    ns = len(parts)
    txt = THINK.format(name=name, exp=exp, ns=ns)
    jumps = []
    bodies = []
    for i, p in enumerate(parts):
        b, org = body(p, f"z{i}")
        bodies.append(b); jumps.append(org)
    while len(jumps) < 3: jumps.append(jumps[0])
    txt = txt.replace("jmz.b   st0", f"jmz.b   {jumps[0]}").replace("jmp     st1", f"jmp     {jumps[1]}").replace("jmp     st2", f"jmp     {jumps[2]}")
    txt += "\n".join(bodies) + "\n"
    open(out, "w").write(txt)
