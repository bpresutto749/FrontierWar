;redcode-94
;name pg0
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s1      spl @0, }1300
        mov.i }s1, >s1
s2      spl @0, }4862
        mov.i }s2, >s2
s3      spl @0, }7142
        mov.i }s3, >s3
        mov.i bomb, >6772
        mov.i bomb, }6456
        jmp s1
bomb    dat >2667, >5334
