;redcode-94
;name pa1
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }2171
        mov.i }s0, >s0
s1      spl @0, }943
        mov.i }s1, >s1
        mov.i bomb, {684
        mov.i bomb, >2028
        mov.i bomb, >4927
        jmp s0
bomb    dat >2667, >5334
