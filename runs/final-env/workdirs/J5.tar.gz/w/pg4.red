;redcode-94
;name pg4
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
s1      spl @0, }382
        mov.i }s1, >s1
s2      spl @0, }408
        mov.i }s2, >s2
s3      spl @0, }5521
        mov.i }s3, >s3
        mov.i bomb, >4635
        jmp s1
bomb    dat #0, <2667
