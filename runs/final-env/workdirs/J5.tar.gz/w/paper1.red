;redcode-94
;name Silk1
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s1      spl @0, }3620
        mov.i }s1, >s1
s2      spl @0, }1872
        mov.i }s2, >s2
        mov.i bomb, >2550
s3      mov.i {s2, <s3
        jmp @0, >5000
bomb    dat >2667, >5334
