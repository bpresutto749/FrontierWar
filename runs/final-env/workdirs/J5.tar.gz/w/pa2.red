;redcode-94
;name pa2
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }4760
        mov.i }s0, >s0
s1      spl @0, }7232
        mov.i }s1, >s1
s2      spl @0, }1290
        mov.i }s2, >s2
s3      spl @0, }2572
        mov.i }s3, >s3
        mov.i bomb, {1381
        mov.i bomb, >4876
        jmp s0
bomb    dat >2667, >5334
