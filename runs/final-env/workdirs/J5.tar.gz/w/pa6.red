;redcode-94
;name pa6
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }5188
        mov.i }s0, >s0
s1      spl @0, }799
        mov.i }s1, >s1
s2      spl @0, }1167
        mov.i }s2, >s2
s3      spl @0, }4393
        mov.i }s3, >s3
        mov.i bomb, {1551
        mov.i bomb, <1445
        mov.i bomb, {3654
        jmp s0
bomb    dat #0, <2667
