;redcode-94
;name Switch1
;author Bart
;assert CORESIZE==8000
PC      equ 37
sstep   equ 3044
        org think
think   ldp.ab  #0, res
        ldp.ab  #PC, str
        jmn.b   keep, res
        add.ab  #1, str
keep    mod.ab  #2, str
        stp.b   str, #PC
        jmz.b   start, str
        jmp     stone
res     dat 0, 0
str     dat 0, 0
start   spl 1
        spl 1
        spl 1
s1      spl @0, }2381
        mov.i }s1, >s1
s2      spl @0, }6110
        mov.i }s2, >s2
s3      spl @0, }6768
        mov.i }s3, >s3
        mov.i bomb, >2074
        mov.i bomb, }5042
        jmp s1
bomb    dat >2667, >5334
        dat 0, 0
        dat 0, 0
stone   add #sstep, ptr
        mov sbmb, @ptr
        jmp stone
ptr     dat 0, 0
sbmb    dat >1, >1
