;redcode-94
;name Silk2
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s1      spl @0, }3620
        mov.i }s1, >s1
s2      spl @0, }1872
        mov.i }s2, >s2
s3      spl @0, }6210
        mov.i }s3, >s3
        mov.i bomb, >2550
        mov.i bomb, }1234
        jmp s1
bomb    dat >2667, >5334
