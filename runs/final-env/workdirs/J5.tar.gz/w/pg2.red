;redcode-94
;name pg2
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
s1      spl @0, }4196
        mov.i }s1, >s1
s2      spl @0, }432
        mov.i }s2, >s2
s3      spl @0, }7518
        mov.i }s3, >s3
        mov.i bomb, >7046
        jmp s1
bomb    dat #0, <2667
