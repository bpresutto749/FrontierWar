;redcode-94
;name pa0
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }595
        mov.i }s0, >s0
s1      spl @0, }793
        mov.i }s1, >s1
s2      spl @0, }6927
        mov.i }s2, >s2
        mov.i bomb, >3195
        mov.i bomb, >7652
        mov.i bomb, }507
        jmp s0
bomb    dat >1, >1
