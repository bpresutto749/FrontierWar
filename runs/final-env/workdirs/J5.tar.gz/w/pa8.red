;redcode-94
;name pa8
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
        spl 1
s0      spl @0, }6728
        mov.i }s0, >s0
s1      spl @0, }3937
        mov.i }s1, >s1
s2      spl @0, }763
        mov.i }s2, >s2
        mov.i bomb, >2411
        mov.i bomb, {5910
        mov.i bomb, >697
        jmp s0
bomb    dat <5334, <2667
