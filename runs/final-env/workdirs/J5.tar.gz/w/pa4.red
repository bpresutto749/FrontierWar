;redcode-94
;name pa4
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
        spl 1
s0      spl @0, }1887
        mov.i }s0, >s0
s1      spl @0, }4266
        mov.i }s1, >s1
        mov.i bomb, {6567
        jmp s0
bomb    dat <5334, <2667
