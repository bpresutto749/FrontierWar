;redcode-94
;name pa14
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }4839
        mov.i }s0, >s0
s1      spl @0, }2810
        mov.i }s1, >s1
s2      spl @0, }1228
        mov.i }s2, >s2
        mov.i bomb, >3940
        mov.i bomb, {3460
        jmp s0
bomb    dat <5334, <2667
