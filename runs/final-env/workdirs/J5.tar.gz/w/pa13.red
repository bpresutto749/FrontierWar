;redcode-94
;name pa13
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }2111
        mov.i }s0, >s0
s1      spl @0, }298
        mov.i }s1, >s1
s2      spl @0, }4172
        mov.i }s2, >s2
        mov.i bomb, }2352
        mov.i bomb, <233
        jmp s0
bomb    dat >1, >1
