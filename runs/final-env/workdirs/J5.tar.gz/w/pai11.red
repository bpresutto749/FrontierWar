;redcode-94
;name pa11
;author Bart
;assert CORESIZE==8000
        org launch
start   spl 1
        spl 1
        spl 1
s0      spl @0, }4267
        mov.i }s0, >s0
s1      spl @0, }860
        mov.i }s1, >s1
s2      spl @0, }1562
        mov.i }s2, >s2
        mov.i bomb, {3490
        mov.i bomb, <7436
        mov.i bomb, }6911
        jmp s0
bomb    dat }2667, }5334
launch  spl  start
        spl  i3
        spl  i4
        jmp  imp+2667
i3      jmp  imp
i4      jmp  imp+5334
imp     mov.i #0, 2667
