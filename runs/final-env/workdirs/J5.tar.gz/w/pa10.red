;redcode-94
;name pa10
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }6493
        mov.i }s0, >s0
s1      spl @0, }2554
        mov.i }s1, >s1
        mov.i bomb, }6248
        jmp s0
bomb    dat <2667, <5334
