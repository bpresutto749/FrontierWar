;redcode-94
;name pa9
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
        spl 1
s0      spl @0, }6070
        mov.i }s0, >s0
s1      spl @0, }3360
        mov.i }s1, >s1
s2      spl @0, }7466
        mov.i }s2, >s2
        mov.i bomb, <384
        mov.i bomb, {3111
        mov.i bomb, }5204
        jmp s0
bomb    dat #0, <2667
