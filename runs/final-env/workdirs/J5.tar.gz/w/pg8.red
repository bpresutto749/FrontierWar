;redcode-94
;name pg8
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
s1      spl @0, }1190
        mov.i }s1, >s1
s2      spl @0, }6287
        mov.i }s2, >s2
s3      spl @0, }2925
        mov.i }s3, >s3
        mov.i bomb, >7536
        jmp s1
bomb    dat #0, <2667
