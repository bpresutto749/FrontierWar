;redcode-94
;name ScanA
;author Bart
;assert CORESIZE==8000
step    equ 3044
        org loop
cptr    dat    0, 0
        dat    0, 0
loop    add.ab #step, scan
scan    jmz.f  loop, step
        mov.b  scan, cptr
clear   spl    #0, 0
cl      mov.i  bomb, >cptr
        mov.i  bomb, >cptr
        mov.i  bomb, >cptr
        jmp    cl
bomb    dat    >1, >1
