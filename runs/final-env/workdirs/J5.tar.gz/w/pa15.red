;redcode-94
;name pa15
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }5396
        mov.i }s0, >s0
s1      spl @0, }3480
        mov.i }s1, >s1
s2      spl @0, }709
        mov.i }s2, >s2
s3      spl @0, }1761
        mov.i }s3, >s3
        mov.i bomb, >1910
        jmp s0
bomb    spl #0, <2667
