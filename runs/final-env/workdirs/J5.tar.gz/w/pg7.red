;redcode-94
;name pg7
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
s1      spl @0, }3609
        mov.i }s1, >s1
s2      spl @0, }7061
        mov.i }s2, >s2
s3      spl @0, }7706
        mov.i }s3, >s3
        mov.i bomb, >4758
        jmp s1
bomb    dat >2667, >5334
