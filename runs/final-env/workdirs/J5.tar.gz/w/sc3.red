;redcode-94
;name sc3
;author Bart
;assert CORESIZE==8000
        org loop
loop    add.ab  #2377, ptr
ptr     jmz.f   loop, 2377
        mov.i   sbmb, @ptr
        mov.i   sbmb, <ptr
        djn.b   loop, #40
clear   spl     #0, 0
cl      mov.i   cbmb, >cptr
        mov.i   cbmb, >cptr
        mov.i   cbmb, >cptr
        jmp     cl
cptr    dat     0, 3
sbmb    spl #0, 0
cbmb    dat >1, >1
