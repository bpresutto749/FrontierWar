;redcode-94
;name pg1
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
s1      spl @0, }4258
        mov.i }s1, >s1
s2      spl @0, }6433
        mov.i }s2, >s2
s3      spl @0, }3882
        mov.i }s3, >s3
        mov.i bomb, >4068
        mov.i bomb, }5537
        jmp s1
bomb    dat #0, <2667
