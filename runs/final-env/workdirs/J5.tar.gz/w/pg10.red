;redcode-94
;name pg10
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s1      spl @0, }2188
        mov.i }s1, >s1
s2      spl @0, }6292
        mov.i }s2, >s2
s3      spl @0, }6732
        mov.i }s3, >s3
        mov.i bomb, >3511
        jmp s1
bomb    dat <2667, <5334
