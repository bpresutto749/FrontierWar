;redcode-94
;name pg11
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s1      spl @0, }908
        mov.i }s1, >s1
s2      spl @0, }3795
        mov.i }s2, >s2
s3      spl @0, }5637
        mov.i }s3, >s3
        mov.i bomb, >4365
        jmp s1
bomb    dat <2667, <5334
