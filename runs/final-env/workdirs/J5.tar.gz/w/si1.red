;redcode-94
;name StoneImp1
;author Bart
;assert CORESIZE==8000
step    equ 3044
istep   equ 2667
        org start
start   spl  stone
        spl  i3
        spl  i4
        jmp  imp+istep
i3      jmp  imp
i4      jmp  imp+2*istep
stone   mov.i  bmb, @ptr
        mov.i  bmb, *ptr
        add.f  inc, ptr
        jmp    stone
ptr     dat    100+step, 100
inc     dat    2*step, 2*step
bmb     dat    >1, >1
imp     mov.i  #0, istep
