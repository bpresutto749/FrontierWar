;redcode-94
;name pa12
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
        spl 1
s0      spl @0, }3602
        mov.i }s0, >s0
s1      spl @0, }3139
        mov.i }s1, >s1
s2      spl @0, }5792
        mov.i }s2, >s2
s3      spl @0, }7443
        mov.i }s3, >s3
        mov.i bomb, {2090
        mov.i bomb, }879
        jmp s0
bomb    dat >1, >1
