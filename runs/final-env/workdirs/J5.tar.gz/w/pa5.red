;redcode-94
;name pa5
;author Bart
;assert CORESIZE==8000
        org start
start   spl 1
        spl 1
        spl 1
s0      spl @0, }2655
        mov.i }s0, >s0
s1      spl @0, }2235
        mov.i }s1, >s1
s2      spl @0, }6707
        mov.i }s2, >s2
        mov.i bomb, }5926
        mov.i bomb, }870
        mov.i bomb, <4502
        jmp s0
bomb    dat #0, <2667
