;redcode-94
;name imp
;assert 1
mov.i #0,1
end
