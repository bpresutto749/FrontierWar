;redcode-94
;name Pebble B
;author anon
;strategy mod-5 stone
;assert CORESIZE==8000
step    equ     3315
        org     loop
loop    add.f   inc,    ptr
        mov.i   bomb,   @ptr
        mov.i   bomb,   *ptr
        djn.f   loop,   <-1000
ptr     dat     #-step, #0
inc     dat     #2*step, #2*step
bomb    dat     #1,     #1
        end
