;redcode-94
;name Seeker A
;author anon
;strategy 0.66c scanner into spl/dat clear
;assert CORESIZE==8000
step    equ     3044
gap     equ     4
        org     loop
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.ab  ptr,    cptr
        add.b   #ptr-cptr, cptr
cl      spl     #0,     0
        mov.i   sbomb,  >cptr
        djn.f   -1,     >cptr
sbomb   spl     #0,     0
cptr    dat     #0,     #0
        end
