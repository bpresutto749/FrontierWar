;redcode-94
;name Seeker Imp
;author anon
;strategy scanner into dat clear, plus 3-point imp ring
;assert CORESIZE==8000
step    equ     2823
gap     equ     4
istep   equ     2667
        org     start
start   spl     loop
        spl     b1
        spl     c1
        jmp     imp+istep
b1      jmp     imp
c1      jmp     imp+2*istep
cptr    dat     #0,     #0
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.b   ptr,    cptr
        add.b   #ptr-cptr, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
imp     mov.i   #0,     istep
fin     dat     #0,     #0
        end
