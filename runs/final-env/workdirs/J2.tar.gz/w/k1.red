;redcode-94
;name Duality C
;author anon
;strategy p-space: scanner/clear, switch to stone after a loss
;assert CORESIZE==8000
step    equ     1405
gap     equ     20
sstep   equ     3315
PS      equ     37
        org     think
cptr    dat     #0,     #0
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        sne.i   *p,     @p
        jmp     loop
found   mov.b   p,      cptr
        add.b   #p-cptr, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
sloop   add.f   sinc,   sptr
        mov.i   sbomb,  @sptr
        mov.i   sbomb,  *sptr
        jmp     sloop
sptr    dat     #-sstep, #0
sinc    dat     #2*sstep, #2*sstep
sbomb   dat     #1,     #1
think   ldp.ab  #0,     res
        ldp.ab  #PS,    str
        jmn.b   keep,   res
        add.b   #1,     str
keep    mod.ab  #2,     str
        stp.b   str,    #PS
str     jmz.b   loop,   #0
        jmp     sloop
fin
res     dat     #0,     #0
        end
