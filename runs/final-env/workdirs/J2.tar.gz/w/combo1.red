;redcode-94
;name Duality A
;author anon
;strategy p-space switch (on loss) between a scanner/clear and a stone
;assert CORESIZE==8000
PS      equ     37
step    equ     2823
gap     equ     4
sstep   equ     3315
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #PS,    str
        jmn.b   keep,   res
        add.b   #1,     str
keep    mod.ab  #2,     str
        stp.b   str,    #PS
str     jmz.b   loop,   #0
        jmp     sloop
res     dat     #0,     #0
cptr    dat     #0,     #0
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.ab  ptr,    cptr
        add.b   #ptr-cptr, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
sloop   add.f   sinc,   sptr
        mov.i   sbomb,  @sptr
        mov.i   sbomb,  *sptr
        jmp     sloop
sptr    dat     #-sstep, #0
sinc    dat     #2*sstep, #2*sstep
sbomb   dat     #1,     #1
fin     dat     #0,     #0
        end
