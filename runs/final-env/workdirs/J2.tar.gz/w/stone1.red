;redcode-94
;name Pebble A
;author anon
;strategy mod-4 stone + dclear
;assert CORESIZE==8000
step    equ     3044
        org     loop
loop    mov.i   bomb,   @ptr
ptr     mov.i   bomb,   *step
        add.f   inc,    ptr
        djn.f   loop,   <-100
bomb    dat     >1,     >1
inc     dat     step*2, step*2
        end
