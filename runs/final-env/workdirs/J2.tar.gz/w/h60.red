;redcode-94
;name Seeker H
;author anon
;strategy 0.8c scanner into dat clear, with decoy
;assert CORESIZE==8000
step    equ     2365
gap     equ     20
        org     loop
cptr    dat     #0,     #0
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        jmp     loop
found   mov.b   p,      cptr
        add.b   #p-cptr-0, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
        dat     #1, #1
        dat     #12, #7
        dat     #10, #13
        dat     #8, #2
        dat     #6, #8
        dat     #4, #14
        dat     #2, #3
        dat     #13, #9
        dat     #11, #15
        dat     #9, #4
        dat     #7, #10
        dat     #5, #16
        dat     #3, #5
        dat     #1, #11
        dat     #12, #17
        dat     #10, #6
        dat     #8, #12
        dat     #6, #1
        dat     #4, #7
        dat     #2, #13
        dat     #13, #2
        dat     #11, #8
        dat     #9, #14
        dat     #7, #3
        dat     #5, #9
        dat     #3, #15
        dat     #1, #4
        dat     #12, #10
        dat     #10, #16
        dat     #8, #5
        dat     #6, #11
        dat     #4, #17
        dat     #2, #6
        dat     #13, #12
        dat     #11, #1
        dat     #9, #7
        dat     #7, #13
        dat     #5, #2
        dat     #3, #8
        dat     #1, #14
        dat     #12, #3
        dat     #10, #9
        dat     #8, #15
        dat     #6, #4
        dat     #4, #10
        dat     #2, #16
        dat     #13, #5
        dat     #11, #11
        dat     #9, #17
        dat     #7, #6
        dat     #5, #12
        dat     #3, #1
        dat     #1, #7
        dat     #12, #13
        dat     #10, #2
        dat     #8, #8
        dat     #6, #14
        dat     #4, #3
        dat     #2, #9
        dat     #13, #15
fin     dat     #0,     #0
        end
