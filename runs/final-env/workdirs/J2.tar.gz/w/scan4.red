;redcode-94
;name Seeker D
;author anon
;strategy 0.66c scanner into spl/dat clear
;assert CORESIZE==8000
step    equ     2823
gap     equ     4
        org     loop
cptr    dat     #sb-cptr, #0
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.ab  ptr,    cptr
        add.b   #ptr-cptr, cptr
        slt.ab  #15,    cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   *cptr,  >cptr
        mov.i   *cptr,  >cptr
        jmp     -2
sb      spl     #db-cptr, #15
db      dat     #db-cptr, #15
        end
