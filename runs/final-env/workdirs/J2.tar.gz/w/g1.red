;redcode-94
;name Seeker G
;author anon
;strategy 0.8c scanner, spl-bombs each find, dat clear when it sees itself
;assert CORESIZE==8000
step    equ     2365
gap     equ     20
        org     loop
cptr    dat     #0,     #fin+1-cptr
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        jmp     loop
found   mov.b   p,      t
        add.ab  #p-cptr+gap, t
        slt.ab  #fin+1-cptr+gap, t
        jmp     cl
        mov.i   sbomb,  @p
        mov.i   sbomb,  *p
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
sbomb   spl     #0,     0
t       dat     #0,     #0
fin
dbomb   dat     #0,     #fin+1-cptr
        end
