;redcode-94
;name Seeker E
;author anon
;strategy 0.66c scanner into spl/dat clear
;assert CORESIZE==8000
step    equ     2823
gap     equ     4
        org     loop
cptr    dat     #sb-cptr, #0
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.ab  ptr,    cptr
        add.b   #ptr-cptr, cptr
        slt.ab  #14,    cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   *cptr,  >cptr
        djn.b   -1,     >cptr
sb      spl     #db-cptr, #14
db      dat     #db-cptr, #14
        end
