;redcode-94
;name Seeker H
;author anon
;strategy 0.8c scanner into dat clear, with decoy
;assert CORESIZE==8000
step    equ     2365
gap     equ     20
        org     loop
        dat     #1, #1
        dat     #10, #11
        dat     #8, #2
        dat     #6, #12
        dat     #4, #3
        dat     #2, #13
        dat     #11, #4
        dat     #9, #14
        dat     #7, #5
        dat     #5, #15
        dat     #3, #6
        dat     #1, #16
        dat     #10, #7
        dat     #8, #17
        dat     #6, #8
        dat     #4, #18
        dat     #2, #9
        dat     #11, #19
        dat     #9, #10
        dat     #7, #1
cptr    dat     #0,     #0
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        jmp     loop
found   mov.b   p,      cptr
        add.b   #p-cptr-0, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
fin     dat     #0,     #0
        end
