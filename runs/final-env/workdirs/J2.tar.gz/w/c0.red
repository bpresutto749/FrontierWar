;redcode-94
;name Duality B
;author anon
;strategy p-space greedy selector (windowed average) between a scanner/clear and a stone
;assert CORESIZE==8000
step    equ     2823
gap     equ     4
sstep   equ     3315
EXPL    equ     4
        org     loop
cptr    dat     #0,     #0
inc     dat     #step,  #step
loop    add.f   inc,    ptr
ptr     sne.i   step+gap, step
        jmp     loop
        mov.ab  ptr,    cptr
        add.b   #ptr-cptr, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
sloop   add.f   sinc,   sptr
        mov.i   sbomb,  @sptr
        mov.i   sbomb,  *sptr
        jmp     sloop
sptr    dat     #-sstep, #0
sinc    dat     #2*sstep, #2*sstep
sbomb   dat     #1,     #1
think   ldp.ab  #0,     res
        ldp.ab  #6,     prv
        sne.ab  #-1,    res
        jmp     decide
        add.b   res,    tp
        mov.b   @tp,    pts
        mov.b   prv,    ss
        add.b   prv,    ss
        add.ab  #2,     ss
        ldp.b   ss,     sm
        add.b   pts,    sm
        mov.b   ss,     ns
        add.ab  #1,     ns
        ldp.b   ns,     nn
        add.ab  #1,     nn
        slt.ab  #31,    nn
        jmp     store
        div.ab  #2,     nn
        div.ab  #2,     sm
store   stp.b   sm,     ss
        stp.b   nn,     ns
decide  ldp.ab  #2,     a0
        ldp.ab  #3,     c0
        ldp.ab  #4,     a1
        ldp.ab  #5,     c1
        slt.ab  #EXPL-1, c0
        jmp     go0
        slt.ab  #EXPL-1, c1
        jmp     go1
        mul.ab  #80,    a0
        div.b   c0,     a0
        mul.ab  #80,    a1
        div.b   c1,     a1
        slt.b   a0,     a1
        jmp     go0
go1     stp.ab  #1,     #6
        jmp     sloop
go0     stp.ab  #0,     #6
        jmp     loop
res     dat     #0,     #0
prv     dat     #0,     #0
tp      dat     #0,     #tab-tp
pts     dat     #0,     #0
ss      dat     #0,     #0
sm      dat     #0,     #0
ns      dat     #0,     #0
nn      dat     #0,     #0
a0      dat     #0,     #0
c0      dat     #0,     #0
a1      dat     #0,     #0
c1      dat     #0,     #0
tab     dat     #0,     #0
        dat     #0,     #3
fin     dat     #0,     #1
        end
