import sys
name, step, gap, U = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
body = ""
for i in range(U-1):
    body += "        add.f   inc,    p\n        seq.i   *p,     @p\n        jmp     found\n"
body += "        add.f   inc,    p\n        sne.i   *p,     @p\n        jmp     loop\n"
body = body.replace("        add.f   inc,    p\n", "loop    add.f   inc,    p\n", 1)
open(f"/tmp/arena_J2/w/{name}.red","w").write(f""";redcode-94
;name Seeker I
;author anon
;strategy unrolled scanner into dat clear
;assert CORESIZE==8000
step    equ     {step}
gap     equ     {gap}
        org     loop
cptr    dat     #0,     #0
inc     dat     #step,  #step
p       dat     #gap,   #0
{body}found   mov.b   p,      cptr
        add.b   #p-cptr, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
fin
dbomb   dat     #0,     #fin+1-cptr
        end
""")
