import sys
name, step, gap = sys.argv[1], sys.argv[2], sys.argv[3]
open(f"/tmp/arena_J2/w/{name}.red","w").write(f""";redcode-94
;name Seeker J
;author anon
;strategy 0.8c scanner into dat clear sharing the scan pointer
;assert CORESIZE==8000
step    equ     {step}
gap     equ     {gap}
        org     loop
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        sne.i   *p,     @p
        jmp     loop
found   slt.ab  #fin+1-p, p
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >p
        djn.f   -1,     >p
fin
dbomb   dat     #0,     #fin+1-p
        end
""")
