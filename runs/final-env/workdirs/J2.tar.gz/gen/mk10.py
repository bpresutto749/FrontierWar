import sys
name, step, gap, nd = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
pre = int(sys.argv[5]) if len(sys.argv)>5 else 0
off = sys.argv[6] if len(sys.argv)>6 else "0"
dec = "".join(f"        dat     #{(i*37)%13+1}, #{(i*91)%17+1}\n" for i in range(nd))
decp = "".join(f"        dat     #{(i*53)%11+1}, #{(i*29)%19+1}\n" for i in range(pre))
open(f"/tmp/arena_J2/w/{name}.red","w").write(f""";redcode-94
;name Seeker H
;author anon
;strategy 0.8c scanner into dat clear, with decoy
;assert CORESIZE==8000
step    equ     {step}
gap     equ     {gap}
        org     loop
{decp}cptr    dat     #0,     #0
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        jmp     loop
found   mov.b   p,      cptr
        add.b   #p-cptr-{off}, cptr
        slt.ab  #fin+1-cptr, cptr
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
dbomb   dat     #0,     #fin+1-cptr
{dec}fin     dat     #0,     #0
        end
""")
