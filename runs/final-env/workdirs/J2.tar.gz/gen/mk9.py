import sys
name, step, gap = sys.argv[1], sys.argv[2], sys.argv[3]
bomb = sys.argv[4] if len(sys.argv)>4 else "spl     #0,     0"
open(f"/tmp/arena_J2/w/{name}.red","w").write(f""";redcode-94
;name Seeker G
;author anon
;strategy 0.8c scanner, spl-bombs each find, dat clear when it sees itself
;assert CORESIZE==8000
step    equ     {step}
gap     equ     {gap}
        org     loop
cptr    dat     #0,     #fin+1-cptr
inc     dat     #step,  #step
p       dat     #gap,   #0
loop    add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        add.f   inc,    p
        seq.i   *p,     @p
        jmp     found
        jmp     loop
found   mov.b   p,      t
        add.ab  #p-cptr+gap, t
        slt.ab  #fin+1-cptr+gap, t
        jmp     cl
        mov.i   sbomb,  @p
        mov.i   sbomb,  *p
        jmp     loop
cl      spl     #0,     0
        mov.i   dbomb,  >cptr
        djn.f   -1,     >cptr
sbomb   {bomb}
t       dat     #0,     #0
fin
dbomb   dat     #0,     #fin+1-cptr
        end
""")
