;redcode-94
;name rs1_1
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 1115
        mov.i  }s1, >s1
s2      spl    @0, 4208
        mov.i  }s2, >s2
s3      spl    @0, 6383
        mov.i  }s3, >s3
        mov.i  bmb, }3832
        mov.i  bmb, >4018
        mov.i  bmb, }5487
        djn.f  -3, <3259
bmb     dat    <2667, <5334
