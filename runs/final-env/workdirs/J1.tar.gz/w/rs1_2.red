;redcode-94
;name rs1_2
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 6611
        mov.i  }s1, >s1
s2      spl    @0, 1869
        mov.i  }s2, >s2
s3      spl    @0, 918
        mov.i  }s3, >s3
        mov.i  bmb, }4146
        mov.i  bmb, >382
        mov.i  bmb, }7468
        djn.f  -3, <6996
bmb     dat    <2667, <5334
