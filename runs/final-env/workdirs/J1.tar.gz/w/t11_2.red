;redcode-94
;name t11_2
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 3620
        mov.i  }s0, >s0
s1      spl    @0, 5250
        mov.i  }s1, >s1
s2      spl    @0, 1820
        mov.i  }s2, >s2
        mov.i  bmb2, }3896
        mov.i  bmb, }5514
        mov.i  bmb2, }2428
        djn.f  -3, <2732
bmb     dat    <2667, <5334
bmb2    spl    #1, <5334
