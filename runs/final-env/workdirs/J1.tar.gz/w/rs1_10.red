;redcode-94
;name rs1_10
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 7656
        mov.i  }s1, >s1
s2      spl    @0, 4708
        mov.i  }s2, >s2
s3      spl    @0, 7704
        mov.i  }s3, >s3
        mov.i  bmb, }5411
        mov.i  bmb, >969
        mov.i  bmb, }1672
        djn.f  -3, <5305
bmb     dat    <2667, <5334
