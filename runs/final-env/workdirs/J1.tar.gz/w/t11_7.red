;redcode-94
;name t11_7
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 5075
        mov.i  }s0, >s0
s1      spl    @0, 3170
        mov.i  }s1, >s1
s2      spl    @0, 3194
        mov.i  }s2, >s2
        mov.i  bmb, }1192
        mov.i  bmb2, }4960
        mov.i  bmb, }4112
        djn.f  -3, <5288
bmb     dat    <2667, <5334
bmb2    spl    #1, <5334
