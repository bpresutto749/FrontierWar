;redcode-94
;name rs1_5
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 7534
        mov.i  }s1, >s1
s2      spl    @0, 2750
        mov.i  }s2, >s2
s3      spl    @0, 400
        mov.i  }s3, >s3
        mov.i  bmb, }332
        mov.i  bmb, >358
        mov.i  bmb, }5471
        djn.f  -3, <4585
bmb     dat    <2667, <5334
