;redcode-94
;name c3_10
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 2099
        mov.i  }s0, >s0
s1      spl    @0, 5482
        mov.i  }s1, >s1
s2      spl    @0, 545
        mov.i  }s2, >s2
        mov.i  bmb, }6877
        mov.i  bmb, >2311
        djn.f  -2, <4539
bmb     dat    <2667, <5334
bmb2    spl    #0, <2667
