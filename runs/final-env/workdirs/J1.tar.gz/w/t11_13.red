;redcode-94
;name t11_13
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 4027
        mov.i  }s0, >s0
s1      spl    @0, 7529
        mov.i  }s1, >s1
s2      spl    @0, 786
        mov.i  }s2, >s2
        mov.i  bmb2, >6626
        mov.i  bmb, }397
        djn.f  -2, <5269
bmb     dat    <1, <2667
bmb2    spl    #0, >2667
