;redcode-94
;name q7_12
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 6198
        mov.i  }s0, >s0
s1      spl    @0, 2178
        mov.i  }s1, >s1
s2      spl    @0, 3409
        mov.i  }s2, >s2
        mov.i  bmb, }7660
        mov.i  bmb, >7288
        mov.i  bmb, }4217
        djn.f  -3, <810
bmb     dat    >2667, >5334
