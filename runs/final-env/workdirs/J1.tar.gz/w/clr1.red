;redcode-94
;name Broom
;author arena
;strategy spl/dat forward core clear with a gate

        org start
ptr     dat    #0, #50
        dat    0, 0
start   spl    #0, 0
loop    mov.i  @sw, >ptr
        djn.f  loop, >ptr
sw      dat    #0, sbmb
        dat    0, 0
sbmb    spl    #0, 0
dbmb    dat    0, 0
