;redcode-94
;name q7_15
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 2302
        mov.i  }s0, >s0
s1      spl    @0, 2459
        mov.i  }s1, >s1
s2      spl    @0, 183
        mov.i  }s2, >s2
s3      spl    @0, 1343
        mov.i  }s3, >s3
        mov.i  bmb, }4529
        mov.i  bmb, >3174
        mov.i  bmb, }5145
        djn.f  -3, <4789
bmb     dat    <2667, >5334
