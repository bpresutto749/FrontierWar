;redcode-94
;name rs1_6
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 225
        mov.i  }s1, >s1
s2      spl    @0, 7843
        mov.i  }s2, >s2
s3      spl    @0, 7369
        mov.i  }s3, >s3
        mov.i  bmb, }3272
        mov.i  bmb, >5773
        mov.i  bmb, }1924
        djn.f  -3, <3607
bmb     dat    <2667, <5334
