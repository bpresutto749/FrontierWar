;redcode-94
;name q7_9
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 5845
        mov.i  }s0, >s0
s1      spl    @0, 3018
        mov.i  }s1, >s1
s2      spl    @0, 5019
        mov.i  }s2, >s2
        mov.i  bmb, }4900
        mov.i  bmb, >6678
        mov.i  bmb, }3887
        djn.f  -3, <713
bmb     dat    <2667, <5334
