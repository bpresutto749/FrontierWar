;redcode-94
;name rs1_0
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 1250
        mov.i  }s1, >s1
s2      spl    @0, 4812
        mov.i  }s2, >s2
s3      spl    @0, 7092
        mov.i  }s3, >s3
        mov.i  bmb, }6722
        mov.i  bmb, >6406
        mov.i  bmb, }666
        djn.f  -3, <2239
bmb     dat    <2667, <5334
