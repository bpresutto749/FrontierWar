;redcode-94
;name t11_20
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 4535
        mov.i  }s0, >s0
s1      spl    @0, 5516
        mov.i  }s1, >s1
s2      spl    @0, 5392
        mov.i  }s2, >s2
        mov.i  bmb, }788
        mov.i  bmb, }5757
        djn.f  -2, <6898
bmb     dat    >2667, >5334
bmb2    spl    #1, <5334
