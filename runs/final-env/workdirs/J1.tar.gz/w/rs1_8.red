;redcode-94
;name rs1_8
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 4211
        mov.i  }s1, >s1
s2      spl    @0, 4679
        mov.i  }s2, >s2
s3      spl    @0, 2059
        mov.i  }s3, >s3
        mov.i  bmb, }2981
        mov.i  bmb, >2041
        mov.i  bmb, }5694
        djn.f  -3, <1942
bmb     dat    <2667, <5334
