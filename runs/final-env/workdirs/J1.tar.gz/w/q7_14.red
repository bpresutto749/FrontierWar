;redcode-94
;name q7_14
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 1386
        mov.i  }s0, >s0
s1      spl    @0, 829
        mov.i  }s1, >s1
s2      spl    @0, 1593
        mov.i  }s2, >s2
        mov.i  bmb, }2050
        mov.i  bmb, >5544
        djn.f  -2, <2061
bmb     dat    <2667, <5334
