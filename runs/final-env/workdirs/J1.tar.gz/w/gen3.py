def paper3(name, nspl, ds, bs, kinds, gate, bombA, bombB, ops=None):
    L=[";redcode-94",f";name {name}",";author arena",";strategy multi-stage silk replicator with mixed spl/dat bombing","        org start","start   spl    1"]
    L+=["        spl    1"]*(nspl-1)
    for i,d in enumerate(ds):
        L.append(f"s{i}      spl    @0, {d}")
        L.append(f"        mov.i  }}s{i}, >s{i}")
    if ops is None: ops=["}",">"]*4
    for j,(b,k) in enumerate(zip(bs,kinds)):
        L.append(f"        mov.i  {'bmb' if k==0 else 'bmb2'}, {ops[j]}{b}")
    L.append(f"        djn.f  -{len(bs)}, <{gate}")
    L.append(f"bmb     {bombA}")
    L.append(f"bmb2    {bombB}")
    open(name+".red","w").write("\n".join(L)+"\n")
