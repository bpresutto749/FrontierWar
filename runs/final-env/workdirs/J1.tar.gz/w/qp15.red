;redcode-94
;name qp15
;author arena
;strategy unrolled pair-qscan that dat-carpets a hit, then a three-stage silk paper
        org q
ptr     dat    0, 0
q       seq.i  99, 4143
        mov.ab #92, ptr
        seq.i  366, 4411
        mov.ab #361, ptr
        seq.i  634, 4679
        mov.ab #631, ptr
        seq.i  901, 4946
        mov.ab #900, ptr
        seq.i  1169, 5214
        mov.ab #1170, ptr
        seq.i  1437, 5482
        mov.ab #1440, ptr
        seq.i  1704, 5749
        mov.ab #1709, ptr
        seq.i  1972, 6017
        mov.ab #1979, ptr
        seq.i  2240, 6285
        mov.ab #2249, ptr
        seq.i  2507, 6552
        mov.ab #2518, ptr
        seq.i  2775, 6820
        mov.ab #2788, ptr
        seq.i  3043, 7088
        mov.ab #3058, ptr
        seq.i  3310, 7355
        mov.ab #3327, ptr
        seq.i  3578, 7623
        mov.ab #3597, ptr
        seq.i  3846, 7891
        mov.ab #3867, ptr
        jmz.b  paper, ptr
atk     mov.i  qb, >ptr
        djn.b  atk, #20
        add.ab #4024, ptr
atk2    mov.i  qb, >ptr
        djn.b  atk2, #20
        jmp    paper
qb      dat    >2667, >5334
paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334
