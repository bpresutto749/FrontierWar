;redcode-94
;name q7_11
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 334
        mov.i  }s0, >s0
s1      spl    @0, 3932
        mov.i  }s1, >s1
s2      spl    @0, 3061
        mov.i  }s2, >s2
        mov.i  bmb, }5154
        mov.i  bmb, >1109
        djn.f  -2, <4194
bmb     dat    <2667, <5334
