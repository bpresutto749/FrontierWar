import random, subprocess, sys, re, json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'.')
from gen2 import paper2
seed=int(sys.argv[1]); n=int(sys.argv[2]); par=int(sys.argv[3])
random.seed(seed)
def rnd(): return random.randint(150, 7850)
bombs=["dat    <2667, <5334","dat    >2667, >5334","dat    <2667, >5334","spl    #0, <2667","dat    #0, <2667","dat    <1, <2667"]
def run(i):
    name=f"q{seed}_{i}"
    ns=random.choice([2,3,3,3,4])
    p=dict(nspl=random.choice([3,4,4,5]), ds=[rnd() for _ in range(ns)], bs=[rnd() for _ in range(random.choice([1,2,3,3,4]))], gate=rnd(), bomb=random.choice(bombs), loop=random.choice(["djn","djn","jmp"]))
    paper2(name, **p)
    out=subprocess.run(["python3","../tools/spar.py",name+".red","--rounds","100"],capture_output=True,text=True).stdout
    m=re.search(r"MEAN\s+([\d.]+)",out)
    sc=float(m.group(1)) if m else -1
    with open("log2.txt","a") as f: f.write(f"{sc:.3f} {name} {json.dumps(p)}\n")
    return sc
with ThreadPoolExecutor(par) as ex: list(ex.map(run, range(n)))
