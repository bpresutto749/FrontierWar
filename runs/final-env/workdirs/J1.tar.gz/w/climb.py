import random, subprocess, sys, re, json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'.')
from gen3 import paper3
tag=sys.argv[1]; base=json.loads(sys.argv[2]); n=int(sys.argv[3]); par=int(sys.argv[4]); rounds=sys.argv[5]; seed=int(sys.argv[6])
random.seed(seed)
def mutate(p):
    q=json.loads(json.dumps(p))
    k=random.choice(["ds","ds","bs","gate","kinds","bombA"])
    if k=="ds":
        i=random.randrange(len(q["ds"])); q["ds"][i]=random.randint(150,7850)
    elif k=="bs":
        i=random.randrange(len(q["bs"])); q["bs"][i]=random.randint(150,7850)
    elif k=="gate": q["gate"]=random.randint(150,7850)
    elif k=="kinds":
        i=random.randrange(len(q["kinds"])); q["kinds"][i]^=1
    else: q["bombA"]=random.choice(["dat    <2667, <5334","dat    >2667, >5334","dat    <1, <2667"])
    return q
def run(i):
    name=f"{tag}_{i}"
    p=base if i==0 else mutate(base)
    paper3(name, **p)
    out=subprocess.run(["python3","../tools/spar.py",name+".red","--rounds",rounds],capture_output=True,text=True).stdout
    m=re.search(r"MEAN\s+([\d.]+)",out)
    sc=float(m.group(1)) if m else -1
    with open("logc.txt","a") as f: f.write(f"{sc:.3f} {name} {json.dumps(p)}\n")
    return sc
with ThreadPoolExecutor(par) as ex: list(ex.map(run, range(n)))
