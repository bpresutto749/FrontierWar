;redcode-94
;name t11_8
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 5302
        mov.i  }s0, >s0
s1      spl    @0, 4687
        mov.i  }s1, >s1
s2      spl    @0, 1760
        mov.i  }s2, >s2
        mov.i  bmb, >7376
        mov.i  bmb2, }4102
        mov.i  bmb, >5094
        djn.f  -3, <1000
bmb     dat    <2667, <5334
bmb2    spl    #0, <2667
