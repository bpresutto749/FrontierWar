;redcode-94
;name Gravel
;author arena
;strategy mod-4 stone plus a 3-point imp ring

step    equ 3044
istep   equ 2667
        org start
start   mov.i  imp, imp+istep
        mov.i  imp, imp+2*istep
        spl    stone
        spl    b2
        jmp    imp
b2      spl    b3
        jmp    imp+istep
b3      jmp    imp+2*istep
stone   mov.i  bomb, @ptr
        mov.i  bomb, *ptr
        add.f  inc, ptr
        jmp    stone
ptr     dat    #step, #step*2
inc     dat    #step*2, #step*2
bomb    dat    #0, #0
        dat    0, 0
imp     mov.i  #0, istep
