;redcode-94
;name t11_0
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 7169
        mov.i  }s0, >s0
s1      spl    @0, 7721
        mov.i  }s1, >s1
s2      spl    @0, 6549
        mov.i  }s2, >s2
        mov.i  bmb, }3851
        mov.i  bmb, }4310
        mov.i  bmb2, }7154
        mov.i  bmb, >4961
        djn.f  -4, <921
bmb     dat    >2667, >5334
bmb2    spl    #1, <5334
