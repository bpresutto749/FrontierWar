;redcode-94
;name rs1_9
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 6383
        mov.i  }s1, >s1
s2      spl    @0, 3915
        mov.i  }s2, >s2
s3      spl    @0, 2523
        mov.i  }s3, >s3
        mov.i  bmb, }7739
        mov.i  bmb, >326
        mov.i  bmb, }3559
        djn.f  -3, <7011
bmb     dat    <2667, <5334
