;redcode-94
;name q7_3
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 556
        mov.i  }s0, >s0
s1      spl    @0, 1961
        mov.i  }s1, >s1
s2      spl    @0, 531
        mov.i  }s2, >s2
s3      spl    @0, 4710
        mov.i  }s3, >s3
        mov.i  bmb, }2522
        mov.i  bmb, >3583
        djn.f  -2, <1331
bmb     dat    #0, <2667
