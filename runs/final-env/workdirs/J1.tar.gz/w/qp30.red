;redcode-94
;name qp30
;author arena
;strategy unrolled pair-qscan that dat-carpets a hit, then a three-stage silk paper
        org q
ptr     dat    0, 0
q       seq.i  99, 4075
        mov.ab #92, ptr
        seq.i  229, 4205
        mov.ab #224, ptr
        seq.i  360, 4336
        mov.ab #357, ptr
        seq.i  490, 4466
        mov.ab #489, ptr
        seq.i  621, 4597
        mov.ab #622, ptr
        seq.i  751, 4727
        mov.ab #754, ptr
        seq.i  882, 4858
        mov.ab #887, ptr
        seq.i  1012, 4989
        mov.ab #1019, ptr
        seq.i  1143, 5119
        mov.ab #1152, ptr
        seq.i  1273, 5250
        mov.ab #1284, ptr
        seq.i  1404, 5380
        mov.ab #1417, ptr
        seq.i  1534, 5511
        mov.ab #1549, ptr
        seq.i  1665, 5641
        mov.ab #1682, ptr
        seq.i  1796, 5772
        mov.ab #1815, ptr
        seq.i  1926, 5902
        mov.ab #1947, ptr
        seq.i  2057, 6033
        mov.ab #2080, ptr
        seq.i  2187, 6163
        mov.ab #2212, ptr
        seq.i  2318, 6294
        mov.ab #2345, ptr
        seq.i  2448, 6425
        mov.ab #2477, ptr
        seq.i  2579, 6555
        mov.ab #2610, ptr
        seq.i  2709, 6686
        mov.ab #2742, ptr
        seq.i  2840, 6816
        mov.ab #2875, ptr
        seq.i  2970, 6947
        mov.ab #3007, ptr
        seq.i  3101, 7077
        mov.ab #3140, ptr
        seq.i  3232, 7208
        mov.ab #3273, ptr
        seq.i  3362, 7338
        mov.ab #3405, ptr
        seq.i  3493, 7469
        mov.ab #3538, ptr
        seq.i  3623, 7599
        mov.ab #3670, ptr
        seq.i  3754, 7730
        mov.ab #3803, ptr
        seq.i  3884, 7861
        mov.ab #3935, ptr
        jmz.b  paper, ptr
atk     mov.i  qb, >ptr
        djn.b  atk, #20
        jmp    paper
qb      dat    >2667, >5334
paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334
