;redcode-94
;name q7_2
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 634
        mov.i  }s0, >s0
s1      spl    @0, 6923
        mov.i  }s1, >s1
        mov.i  bmb, }1164
        mov.i  bmb, >1978
        mov.i  bmb, }5316
        mov.i  bmb, >5289
        jmp    -4, <4925
bmb     dat    <2667, <5334
