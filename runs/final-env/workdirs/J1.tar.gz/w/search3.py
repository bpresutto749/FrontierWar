import random, subprocess, sys, re, json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'.')
from gen3 import paper3
seed=int(sys.argv[1]); n=int(sys.argv[2]); par=int(sys.argv[3]); rounds=sys.argv[4] if len(sys.argv)>4 else "100"
random.seed(seed)
def rnd(): return random.randint(150, 7850)
A=["dat    <2667, <5334","dat    >2667, >5334","dat    <1, <2667"]
B=["spl    #0, <2667","spl    #0, 0","spl    #1, <5334","spl    #0, >2667"]
def run(i):
    name=f"t{seed}_{i}"
    nb=random.choice([2,3,3,4])
    p=dict(nspl=random.choice([4,4,5]), ds=random.choice([[3620,5250,1820],[rnd(),rnd(),rnd()]]), bs=[rnd() for _ in range(nb)], kinds=[random.randint(0,1) for _ in range(nb)], gate=rnd(), bombA=random.choice(A), bombB=random.choice(B), ops=[random.choice("}>") for _ in range(nb)])
    paper3(name, **p)
    out=subprocess.run(["python3","../tools/spar.py",name+".red","--rounds",rounds],capture_output=True,text=True).stdout
    m=re.search(r"MEAN\s+([\d.]+)",out)
    sc=float(m.group(1)) if m else -1
    with open("log3.txt","a") as f: f.write(f"{sc:.3f} {name} {json.dumps(p)}\n")
    return sc
with ThreadPoolExecutor(par) as ex: list(ex.map(run, range(n)))
