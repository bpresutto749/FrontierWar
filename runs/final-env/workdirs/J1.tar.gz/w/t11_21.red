;redcode-94
;name t11_21
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 3620
        mov.i  }s0, >s0
s1      spl    @0, 5250
        mov.i  }s1, >s1
s2      spl    @0, 1820
        mov.i  }s2, >s2
        mov.i  bmb, }2381
        mov.i  bmb2, >6528
        mov.i  bmb, >2982
        mov.i  bmb, }4571
        djn.f  -4, <3512
bmb     dat    <1, <2667
bmb2    spl    #0, >2667
