;redcode-94
;name t11_15
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 6295
        mov.i  }s0, >s0
s1      spl    @0, 4365
        mov.i  }s1, >s1
s2      spl    @0, 394
        mov.i  }s2, >s2
        mov.i  bmb2, >5075
        mov.i  bmb, >868
        djn.f  -2, <2035
bmb     dat    <1, <2667
bmb2    spl    #0, <2667
