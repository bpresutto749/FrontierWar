;redcode-94
;name qp25
;author arena
;strategy unrolled pair-qscan that dat-carpets a hit, then a three-stage silk paper
        org q
ptr     dat    0, 0
q       seq.i  99, 4088
        mov.ab #92, ptr
        seq.i  256, 4246
        mov.ab #251, ptr
        seq.i  414, 4403
        mov.ab #411, ptr
        seq.i  571, 4561
        mov.ab #570, ptr
        seq.i  729, 4719
        mov.ab #730, ptr
        seq.i  886, 4876
        mov.ab #889, ptr
        seq.i  1044, 5034
        mov.ab #1049, ptr
        seq.i  1202, 5191
        mov.ab #1209, ptr
        seq.i  1359, 5349
        mov.ab #1368, ptr
        seq.i  1517, 5507
        mov.ab #1528, ptr
        seq.i  1674, 5664
        mov.ab #1687, ptr
        seq.i  1832, 5822
        mov.ab #1847, ptr
        seq.i  1990, 5979
        mov.ab #2007, ptr
        seq.i  2147, 6137
        mov.ab #2166, ptr
        seq.i  2305, 6295
        mov.ab #2326, ptr
        seq.i  2462, 6452
        mov.ab #2485, ptr
        seq.i  2620, 6610
        mov.ab #2645, ptr
        seq.i  2778, 6767
        mov.ab #2805, ptr
        seq.i  2935, 6925
        mov.ab #2964, ptr
        seq.i  3093, 7083
        mov.ab #3124, ptr
        seq.i  3250, 7240
        mov.ab #3283, ptr
        seq.i  3408, 7398
        mov.ab #3443, ptr
        seq.i  3566, 7555
        mov.ab #3603, ptr
        seq.i  3723, 7713
        mov.ab #3762, ptr
        seq.i  3881, 7871
        mov.ab #3922, ptr
        jmz.b  paper, ptr
atk     mov.i  qb, >ptr
        djn.b  atk, #20
        add.ab #3969, ptr
atk2    mov.i  qb, >ptr
        djn.b  atk2, #20
        jmp    paper
qb      dat    >2667, >5334
paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334
