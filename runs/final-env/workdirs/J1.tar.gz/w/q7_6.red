;redcode-94
;name q7_6
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 4946
        mov.i  }s0, >s0
s1      spl    @0, 7714
        mov.i  }s1, >s1
s2      spl    @0, 3862
        mov.i  }s2, >s2
        mov.i  bmb, }2605
        mov.i  bmb, >2185
        mov.i  bmb, }6657
        djn.f  -3, <1622
bmb     dat    <1, <2667
