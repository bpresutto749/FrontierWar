;redcode-94
;name q7_4
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 4739
        mov.i  }s0, >s0
s1      spl    @0, 6835
        mov.i  }s1, >s1
s2      spl    @0, 5736
        mov.i  }s2, >s2
s3      spl    @0, 1630
        mov.i  }s3, >s3
        mov.i  bmb, }4914
        djn.f  -1, <4829
bmb     dat    <1, <2667
