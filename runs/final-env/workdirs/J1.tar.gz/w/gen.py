import sys
def paper(name, nspl, d1, d2, d3, b1=1777, b2=-2311, b3=3001, gate=-1200, bomb="dat    <2667, <5334", extra=""):
    s = f""";redcode-94
;name {name}
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
""" + "        spl    1\n"*(nspl-1) + f"""s1      spl    @0, {d1}
        mov.i  }}s1, >s1
s2      spl    @0, {d2}
        mov.i  }}s2, >s2
s3      spl    @0, {d3}
        mov.i  }}s3, >s3
        mov.i  bmb, }}{b1}
        mov.i  bmb, >{b2}
        mov.i  bmb, }}{b3}
        djn.f  -3, <{gate}
bmb     {bomb}
{extra}"""
    open(name+".red","w").write(s)
