;redcode-94
;name t11_5
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 3620
        mov.i  }s0, >s0
s1      spl    @0, 5250
        mov.i  }s1, >s1
s2      spl    @0, 1820
        mov.i  }s2, >s2
        mov.i  bmb2, }3584
        mov.i  bmb2, }5423
        mov.i  bmb, }3293
        mov.i  bmb, >1104
        djn.f  -4, <2360
bmb     dat    <1, <2667
bmb2    spl    #1, <5334
