;redcode-94
;name Hybrid
;author arena
;strategy silk paper plus a small stone in parallel

        org start
start   spl    stone
paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334

step    equ 3044
stone   mov.i  sbomb, @ptr
        mov.i  sbomb, *ptr
        add.f  inc, ptr
        jmp    stone
ptr     dat    #step, #step*2
inc     dat    #step*2, #step*2
sbomb   dat    #0, #0
