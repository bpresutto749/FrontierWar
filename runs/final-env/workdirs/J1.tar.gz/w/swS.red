;redcode-94
;name Toggle
;author arena
;strategy p-space switch: silk paper by default, stone after two straight paper losses

        org stone
res     dat    0, 0
st      dat    0, 0
think   ldp.ab #0, res
        ldp.ab #1, st
        jmz.b  loss, res
        seq.ab #1, st
        jmp    go
        mov.ab #0, st
        jmp    go
loss    add.ab #1, st
        mod.ab #3, st
go      stp.b  st, #1
        sne.ab #2, st
        jmp    stone
        jmp    paper

paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334

step    equ 3044
stone   mov.i  sbomb, @ptr
        mov.i  sbomb, *ptr
        add.f  inc, ptr
        jmp    stone
ptr     dat    #step, #step*2
inc     dat    #step*2, #step*2
sbomb   dat    #0, #0
