;redcode-94
;name t11_6
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 1348
        mov.i  }s0, >s0
s1      spl    @0, 1896
        mov.i  }s1, >s1
s2      spl    @0, 3767
        mov.i  }s2, >s2
        mov.i  bmb2, }228
        mov.i  bmb2, }6479
        djn.f  -2, <3313
bmb     dat    <2667, <5334
bmb2    spl    #0, <2667
