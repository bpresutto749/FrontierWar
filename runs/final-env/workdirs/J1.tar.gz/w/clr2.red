;redcode-94
;name Broom2
;author arena
;strategy spl-then-dat sweep

        org start
ptr     dat    #0, #20
start   spl    #0, <-10
loop    mov.i  sbmb, >ptr
        mov.i  sbmb, >ptr
        djn.f  loop, <ptr
sbmb    spl    #0, 0
