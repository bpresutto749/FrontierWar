;redcode-94
;name Twin Silk 3
;author arena
;strategy p-space: two silk papers, switch to the spl-bomber after two straight losses

        org think
res     dat    0, 0
st      dat    0, 0
think   ldp.ab #0, res
        ldp.ab #1, st
        jmz.b  loss, res
        seq.ab #1, st
        jmp    go
        mov.ab #0, st
        jmp    go
loss    add.ab #1, st
        mod.ab #3, st
go      stp.b  st, #1
        sne.ab #2, st
        jmp    pB
        jmp    pA
pA      spl    1
        spl    1
        spl    1
        spl    1
a1      spl    @0, 3620
        mov.i  }a1, >a1
a2      spl    @0, 5250
        mov.i  }a2, >a2
a3      spl    @0, 1820
        mov.i  }a3, >a3
        mov.i  abm, }1777
        mov.i  abm, >-2311
        mov.i  abm, }3001
        djn.f  -3, <-1200
abm     dat    <2667, <5334

pB      spl    1
        spl    1
        spl    1
        spl    1
b1      spl    @0, 3620
        mov.i  }b1, >b1
b2      spl    @0, 5250
        mov.i  }b2, >b2
b3      spl    @0, 1820
        mov.i  }b3, >b3
        mov.i  bbm, }1777
        mov.i  bbm2, >-2311
        mov.i  bbm, }3001
        djn.f  -3, <-1200
bbm     dat    <2667, <5334
bbm2    spl    #0, <2667
