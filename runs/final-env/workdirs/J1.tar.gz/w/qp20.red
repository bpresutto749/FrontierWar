;redcode-94
;name qp20
;author arena
;strategy unrolled pair-qscan that dat-carpets a hit, then a three-stage silk paper
        org q
ptr     dat    0, 0
q       seq.i  99, 4109
        mov.ab #92, ptr
        seq.i  297, 4307
        mov.ab #292, ptr
        seq.i  496, 4506
        mov.ab #493, ptr
        seq.i  694, 4704
        mov.ab #693, ptr
        seq.i  893, 4903
        mov.ab #894, ptr
        seq.i  1091, 5101
        mov.ab #1094, ptr
        seq.i  1290, 5300
        mov.ab #1295, ptr
        seq.i  1488, 5498
        mov.ab #1495, ptr
        seq.i  1687, 5697
        mov.ab #1696, ptr
        seq.i  1885, 5895
        mov.ab #1896, ptr
        seq.i  2084, 6094
        mov.ab #2097, ptr
        seq.i  2282, 6292
        mov.ab #2297, ptr
        seq.i  2481, 6491
        mov.ab #2498, ptr
        seq.i  2679, 6689
        mov.ab #2698, ptr
        seq.i  2878, 6888
        mov.ab #2899, ptr
        seq.i  3076, 7086
        mov.ab #3099, ptr
        seq.i  3275, 7285
        mov.ab #3300, ptr
        seq.i  3473, 7483
        mov.ab #3500, ptr
        seq.i  3672, 7682
        mov.ab #3701, ptr
        seq.i  3870, 7881
        mov.ab #3901, ptr
        jmz.b  paper, ptr
atk     mov.i  qb, >ptr
        djn.b  atk, #20
        add.ab #3990, ptr
atk2    mov.i  qb, >ptr
        djn.b  atk2, #20
        jmp    paper
qb      dat    >2667, >5334
paper   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3620
        mov.i  }s1, >s1
s2      spl    @0, 5250
        mov.i  }s2, >s2
s3      spl    @0, 1820
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    <2667, <5334
