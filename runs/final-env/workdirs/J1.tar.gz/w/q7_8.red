;redcode-94
;name q7_8
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 1501
        mov.i  }s0, >s0
s1      spl    @0, 6352
        mov.i  }s1, >s1
s2      spl    @0, 2952
        mov.i  }s2, >s2
s3      spl    @0, 1395
        mov.i  }s3, >s3
        mov.i  bmb, }3604
        mov.i  bmb, >471
        mov.i  bmb, }5624
        jmp    -3, <785
bmb     dat    #0, <2667
