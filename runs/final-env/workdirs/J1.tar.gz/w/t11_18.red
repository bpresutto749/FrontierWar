;redcode-94
;name t11_18
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 7733
        mov.i  }s0, >s0
s1      spl    @0, 1903
        mov.i  }s1, >s1
s2      spl    @0, 6956
        mov.i  }s2, >s2
        mov.i  bmb2, }3283
        mov.i  bmb2, >5276
        mov.i  bmb2, >4409
        mov.i  bmb, >4195
        djn.f  -4, <6938
bmb     dat    <2667, <5334
bmb2    spl    #1, <5334
