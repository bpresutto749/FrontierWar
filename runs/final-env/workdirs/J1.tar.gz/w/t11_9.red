;redcode-94
;name t11_9
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 6897
        mov.i  }s0, >s0
s1      spl    @0, 7562
        mov.i  }s1, >s1
s2      spl    @0, 5036
        mov.i  }s2, >s2
        mov.i  bmb, >2553
        mov.i  bmb, }4410
        mov.i  bmb, }1587
        djn.f  -3, <4076
bmb     dat    <1, <2667
bmb2    spl    #0, <2667
