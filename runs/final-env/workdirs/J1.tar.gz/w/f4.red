;redcode-94
;name f4
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 3384
        mov.i  }s0, >s0
s1      spl    @0, 5482
        mov.i  }s1, >s1
s2      spl    @0, 545
        mov.i  }s2, >s2
s3      spl    @0, 1777
        mov.i  }s3, >s3
        mov.i  bmb, }6877
        djn.f  -1, <4539
bmb     dat    <2667, <5334
