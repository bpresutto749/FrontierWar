;redcode-94
;name rs1_4
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3798
        mov.i  }s1, >s1
s2      spl    @0, 2331
        mov.i  }s2, >s2
s3      spl    @0, 6060
        mov.i  }s3, >s3
        mov.i  bmb, }6718
        mov.i  bmb, >2024
        mov.i  bmb, }4992
        djn.f  -3, <987
bmb     dat    <2667, <5334
