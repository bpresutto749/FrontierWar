;redcode-94
;name q7_10
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
s0      spl    @0, 647
        mov.i  }s0, >s0
s1      spl    @0, 6139
        mov.i  }s1, >s1
s2      spl    @0, 5896
        mov.i  }s2, >s2
        mov.i  bmb, }5451
        mov.i  bmb, >4884
        mov.i  bmb, }5730
        djn.f  -3, <6883
bmb     spl    #0, <2667
