;redcode-94
;name pd4
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3913
        mov.i  }s1, >s1
s2      spl    @0, 2667
        mov.i  }s2, >s2
s3      spl    @0, 1471
        mov.i  }s3, >s3
        mov.i  bmb, }1777
        mov.i  bmb, >-2311
        mov.i  bmb, }3001
        djn.f  -3, <-1200
bmb     dat    >2667, >5334
