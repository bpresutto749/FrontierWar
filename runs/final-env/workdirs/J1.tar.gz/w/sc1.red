;redcode-94
;name Sweeper
;author arena
;strategy 0.5c scanner with spl carpets, then spl and dat core clears

STEP    equ 1329
        org scan
top     dat    0, 0
t       dat    0, 0
scan    add.ab #STEP, p
p       jmz.f  scan, STEP
        slt.ab #40, p
        jmp    scan
        slt.b  p, #7975
        jmp    scan
        mov.b  p, t
        add.ab #p-t-2, t
k       mov.i  sb, >t
        djn.b  k, cnt
        mov.ab #8, cnt
        djn.b  scan, #24
clear   mov.ab #last-cp+1, cp
cl1     mov.i  sb, >cp
        djn.b  cl1, #8000-(last-top+1)
        add.ab #last-top+1, cp
cl2     mov.i  db, >cp
        djn.b  cl2, #8000-(last-top+1)
        jmp    0
cnt     dat    0, #8
cp      dat    0, 0
sb      spl    #0, 0
db      dat    0, 0
last    dat    0, 0
