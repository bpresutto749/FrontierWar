import random, subprocess, sys, re, json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'.')
from gen import paper
seed=int(sys.argv[1]); n=int(sys.argv[2]); par=int(sys.argv[3])
random.seed(seed)
def rnd(): return random.randint(150, 7850)
def run(i):
    name=f"rs{seed}_{i}"
    p=dict(nspl=4, d1=rnd(), d2=rnd(), d3=rnd(), b1=rnd(), b2=rnd(), b3=rnd(), gate=rnd())
    paper(name, **p)
    out=subprocess.run(["python3","../tools/spar.py",name+".red","--rounds","100"],capture_output=True,text=True).stdout
    m=re.search(r"MEAN\s+([\d.]+)",out)
    sc=float(m.group(1)) if m else -1
    with open("log.txt","a") as f: f.write(f"{sc:.3f} {name} {json.dumps(p)}\n")
    return sc
with ThreadPoolExecutor(par) as ex: list(ex.map(run, range(n)))
