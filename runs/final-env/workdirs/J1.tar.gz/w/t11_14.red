;redcode-94
;name t11_14
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 892
        mov.i  }s0, >s0
s1      spl    @0, 5388
        mov.i  }s1, >s1
s2      spl    @0, 1096
        mov.i  }s2, >s2
        mov.i  bmb2, >7357
        mov.i  bmb2, >3559
        djn.f  -2, <7803
bmb     dat    <1, <2667
bmb2    spl    #0, >2667
