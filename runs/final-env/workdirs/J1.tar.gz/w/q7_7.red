;redcode-94
;name q7_7
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 4452
        mov.i  }s0, >s0
s1      spl    @0, 4205
        mov.i  }s1, >s1
        mov.i  bmb, }6125
        mov.i  bmb, >3826
        mov.i  bmb, }2508
        djn.f  -3, <5138
bmb     dat    <2667, <5334
