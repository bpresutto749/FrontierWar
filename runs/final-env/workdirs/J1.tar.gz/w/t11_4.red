;redcode-94
;name t11_4
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 2699
        mov.i  }s0, >s0
s1      spl    @0, 2874
        mov.i  }s1, >s1
s2      spl    @0, 274
        mov.i  }s2, >s2
        mov.i  bmb, >6359
        mov.i  bmb, }7709
        mov.i  bmb, }1116
        djn.f  -3, <239
bmb     dat    <2667, <5334
bmb2    spl    #0, >2667
