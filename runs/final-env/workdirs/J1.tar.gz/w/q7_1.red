;redcode-94
;name q7_1
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
s0      spl    @0, 7602
        mov.i  }s0, >s0
s1      spl    @0, 4306
        mov.i  }s1, >s1
s2      spl    @0, 1908
        mov.i  }s2, >s2
s3      spl    @0, 457
        mov.i  }s3, >s3
        mov.i  bmb, }3702
        djn.f  -1, <3575
bmb     dat    <2667, <5334
