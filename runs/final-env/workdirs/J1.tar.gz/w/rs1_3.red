;redcode-94
;name rs1_3
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 3343
        mov.i  }s1, >s1
s2      spl    @0, 3695
        mov.i  }s2, >s2
s3      spl    @0, 5126
        mov.i  }s3, >s3
        mov.i  bmb, }6394
        mov.i  bmb, >6434
        mov.i  bmb, }167
        djn.f  -3, <5850
bmb     dat    <2667, <5334
