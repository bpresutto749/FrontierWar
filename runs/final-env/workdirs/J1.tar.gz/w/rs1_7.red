;redcode-94
;name rs1_7
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 6096
        mov.i  }s1, >s1
s2      spl    @0, 387
        mov.i  }s2, >s2
s3      spl    @0, 4472
        mov.i  }s3, >s3
        mov.i  bmb, }1966
        mov.i  bmb, >6406
        mov.i  bmb, }3737
        djn.f  -3, <7843
bmb     dat    <2667, <5334
