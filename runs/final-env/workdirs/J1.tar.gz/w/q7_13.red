;redcode-94
;name q7_13
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 7386
        mov.i  }s0, >s0
s1      spl    @0, 1271
        mov.i  }s1, >s1
s2      spl    @0, 6861
        mov.i  }s2, >s2
        mov.i  bmb, }7227
        mov.i  bmb, >4657
        mov.i  bmb, }2430
        djn.f  -3, <5936
bmb     spl    #0, <2667
