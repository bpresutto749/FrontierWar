;redcode-94
;name q7_5
;author arena
;strategy multi-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
s0      spl    @0, 4637
        mov.i  }s0, >s0
s1      spl    @0, 5983
        mov.i  }s1, >s1
s2      spl    @0, 664
        mov.i  }s2, >s2
        mov.i  bmb, }638
        mov.i  bmb, >5220
        mov.i  bmb, }1837
        mov.i  bmb, >4216
        djn.f  -4, <5723
bmb     dat    #0, <2667
