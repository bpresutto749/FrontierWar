;redcode-94
;name t11_23
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 2688
        mov.i  }s0, >s0
s1      spl    @0, 4548
        mov.i  }s1, >s1
s2      spl    @0, 6628
        mov.i  }s2, >s2
        mov.i  bmb, >2295
        mov.i  bmb2, >7604
        mov.i  bmb, }6034
        mov.i  bmb, }7160
        djn.f  -4, <3761
bmb     dat    >2667, >5334
bmb2    spl    #0, >2667
