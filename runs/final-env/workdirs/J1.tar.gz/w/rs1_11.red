;redcode-94
;name rs1_11
;author arena
;strategy three-stage silk replicator
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s1      spl    @0, 6078
        mov.i  }s1, >s1
s2      spl    @0, 7194
        mov.i  }s2, >s2
s3      spl    @0, 2578
        mov.i  }s3, >s3
        mov.i  bmb, }1140
        mov.i  bmb, >6237
        mov.i  bmb, }2875
        djn.f  -3, <7486
bmb     dat    <2667, <5334
