;redcode-94
;name t11_11
;author arena
;strategy multi-stage silk replicator with mixed spl/dat bombing
        org start
start   spl    1
        spl    1
        spl    1
        spl    1
s0      spl    @0, 3620
        mov.i  }s0, >s0
s1      spl    @0, 5250
        mov.i  }s1, >s1
s2      spl    @0, 1820
        mov.i  }s2, >s2
        mov.i  bmb, }4982
        mov.i  bmb2, }437
        mov.i  bmb2, >7716
        djn.f  -3, <5892
bmb     dat    >2667, >5334
bmb2    spl    #0, <2667
