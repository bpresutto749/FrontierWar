def paper2(name, nspl, ds, bs, gate, bomb, loop="djn"):
    L=[";redcode-94",f";name {name}",";author arena",";strategy multi-stage silk replicator","        org start","start   spl    1"]
    L+=["        spl    1"]*(nspl-1)
    for i,d in enumerate(ds):
        L.append(f"s{i}      spl    @0, {d}")
        L.append(f"        mov.i  }}s{i}, >s{i}")
    ops=["}",">"]
    for j,b in enumerate(bs):
        L.append(f"        mov.i  bmb, {ops[j%2]}{b}")
    if loop=="djn":
        L.append(f"        djn.f  -{len(bs)}, <{gate}")
    elif loop=="jmp":
        L.append(f"        jmp    -{len(bs)}, <{gate}")
    L.append(f"bmb     {bomb}")
    open(name+".red","w").write("\n".join(L)+"\n")
