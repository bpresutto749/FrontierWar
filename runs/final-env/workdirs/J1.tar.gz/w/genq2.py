import sys
def build(name, N=30, lo=100, hi=7920, back=8, cnt=20, paper_lines=None, bomb="dat    >2667, >5334"):
    L=[]  # instruction strings, position = index
    hdr=[";redcode-94",f";name {name}",";author arena",";strategy unrolled pair-qscan that dat-carpets a hit, then a three-stage silk paper","        org q"]
    # layout: ptr at 0, checks from 1, then decode, attack, paper
    nck=2*N
    tg=[lo+(hi-lo)*i//(2*N-1) for i in range(2*N)]
    # interleave so pair (X,Y) far apart: pair i -> tg[i], tg[i+N]
    P=0
    L.append("ptr     dat    0, 0")
    for i in range(N):
        pos=len(L)
        X=tg[i]; Y=tg[i+N]
        lab="q      " if i==0 else "       "
        L.append(f"{lab} seq.i  {X-pos}, {Y-pos}")
        pos=len(L)
        L.append(f"        mov.ab #{X-P-back}, ptr")
        # second pair element: record Y via separate check? keep X only, attack both later
    # decode: jmz to paper if no hit
    L.append("        jmz.b  paper, ptr")
    L.append(f"atk     mov.i  qb, >ptr")
    L.append(f"        djn.b  atk, #{cnt}")
    # also attack Y region: Y = X + (tg[i+N]-tg[i]) which is constant? 
    L.append(f"        add.ab #{tg[N]-tg[0]-cnt}, ptr")
    L.append(f"atk2    mov.i  qb, >ptr")
    L.append(f"        djn.b  atk2, #{cnt}")
    L.append("        jmp    paper")
    L.append(f"qb      {bomb}")
    L+=paper_lines
    open(name+".red","w").write("\n".join(hdr+L)+"\n")
    return tg
paper=open("pb4.red").read().split("org start\n")[1].replace("start   spl    1","paper   spl    1",1).rstrip("\n").split("\n")
for N in (15,20,25):
    tg=build(f"qp{N}",N=N,paper_lines=paper)
    print(N, tg[N]-tg[0], tg[N+1]-tg[1])
