;redcode-94
;name SW1
;author me
;assert CORESIZE==8000
PC      equ     37
step    equ     3364
sstep   equ     3364
        org     loop
think   ldp.ab  #0,     res
        ldp.ab  #PC,    sel
        jmn.b   keep,   res
        add.ab  #1,     sel
keep    mod.ab  #3,     sel
        stp.b   sel,    #PC
        add.b   sel,    jptr
        jmp     @jptr
res     dat     0,      0
sel     dat     0,      0
jptr    dat     0,      tab
tab     dat     0,      pstart
        dat     0,      scan
        dat     0,      loop

pstart  spl     1
        spl     1
        spl     1
silk    spl     @0,     >3620
        mov.i   }silk,  >silk
silk2   spl     @0,     >1240
        mov.i   }silk2, >silk2
        mov.i   pbomb,  >2000
        mov.i   pbomb,  >2000
        jmp     silk
pbomb   dat     >2667,  >5334

scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step+100
        add.ab  ptr,    gate
        sub.ab  #10,    gate
        jmp     p1
gate    dat     0,      ptr-gate
p1      mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        djn.b   p1,     #2700
p2      mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        jmp     p2
sbomb   spl     #0,     dbomb-gate+2
dbomb   dat     0,      dbomb-gate+2

loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #sstep, #sstep*2
inc     dat     #sstep*2,#sstep*2
bomb    dat     >1,     >1
