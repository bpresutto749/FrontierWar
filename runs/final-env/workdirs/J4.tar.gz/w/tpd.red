;redcode-94
;name tpd
;author me
;assert CORESIZE==8000
sstep   equ     3364
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #1,     cur
        ldp.ab  #2,     n0
        ldp.ab  #3,     d0
        ldp.ab  #4,     n1
        ldp.ab  #5,     d1
        seq.ab  #-1,    res
        jmp     update
        jmp     choose
update  add.b   cur,    tp
        add.b   cur,    tp
        sne.ab  #0,     res
        mov.ab  #3,     def
        sne.ab  #2,     res
        mov.ab  #2,     def
        add.ab  #1,     >tp
        add.b   def,    @tp
        sub.ab  #1,     tp
        slt.ab  #30,    @tp
        jmp     choose
        div.ab  #2,     >tp
        div.ab  #2,     @tp
choose  mov.b   n1,     t1
        add.ab  #1,     t1
        mul.b   d0,     t1
        mov.b   n0,     t2
        add.ab  #1,     t2
        mul.b   d1,     t2
        mov.ab  #0,     cur
        slt.b   t2,     t1
        jmp     store
        mov.ab  #1,     cur
store   stp.b   cur,    #1
        stp.b   n0,     #2
        stp.b   d0,     #3
        stp.b   n1,     #4
        stp.b   d1,     #5
        jmn.b   die, cur
        jmp     pstart
res     dat     0,      0
cur     dat     0,      0
def     dat     0,      0
tp      dat     0,      n0
t1      dat     0,      0
t2      dat     0,      0
n0      dat     0,      0
d0      dat     0,      0
n1      dat     0,      0
d1      dat     0,      0
pstart  spl     1
        spl     1
        spl     1
silk    spl     @0,     >3620
        mov.i   }silk,  >silk
silk2   spl     @0,     >1240
        mov.i   }silk2, >silk2
        mov.i   pbomb,  >2000
        mov.i   pbomb,  >2000
        jmp     silk
pbomb   dat     >2667,  >5334
die     dat 0,0
