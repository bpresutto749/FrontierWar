die     dat 0,0
