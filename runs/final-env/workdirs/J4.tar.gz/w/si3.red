;redcode-94
;name SI3
;author me
;assert CORESIZE==8000
sstep   equ     3364
ist     equ     2667
        org     start
start   spl     loop
        spl     a1
        spl     a2
        jmp     imp+ist
a1      jmp     imp
a2      jmp     imp+2*ist
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #sstep, #sstep*2
inc     dat     #sstep*2,#sstep*2
bomb    dat     >1,     >1
imp     mov.i   #0,     ist
