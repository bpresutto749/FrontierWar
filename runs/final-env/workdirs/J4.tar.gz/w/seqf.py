import subprocess,sys
a,b,n=sys.argv[1],sys.argv[2],int(sys.argv[3])
prev=(0,0,0);s=""
for r in range(1,n+1):
    o=subprocess.run(["../bin/pmars","-b","-f","-r",str(r),a,b],capture_output=True,text=True).stdout.strip().splitlines()[-1].split()[1:4]
    o=tuple(map(int,o))
    s+="W" if o[0]>prev[0] else ("L" if o[1]>prev[1] else "T"); prev=o
print(s)
