;redcode-94
;name tdiv
;assert 1
        org     go
go      div.ab  #2,     >tp
        div.ab  #2,     @tp
        seq.ab  #15,    n0
        dat     0,      0
        seq.ab  #62,    d0
        dat     0,      0
imp     mov.i   #0,     1
tp      dat     0,      n0
n0      dat     0,      31
d0      dat     0,      62
