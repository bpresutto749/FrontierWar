;redcode-94
;name C1
;author me
;assert CORESIZE==8000
step    equ     3044
        org     scan
scan    add.f   inc,    ptr
ptr     sne.i   100,    100+step/2
        djn.f   scan,   <-300
        mov.ab  ptr,    clr
        jmz     scan, 0
        jmp     clr
inc     dat     #step,  #step
clr     dat     0,      0
