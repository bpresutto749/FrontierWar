;redcode-94
;name P1
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk    spl     @0,     >3620
        mov.i   }silk,  >silk
silk2   spl     @0,     >1240
        mov.i   }silk2, >silk2
        mov.i   bomb,   >2000
        mov.i   bomb,   >2000
        jmp     silk
bomb    dat     >2667,  >5334
