;redcode-94
;name C2
;author me
;assert CORESIZE==8000
step    equ     3364
        org     scan
scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step
        mov.ab  ptr,    cptr
        add.ab  #ptr-cptr-10, cptr
loop    mov.i   sbomb,  >cptr
        mov.i   sbomb,  >cptr
        djn.b   loop,   #4000
loop2   mov.i   dbomb,  >cptr
        jmp     loop2
cptr    dat     0,      0
sbomb   spl     #0,     0
dbomb   dat     0,      0
