;redcode-94
;name SI1
;author me
;assert CORESIZE==8000
sstep   equ     3364
        org     start
start   spl     imp
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #sstep, #sstep*2
inc     dat     #sstep*2,#sstep*2
bomb    dat     >1,     >1
        dat     0,0
        dat     0,0
        dat     0,0
imp     mov.i   #0,     1
