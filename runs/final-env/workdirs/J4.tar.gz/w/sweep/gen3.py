exec(open('gen2.py').read().split("B=[")[0])
B=["<1001","<3003"]; O=[5432,2345,1234]
V={
 'I1':dict(offs=O,bombs=B,silkop="<",tail=None),
 'I2':dict(offs=O,bombs=B,nspl=4,tail=None),
 'I3':dict(offs=O,bombs=B+["<5005"],tail=None),
 'I4':dict(offs=[3456,1789,6123],bombs=B,tail=None),
 'I5':dict(offs=O,bombs=B,bomb="dat     <2667,  <2667",tail=None),
 'I6':dict(offs=O,bombs=B,imp=True,tail=None),
 'I7':dict(offs=O,bombs=["<2001","<6003"],tail=None),
 'I8':dict(offs=[4321,1987,7123],bombs=B,tail=None),
}
for k,v in V.items(): open(k+".red","w").write(paper(k,**v))
