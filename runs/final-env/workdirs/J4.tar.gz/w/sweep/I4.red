;redcode-94
;name I4
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk0   spl     @0,     >3456
        mov.i   }silk0, >silk0
silk1   spl     @0,     >1789
        mov.i   }silk1, >silk1
silk2   spl     @0,     >6123
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
