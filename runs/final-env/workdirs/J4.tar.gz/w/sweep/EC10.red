;redcode-94
;name EC10
;author me
;assert CORESIZE==8000
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #1,     rnd
        ldp.ab  #6,     last
        ldp.ab  #2,     s0
        ldp.ab  #3,     s1
        ldp.ab  #4,     n0
        ldp.ab  #5,     n1
        sne.ab  #1,     res
        mov.ab  #3,     pts
        sne.ab  #2,     res
        mov.ab  #1,     pts
        seq.ab  #-1,    res
        jmp     attr
        jmp     dec
attr    jmn.b   at1,    last
        add.b   pts,    s0
        add.ab  #1,     n0
        jmp     dec
at1     add.b   pts,    s1
        add.ab  #1,     n1
dec     add.ab  #1,     rnd
        mov.ab  #0,     last
        slt.ab  #10,    rnd
        jmp     go
        mov.ab  #1,     last
        slt.ab  #20,    rnd
        jmp     go
        mov.b   s0,     t0
        mul.ab  #5,     t0
        div.b   n0,     t0
        mov.b   s1,     t1
        mul.ab  #5,     t1
        div.b   n1,     t1
        mov.ab  #0,     last
        slt.b   t0,     t1
        jmp     go
        mov.ab  #1,     last
go      stp.b   rnd,    #1
        stp.b   s0,     #2
        stp.b   s1,     #3
        stp.b   n0,     #4
        stp.b   n1,     #5
        stp.b   last,   #6
        jmn.b   loop,   last
        jmp     pstart
res     dat     0,      0
rnd     dat     0,      0
last    dat     0,      0
s0      dat     0,      0
s1      dat     0,      0
n0      dat     0,      0
n1      dat     0,      0
pts     dat     0,      0
t0      dat     0,      0
t1      dat     0,      0
pstart  spl     1
        spl     1
        spl     1
silk0   spl     @0,     >5432
        mov.i   }silk0, >silk0
silk1   spl     @0,     >2345
        mov.i   }silk1, >silk1
silk2   spl     @0,     >1234
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #3364,  #3364*2
inc     dat     #3364*2,#3364*2
bomb    dat     >1,     >1
