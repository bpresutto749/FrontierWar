def paper(name, offs, bombs, nspl=3, bomb="dat     <2667,  <5334", imp=False, silkop=">", tail="        jmp     silk0"):
    L=[";redcode-94",";name "+name,";author me",";assert CORESIZE==8000","        org     start"]
    if imp:
        L+=["start   spl     pstart","        spl     a1","        spl     a2","        jmp     imp+2667","a1      jmp     imp","a2      jmp     imp+5334","imp     mov.i   #0,     2667"]
        L.append("pstart  spl     1")
    else:
        L.append("start   spl     1")
    for i in range(nspl-1): L.append("        spl     1")
    for i,o in enumerate(offs):
        L.append(f"silk{i}   spl     @0,     {silkop}{o}")
        L.append(f"        mov.i   }}silk{i}, >silk{i}")
    for b in bombs:
        L.append(f"        mov.i   pbomb,  {b}")
    if tail: L.append(tail)
    L.append("pbomb   "+bomb)
    return "\n".join(L)+"\n"
B=["<1001","<3003"]; O=[5432,2345,1234]
V={
 'H1':dict(offs=O+[6543],bombs=B,imp=True),
 'H2':dict(offs=O,bombs=B,imp=True,bomb="dat     <2667,  <2667"),
 'H3':dict(offs=O,bombs=B+["<5005"],imp=True),
 'H4':dict(offs=O,bombs=B,silkop="<"),
 'H5':dict(offs=O+[6543,3210],bombs=B,nspl=4),
 'H6':dict(offs=O,bombs=B,tail="        djn.f   silk0,  <2500"),
 'H7':dict(offs=[5432,2345,1234],bombs=["<1001","<3003"],nspl=3,tail=None),
 'H8':dict(offs=[7232,3345,4234],bombs=B),
}
for k,v in V.items(): open(k+".red","w").write(paper(k,**v))
