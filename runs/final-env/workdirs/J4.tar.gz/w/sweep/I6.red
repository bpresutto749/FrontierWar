;redcode-94
;name I6
;author me
;assert CORESIZE==8000
        org     start
start   spl     pstart
        spl     a1
        spl     a2
        jmp     imp+2667
a1      jmp     imp
a2      jmp     imp+5334
imp     mov.i   #0,     2667
pstart  spl     1
        spl     1
        spl     1
silk0   spl     @0,     >5432
        mov.i   }silk0, >silk0
silk1   spl     @0,     >2345
        mov.i   }silk1, >silk1
silk2   spl     @0,     >1234
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
