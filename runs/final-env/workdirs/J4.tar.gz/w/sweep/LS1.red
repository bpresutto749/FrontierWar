;redcode-94
;name LS1
;author me
;assert CORESIZE==8000
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #37,    sel
        jmn.b   keep,   res
        add.ab  #1,     sel
keep    mod.ab  #2,     sel
        stp.b   sel,    #37
        jmn.b   loop,   sel
        jmp     pstart
res     dat     0,      0
sel     dat     0,      0
pstart  spl     1
        spl     1
        spl     1
silk    spl     @0,     >5432
        mov.i   }silk,  >silk
silk2   spl     @0,     >2345
        mov.i   }silk2, >silk2
silk3   spl     @0,     >1234
        mov.i   }silk3, >silk3
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
        jmp     silk
pbomb   dat     <2667,  <5334
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #3364,  #3364*2
inc     dat     #3364*2,#3364*2
bomb    dat     >1,     >1
