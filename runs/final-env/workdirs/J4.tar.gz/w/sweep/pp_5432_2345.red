;redcode-94
;name P
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk    spl     @0,     >5432
        mov.i   }silk,  >silk
silk2   spl     @0,     >2345
        mov.i   }silk2, >silk2
        mov.i   pbomb,  >2000
        mov.i   pbomb,  >2000
        jmp     silk
pbomb   dat     >2667,  >5334
