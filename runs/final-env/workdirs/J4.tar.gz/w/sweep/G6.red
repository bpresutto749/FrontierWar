;redcode-94
;name G6
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk0   spl     @0,     >4100
        mov.i   }silk0, >silk0
silk1   spl     @0,     >1800
        mov.i   }silk1, >silk1
silk2   spl     @0,     >2900
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
        jmp     silk0
pbomb   dat     <2667,  <5334
