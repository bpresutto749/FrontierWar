;redcode-94
;name LW2
;author me
;assert CORESIZE==8000
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #37,    sel
        ldp.ab  #38,    lcnt
        jmn.b   win,    res
        add.ab  #1,     lcnt
        slt.ab  #1,     lcnt
        jmp     keep
        add.ab  #1,     sel
win     mov.ab  #0,     lcnt
keep    mod.ab  #2,     sel
        stp.b   sel,    #37
        stp.b   lcnt,   #38
        jmn.b   wipe,   sel
        mov.ab  #pstart-wj, wj
        jmp     wipe
res     dat     0,      0
sel     dat     0,      0
lcnt    dat     0,      0
wipe    mov.i   wz,     <wptr
        djn.b   wipe,   #wipe-think
        jmp     @wj
wptr    dat     0,      wipe-wptr
wj      dat     0,      loop-wj
wz      dat     0,      0
pstart  spl     1
        spl     1
        spl     1
silk0   spl     @0,     >5432
        mov.i   }silk0, >silk0
silk1   spl     @0,     >2345
        mov.i   }silk1, >silk1
silk2   spl     @0,     >1234
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #3364,  #3364*2
inc     dat     #3364*2,#3364*2
bomb    dat     >1,     >1
