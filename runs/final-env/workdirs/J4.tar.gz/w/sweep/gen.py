import sys
def paper(name, offs, bombs, nspl=3, bomb="dat     <2667,  <5334", jmp=True):
    L=[";redcode-94",";name "+name,";author me",";assert CORESIZE==8000","        org     start"]
    L.append("start   spl     1")
    for i in range(nspl-1): L.append("        spl     1")
    for i,o in enumerate(offs):
        L.append(f"silk{i}   spl     @0,     >{o}")
        L.append(f"        mov.i   }}silk{i}, >silk{i}")
    for b in bombs:
        L.append(f"        mov.i   pbomb,  {b}")
    if jmp: L.append("        jmp     silk0")
    L.append("pbomb   "+bomb)
    return "\n".join(L)+"\n"
V={
 'G1':dict(offs=[5432,2345,1234,6543],bombs=["<1001","<3003"]),
 'G2':dict(offs=[5432,2345,1234],bombs=["<1001","<3003"],nspl=4),
 'G3':dict(offs=[5432,2345,1234],bombs=["<1001","<3003","<5005"]),
 'G4':dict(offs=[5432,2345,1234],bombs=["<1001"]),
 'G5':dict(offs=[3620,1240,6200],bombs=["<1001","<3003"]),
 'G6':dict(offs=[4100,1800,2900],bombs=["<1001","<3003"]),
 'G7':dict(offs=[5432,2345,1234],bombs=["<2001","<4003"]),
 'G8':dict(offs=[5432,2345,1234],bombs=["<1001","<3003"],bomb="dat     <2667,  <2667"),
}
for k,v in V.items(): open(k+".red","w").write(paper(k,**v))
