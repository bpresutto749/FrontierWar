;redcode-94
;name I8
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk0   spl     @0,     >4321
        mov.i   }silk0, >silk0
silk1   spl     @0,     >1987
        mov.i   }silk1, >silk1
silk2   spl     @0,     >7123
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
