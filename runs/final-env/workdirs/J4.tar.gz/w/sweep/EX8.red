;redcode-94
;name EX8
;author me
;assert CORESIZE==8000
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #1,     rnd
        ldp.ab  #2,     sc0
        ldp.ab  #3,     sc1
        sne.ab  #1,     res
        mov.ab  #3,     pts
        sne.ab  #2,     res
        mov.ab  #1,     pts
        slt.ab  #8,    rnd
        jmp     a0
        slt.ab  #16,    rnd
        add.b   pts,    sc1
        jmp     dec
a0      add.b   pts,    sc0
dec     add.ab  #1,     rnd
        stp.b   rnd,    #1
        stp.b   sc0,    #2
        stp.b   sc1,    #3
        slt.ab  #8,    rnd
        jmp     pstart
        slt.ab  #16,    rnd
        jmp     loop
        slt.b   sc0,    sc1
        jmp     pstart
        jmp     loop
res     dat     0,      0
rnd     dat     0,      0
sc0     dat     0,      0
sc1     dat     0,      0
pts     dat     0,      0
pstart  spl     1
        spl     1
        spl     1
silk0   spl     @0,     >5432
        mov.i   }silk0, >silk0
silk1   spl     @0,     >2345
        mov.i   }silk1, >silk1
silk2   spl     @0,     >1234
        mov.i   }silk2, >silk2
        mov.i   pbomb,  <1001
        mov.i   pbomb,  <3003
pbomb   dat     <2667,  <5334
loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #3364,  #3364*2
inc     dat     #3364*2,#3364*2
bomb    dat     >1,     >1
