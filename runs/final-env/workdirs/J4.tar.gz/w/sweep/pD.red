;redcode-94
;name P
;author me
;assert CORESIZE==8000
        org     start
start   spl     1
        spl     1
        spl     1
silk    spl     @0,     >5432
        mov.i   }silk,  >silk
silk2   spl     @0,     >2345
        mov.i   }silk2, >silk2
        mov.i   #1,     <1001
        mov.i   #1,     <3003
        jmp     silk
