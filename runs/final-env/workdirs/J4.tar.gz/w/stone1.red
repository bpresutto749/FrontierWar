;redcode-94
;name S1
;author me
;assert CORESIZE==8000
step    equ     3364
        org     loop
loop    add.f   inc,    ptr
        mov.i   bomb,   @ptr
        mov.i   bomb,   *ptr
        jmp     loop,   <-50
ptr     dat     #step,  #step*2
inc     dat     #step*2,#step*2
bomb    dat     >1,     >1
