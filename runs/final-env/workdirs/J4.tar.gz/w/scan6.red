;redcode-94
;name C6
;author me
;assert CORESIZE==8000
step    equ     3364
        org     scan
scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step+100
        add.ab  ptr,    gate
        sub.ab  #10,    gate
        jmp     p1
gate    dat     0,      ptr-gate
p1      mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        djn.b   p1,     #2700
p2      mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        jmp     p2
sbomb   spl     #0,     dbomb-gate+2
dbomb   dat     0,      dbomb-gate+2
