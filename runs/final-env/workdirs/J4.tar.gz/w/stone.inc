loop    add.f   inc,    sptr
        mov.i   bomb,   @sptr
        mov.i   bomb,   *sptr
        jmp     loop,   <-50
sptr    dat     #sstep, #sstep*2
inc     dat     #sstep*2,#sstep*2
bomb    dat     >1,     >1
