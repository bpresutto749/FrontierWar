;redcode-94
;name C5
;author me
;assert CORESIZE==8000
step    equ     3364
        org     scan
scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step+100
        add.ab  ptr,    gate
        sub.ab  #10,    gate
p1      mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        mov.i   sbomb,  >gate
        djn.b   p1,     #2700
p2      mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        mov.i   dbomb,  >gate
        jmp     p2
gate    dat     0,      ptr-gate
sbomb   spl     #0,     dbomb-gate+2
dbomb   dat     0,      dbomb-gate+2
