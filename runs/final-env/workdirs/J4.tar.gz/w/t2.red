;redcode-94
;name T1
;assert CORESIZE==8000
        org     think
think   ldp.ab  #0,     res
        ldp.ab  #37,    sel
        jmn.b   keep,   res
        add.ab  #1,     sel
keep    nop
        stp.b   sel,    #37
        jmp     imp
res     dat     0,      0
sel     dat     0,      0
imp     mov.i   #0,     1
