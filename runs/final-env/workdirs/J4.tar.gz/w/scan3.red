;redcode-94
;name C3
;author me
;assert CORESIZE==8000
step    equ     3364
        org     scan
scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step+100
        add.ab  ptr,    gate
gate    dat     0,      ptr-gate-5
clr     spl     #0,     0
loop    mov.i   bomb,   >gate
        djn.f   loop,   >gate
bomb    dat     0,      bomb-gate+2
