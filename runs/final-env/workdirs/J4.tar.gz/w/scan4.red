;redcode-94
;name C4
;author me
;assert CORESIZE==8000
step    equ     3364
        org     scan
scan    add.ab  #step,  ptr
ptr     jmz.f   scan,   step+100
        add.ab  ptr,    gate
        jmp     clr
gate    dat     0,      ptr-gate-5
clr     spl     #0,     0
loop    mov.i   bomb,   >gate
        mov.i   bomb,   >gate
        djn.f   loop,   >gate
bomb    spl     #0,     bomb-gate+2
